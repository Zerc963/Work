using System;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using MetaEdge.ISMD.Entity.Models.Mapping;
using System.Data;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class ISMDContext : DbContext
    {
        static ISMDContext()
        {
            Database.SetInitializer<ISMDContext>(null);
        }

        public ISMDContext()
            //: base("Name=ISMDContext")
        {
            string connectionString = MetaEdge.Registry.ConnectionFactory.Get("ISMD");
            base.Database.Connection.ConnectionString = connectionString;
            base.Database.CommandTimeout = 600;
        }

        public DbSet<CB_CHECK> CB_CHECK { get; set; }
        public DbSet<CB_DT> CB_DT { get; set; }
        public DbSet<sysssislog> sysssislog { get; set; }
        public DbSet<WWKSPC_XENCRYPTION> WWKSPC_XENCRYPTION { get; set; }
        public DbSet<WWKSPC_XFILEDETAIL> WWKSPC_XFILEDETAIL { get; set; }
        public DbSet<WWKSPC_XFLATFILEDETAIL> WWKSPC_XFLATFILEDETAIL { get; set; }
        public DbSet<WWKSPC_XFLOWDETAIL> WWKSPC_XFLOWDETAIL { get; set; }
        public DbSet<WWKSPC_XJOBDETAIL> WWKSPC_XJOBDETAIL { get; set; }
        public DbSet<WWKSPC_XLOCALDETAIL> WWKSPC_XLOCALDETAIL { get; set; }
        public DbSet<WWKSPC_XMAILDETAIL> WWKSPC_XMAILDETAIL { get; set; }
        public DbSet<WWKSPC_XMONITOR_FILEWAIT> WWKSPC_XMONITOR_FILEWAIT { get; set; }
        public DbSet<WWKSPC_XMONITOR_FLOWTIME> WWKSPC_XMONITOR_FLOWTIME { get; set; }
        public DbSet<WWKSPC_XREMOTEDETAIL> WWKSPC_XREMOTEDETAIL { get; set; }
        public DbSet<WWKSPC_XSCHEDULE> WWKSPC_XSCHEDULE { get; set; }
        public DbSet<WWKSPC_XWAITDETAIL> WWKSPC_XWAITDETAIL { get; set; }
        public DbSet<WJOBITEM> WJOBITEM { get; set; }
        public DbSet<XBATCHFLOW> XBATCHFLOW { get; set; }
        public DbSet<XBATCHFLOWH> XBATCHFLOWH { get; set; }
        public DbSet<XCHECKFILE> XCHECKFILE { get; set; }
        public DbSet<XCOLUMNDETAIL> XCOLUMNDETAIL { get; set; }
        public DbSet<XENCRYPTION> XENCRYPTION { get; set; }
        public DbSet<XFILEDETAIL> XFILEDETAIL { get; set; }
        public DbSet<XFILESTATUS> XFILESTATUS { get; set; }
        public DbSet<XFILESTATUSH> XFILESTATUSH { get; set; }
        public DbSet<XFLATFILEDETAIL> XFLATFILEDETAIL { get; set; }
        public DbSet<XFLOWAGENT> XFLOWAGENT { get; set; }
        public DbSet<XFLOWDETAIL> XFLOWDETAIL { get; set; }
        public DbSet<XFLOWSTATUS> XFLOWSTATUS { get; set; }
        public DbSet<XFLOWSTATUSH> XFLOWSTATUSH { get; set; }
        public DbSet<XGLOBALCONFIG> XGLOBALCONFIG { get; set; }
        public DbSet<XJOBDETAIL> XJOBDETAIL { get; set; }
        public DbSet<XJOBFILE> XJOBFILE { get; set; }
        public DbSet<XLOCALDETAIL> XLOCALDETAIL { get; set; }
        public DbSet<XMAILDETAIL> XMAILDETAIL { get; set; }
        public DbSet<XMAILLIST> XMAILLIST { get; set; }
        public DbSet<XMAILLISTH> XMAILLISTH { get; set; }
        public DbSet<XMONITOR_FILEWAIT> XMONITOR_FILEWAIT { get; set; }
        public DbSet<XMONITOR_FLOWTIME> XMONITOR_FLOWTIME { get; set; }
        public DbSet<XPROCESSFLOW> XPROCESSFLOW { get; set; }
        public DbSet<XREMOTEDETAIL> XREMOTEDETAIL { get; set; }
        public DbSet<XSCHEDULE> XSCHEDULE { get; set; }
        public DbSet<XSERVERDETAIL> XSERVERDETAIL { get; set; }
        public DbSet<XTABLESTATUS> XTABLESTATUS { get; set; }
        public DbSet<XTABLETRACK> XTABLETRACK { get; set; }
        public DbSet<XWAITDETAIL> XWAITDETAIL { get; set; }
        public DbSet<XWAITSTATUS> XWAITSTATUS { get; set; }
        public DbSet<XWAITSTATUSH> XWAITSTATUSH { get; set; }
        public DbSet<V_XBATCHFLOW> V_XBATCHFLOW { get; set; }
        public DbSet<WV_XBATCHFLOW> WV_XBATCHFLOW { get; set; }
        public DbSet<WV_XBATCHFLOWH> WV_XBATCHFLOWH { get; set; }
        public DbSet<WV_XFILESTATUS> WV_XFILESTATUS { get; set; }
        public DbSet<WV_XFILESTATUSH> WV_XFILESTATUSH { get; set; }
        public DbSet<WV_XFLOWDETAIL> WV_XFLOWDETAIL { get; set; }
        public DbSet<WV_XFLOWSTATUS> WV_XFLOWSTATUS { get; set; }
        public DbSet<WV_WJOBITEM> WV_WJOBITEM { get; set; }
        public DbSet<WV_XWAITSTATUS> WV_XWAITSTATUS { get; set; }
        public DbSet<WV_XWAITSTATUSH> WV_XWAITSTATUSH { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new CB_CHECKMap());
            modelBuilder.Configurations.Add(new CB_DTMap());
            modelBuilder.Configurations.Add(new sysssislogMap());
            modelBuilder.Configurations.Add(new WWKSPC_XENCRYPTIONMap());
            modelBuilder.Configurations.Add(new WWKSPC_XFILEDETAILMap());
            modelBuilder.Configurations.Add(new WWKSPC_XFLATFILEDETAILMap());
            modelBuilder.Configurations.Add(new WWKSPC_XFLOWDETAILMap());
            modelBuilder.Configurations.Add(new WWKSPC_XJOBDETAILMap());
            modelBuilder.Configurations.Add(new WWKSPC_XLOCALDETAILMap());
            modelBuilder.Configurations.Add(new WWKSPC_XMAILDETAILMap());
            modelBuilder.Configurations.Add(new WWKSPC_XMONITOR_FILEWAITMap());
            modelBuilder.Configurations.Add(new WWKSPC_XMONITOR_FLOWTIMEMap());
            modelBuilder.Configurations.Add(new WWKSPC_XREMOTEDETAILMap());
            modelBuilder.Configurations.Add(new WWKSPC_XSCHEDULEMap());
            modelBuilder.Configurations.Add(new WWKSPC_XWAITDETAILMap());
            modelBuilder.Configurations.Add(new WJOBITEMMap());
            modelBuilder.Configurations.Add(new XBATCHFLOWMap());
            modelBuilder.Configurations.Add(new XBATCHFLOWHMap());
            modelBuilder.Configurations.Add(new XCHECKFILEMap());
            modelBuilder.Configurations.Add(new XCOLUMNDETAILMap());
            modelBuilder.Configurations.Add(new XENCRYPTIONMap());
            modelBuilder.Configurations.Add(new XFILEDETAILMap());
            modelBuilder.Configurations.Add(new XFILESTATUSMap());
            modelBuilder.Configurations.Add(new XFILESTATUSHMap());
            modelBuilder.Configurations.Add(new XFLATFILEDETAILMap());
            modelBuilder.Configurations.Add(new XFLOWAGENTMap());
            modelBuilder.Configurations.Add(new XFLOWDETAILMap());
            modelBuilder.Configurations.Add(new XFLOWSTATUSMap());
            modelBuilder.Configurations.Add(new XFLOWSTATUSHMap());
            modelBuilder.Configurations.Add(new XGLOBALCONFIGMap());
            modelBuilder.Configurations.Add(new XJOBDETAILMap());
            modelBuilder.Configurations.Add(new XJOBFILEMap());
            modelBuilder.Configurations.Add(new XLOCALDETAILMap());
            modelBuilder.Configurations.Add(new XMAILDETAILMap());
            modelBuilder.Configurations.Add(new XMAILLISTMap());
            modelBuilder.Configurations.Add(new XMAILLISTHMap());
            modelBuilder.Configurations.Add(new XMONITOR_FILEWAITMap());
            modelBuilder.Configurations.Add(new XMONITOR_FLOWTIMEMap());
            modelBuilder.Configurations.Add(new XPROCESSFLOWMap());
            modelBuilder.Configurations.Add(new XREMOTEDETAILMap());
            modelBuilder.Configurations.Add(new XSCHEDULEMap());
            modelBuilder.Configurations.Add(new XSERVERDETAILMap());
            modelBuilder.Configurations.Add(new XTABLESTATUSMap());
            modelBuilder.Configurations.Add(new XTABLETRACKMap());
            modelBuilder.Configurations.Add(new XWAITDETAILMap());
            modelBuilder.Configurations.Add(new XWAITSTATUSMap());
            modelBuilder.Configurations.Add(new XWAITSTATUSHMap());
            modelBuilder.Configurations.Add(new V_XBATCHFLOWMap());
            modelBuilder.Configurations.Add(new WV_XBATCHFLOWMap());
            modelBuilder.Configurations.Add(new WV_XBATCHFLOWHMap());
            modelBuilder.Configurations.Add(new WV_XFILESTATUSMap());
            modelBuilder.Configurations.Add(new WV_XFILESTATUSHMap());
            modelBuilder.Configurations.Add(new WV_XFLOWDETAILMap());
            modelBuilder.Configurations.Add(new WV_XFLOWSTATUSMap());
            modelBuilder.Configurations.Add(new WV_WJOBITEMMap());
            modelBuilder.Configurations.Add(new WV_XWAITSTATUSMap());
            modelBuilder.Configurations.Add(new WV_XWAITSTATUSHMap());
        }
    }
}
