using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class CB_CHECKMap : EntityTypeConfiguration<CB_CHECK>
    {
        public CB_CHECKMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.SEQ, t.ORGDATASRC });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.SRCDATE)
                .IsFixedLength()
                .HasMaxLength(8);

            this.Property(t => t.SRCNAME)
                .HasMaxLength(50);

            this.Property(t => t.SRC_AMT_NM)
                .HasMaxLength(50);

            this.Property(t => t.ORGDATASRC)
                .IsRequired()
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("CB_CHECK");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.CYCLEDATE).HasColumnName("CYCLEDATE");
            this.Property(t => t.SEQ).HasColumnName("SEQ");
            this.Property(t => t.SRCDATE).HasColumnName("SRCDATE");
            this.Property(t => t.SRCNAME).HasColumnName("SRCNAME");
            this.Property(t => t.SRC_CNT).HasColumnName("SRC_CNT");
            this.Property(t => t.SRC_AMT_NM).HasColumnName("SRC_AMT_NM");
            this.Property(t => t.SRC_AMT).HasColumnName("SRC_AMT");
            this.Property(t => t.ORGDATASRC).HasColumnName("ORGDATASRC");
            this.Property(t => t.CREATE_DT).HasColumnName("CREATE_DT");
        }
    }
}
