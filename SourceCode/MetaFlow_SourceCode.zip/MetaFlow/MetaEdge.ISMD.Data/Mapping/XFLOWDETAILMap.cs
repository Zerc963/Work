using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XFLOWDETAILMap : EntityTypeConfiguration<XFLOWDETAIL>
    {
        public XFLOWDETAILMap()
        {
            // Primary Key
            this.HasKey(t => t.DATACAT);

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.FLOW_TYPE)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.DATACATNM)
                .HasMaxLength(100);

            this.Property(t => t.DT_TYPE)
                .IsFixedLength()
                .HasMaxLength(3);

            this.Property(t => t.CYC_RERUN_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.CURR_CYC_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.AGENT_MODE)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.LOCAL_MODE)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XFLOWDETAIL");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.FLOW_TYPE).HasColumnName("FLOW_TYPE");
            this.Property(t => t.DATACATNM).HasColumnName("DATACATNM");
            this.Property(t => t.DT_TYPE).HasColumnName("DT_TYPE");
            this.Property(t => t.DT_CHG_HR).HasColumnName("DT_CHG_HR");
            this.Property(t => t.CYC_RERUN_FG).HasColumnName("CYC_RERUN_FG");
            this.Property(t => t.CURR_CYC_FG).HasColumnName("CURR_CYC_FG");
            this.Property(t => t.RETRY_TIMES).HasColumnName("RETRY_TIMES");
            this.Property(t => t.ABORT_RESTART_INTERVAL).HasColumnName("ABORT_RESTART_INTERVAL");
            this.Property(t => t.ABORT_NOTIFY_SKIP_TIMES).HasColumnName("ABORT_NOTIFY_SKIP_TIMES");
            this.Property(t => t.AGENT_MODE).HasColumnName("AGENT_MODE");
            this.Property(t => t.LOCAL_MODE).HasColumnName("LOCAL_MODE");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
