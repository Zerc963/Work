using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WWKSPC_XLOCALDETAILMap : EntityTypeConfiguration<WWKSPC_XLOCALDETAIL>
    {
        public WWKSPC_XLOCALDETAILMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.LSEQ, t.LST_MAINT_USR });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.LSEQ)
                .IsRequired()
                .HasMaxLength(10);

            this.Property(t => t.LOCAL_PATH)
                .HasMaxLength(150);

            this.Property(t => t.WORK_PATH)
                .HasMaxLength(150);

            this.Property(t => t.BACKUP_PATH)
                .HasMaxLength(150);

            this.Property(t => t.LST_MAINT_USR)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("WWKSPC_XLOCALDETAIL");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.LSEQ).HasColumnName("LSEQ");
            this.Property(t => t.LOCAL_PATH).HasColumnName("LOCAL_PATH");
            this.Property(t => t.WORK_PATH).HasColumnName("WORK_PATH");
            this.Property(t => t.BACKUP_PATH).HasColumnName("BACKUP_PATH");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
