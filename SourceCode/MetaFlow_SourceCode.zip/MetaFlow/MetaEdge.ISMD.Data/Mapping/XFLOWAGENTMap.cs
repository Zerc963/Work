using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XFLOWAGENTMap : EntityTypeConfiguration<XFLOWAGENT>
    {
        public XFLOWAGENTMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.CYCLEDATE, t.START_MODE });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.CYCLEDATE)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(8);

            this.Property(t => t.START_MODE)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(10);

            this.Property(t => t.CREATE_USER)
                .HasMaxLength(200);

            // Table & Column Mappings
            this.ToTable("XFLOWAGENT");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.CYCLEDATE).HasColumnName("CYCLEDATE");
            this.Property(t => t.START_MODE).HasColumnName("START_MODE");
            this.Property(t => t.CREATE_USER).HasColumnName("CREATE_USER");
            this.Property(t => t.CREATE_DT).HasColumnName("CREATE_DT");
        }
    }
}
