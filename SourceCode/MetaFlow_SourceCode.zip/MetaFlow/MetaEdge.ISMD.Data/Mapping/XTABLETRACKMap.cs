using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XTABLETRACKMap : EntityTypeConfiguration<XTABLETRACK>
    {
        public XTABLETRACKMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.JOB_STAGE, t.JOB_FLOW, t.JOB_SEQ });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.JOB_STAGE)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.JOB_FLOW)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.JOB_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.TGT_DB)
                .HasMaxLength(128);

            this.Property(t => t.TGT_TB)
                .HasMaxLength(1000);

            // Table & Column Mappings
            this.ToTable("XTABLETRACK");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.JOB_STAGE).HasColumnName("JOB_STAGE");
            this.Property(t => t.JOB_FLOW).HasColumnName("JOB_FLOW");
            this.Property(t => t.JOB_SEQ).HasColumnName("JOB_SEQ");
            this.Property(t => t.CYCLEDATE).HasColumnName("CYCLEDATE");
            this.Property(t => t.TGT_DB).HasColumnName("TGT_DB");
            this.Property(t => t.TGT_TB).HasColumnName("TGT_TB");
            this.Property(t => t.LSTMODIFYDT).HasColumnName("LSTMODIFYDT");
        }
    }
}
