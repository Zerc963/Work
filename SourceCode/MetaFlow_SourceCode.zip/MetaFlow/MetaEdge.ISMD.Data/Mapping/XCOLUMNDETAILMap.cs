using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XCOLUMNDETAILMap : EntityTypeConfiguration<XCOLUMNDETAIL>
    {
        public XCOLUMNDETAILMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DB_NM, t.SCHEMA_NM, t.TABLE_NM, t.COLUMN_NM });

            // Properties
            this.Property(t => t.DB_NM)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.SCHEMA_NM)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.TABLE_NM)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.COLUMN_NM)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XCOLUMNDETAIL");
            this.Property(t => t.DB_NM).HasColumnName("DB_NM");
            this.Property(t => t.SCHEMA_NM).HasColumnName("SCHEMA_NM");
            this.Property(t => t.TABLE_NM).HasColumnName("TABLE_NM");
            this.Property(t => t.COLUMN_SEQ).HasColumnName("COLUMN_SEQ");
            this.Property(t => t.COLUMN_NM).HasColumnName("COLUMN_NM");
            this.Property(t => t.COLUMN_LEN).HasColumnName("COLUMN_LEN");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
