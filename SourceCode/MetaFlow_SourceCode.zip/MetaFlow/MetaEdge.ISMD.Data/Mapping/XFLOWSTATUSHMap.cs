using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XFLOWSTATUSHMap : EntityTypeConfiguration<XFLOWSTATUSH>
    {
        public XFLOWSTATUSHMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.BATCH_NO });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.START_MODE)
                .IsFixedLength()
                .HasMaxLength(10);

            this.Property(t => t.RUN_STATUS)
                .IsFixedLength()
                .HasMaxLength(7);

            this.Property(t => t.EXECUTION_ID)
                .HasMaxLength(50);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XFLOWSTATUSH");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.BATCH_NO).HasColumnName("BATCH_NO");
            this.Property(t => t.CYCLE_START).HasColumnName("CYCLE_START");
            this.Property(t => t.CYCLE_END).HasColumnName("CYCLE_END");
            this.Property(t => t.START_MODE).HasColumnName("START_MODE");
            this.Property(t => t.RUN_STATUS).HasColumnName("RUN_STATUS");
            this.Property(t => t.START_TIME).HasColumnName("START_TIME");
            this.Property(t => t.RESTART_TIME).HasColumnName("RESTART_TIME");
            this.Property(t => t.END_TIME).HasColumnName("END_TIME");
            this.Property(t => t.RUN_DESC).HasColumnName("RUN_DESC");
            this.Property(t => t.EXECUTION_ID).HasColumnName("EXECUTION_ID");
            this.Property(t => t.NEXT_TIME).HasColumnName("NEXT_TIME");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
