using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XMAILLISTHMap : EntityTypeConfiguration<XMAILLISTH>
    {
        public XMAILLISTHMap()
        {
            // Primary Key
            this.HasKey(t => t.ID);

            // Properties
            this.Property(t => t.ID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.ContactAddress)
                .HasMaxLength(4000);

            this.Property(t => t.NotificationTitle)
                .HasMaxLength(200);

            // Table & Column Mappings
            this.ToTable("XMAILLISTH");
            this.Property(t => t.SendTime).HasColumnName("SendTime");
            this.Property(t => t.ID).HasColumnName("ID");
            this.Property(t => t.ContactAddress).HasColumnName("ContactAddress");
            this.Property(t => t.NotificationTitle).HasColumnName("NotificationTitle");
            this.Property(t => t.Body).HasColumnName("Body");
            this.Property(t => t.MailID).HasColumnName("MailID");
            this.Property(t => t.Attachment).HasColumnName("Attachment");
            this.Property(t => t.ExecDesc).HasColumnName("ExecDesc");
        }
    }
}
