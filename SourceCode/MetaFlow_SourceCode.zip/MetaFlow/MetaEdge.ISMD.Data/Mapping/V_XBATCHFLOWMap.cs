using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class V_XBATCHFLOWMap : EntityTypeConfiguration<V_XBATCHFLOW>
    {
        public V_XBATCHFLOWMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.JOB_STAGE, t.JOB_FLOW, t.JOB_SEQ, t.JOB_STAGE_SEQ });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PROCESS_TYPE)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.JOB_STAGE)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.JOB_FLOW)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.JOB_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.JOB_NAME)
                .HasMaxLength(150);

            this.Property(t => t.START_MODE)
                .IsFixedLength()
                .HasMaxLength(7);

            this.Property(t => t.RUN_STATUS)
                .IsFixedLength()
                .HasMaxLength(7);

            this.Property(t => t.SRC_TB)
                .HasMaxLength(1000);

            this.Property(t => t.TGT_TB)
                .HasMaxLength(1000);

            this.Property(t => t.PARAM)
                .HasMaxLength(4000);

            this.Property(t => t.SKIP_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.FORK_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.ABORTCONTINUE_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.JOB_TYPE)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.JOB_DESC)
                .HasMaxLength(255);

            this.Property(t => t.JOB_LOCATION)
                .HasMaxLength(100);

            this.Property(t => t.JOB_OWNER)
                .HasMaxLength(30);

            this.Property(t => t.EXECUTION_ID)
                .HasMaxLength(50);

            this.Property(t => t.JOB_STAGE_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            // Table & Column Mappings
            this.ToTable("V_XBATCHFLOW");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.BATCH_NO).HasColumnName("BATCH_NO");
            this.Property(t => t.CYCLE_START).HasColumnName("CYCLE_START");
            this.Property(t => t.CYCLE_END).HasColumnName("CYCLE_END");
            this.Property(t => t.PROCESS_TYPE).HasColumnName("PROCESS_TYPE");
            this.Property(t => t.JOB_STAGE).HasColumnName("JOB_STAGE");
            this.Property(t => t.JOB_FLOW).HasColumnName("JOB_FLOW");
            this.Property(t => t.JOB_SEQ).HasColumnName("JOB_SEQ");
            this.Property(t => t.JOB_NAME).HasColumnName("JOB_NAME");
            this.Property(t => t.START_MODE).HasColumnName("START_MODE");
            this.Property(t => t.JOB_START_TIME).HasColumnName("JOB_START_TIME");
            this.Property(t => t.JOB_END_TIME).HasColumnName("JOB_END_TIME");
            this.Property(t => t.RUN_STATUS).HasColumnName("RUN_STATUS");
            this.Property(t => t.INS_CNT).HasColumnName("INS_CNT");
            this.Property(t => t.UPD_CNT).HasColumnName("UPD_CNT");
            this.Property(t => t.DEL_CNT).HasColumnName("DEL_CNT");
            this.Property(t => t.SRC_TB).HasColumnName("SRC_TB");
            this.Property(t => t.TGT_TB).HasColumnName("TGT_TB");
            this.Property(t => t.PARAM).HasColumnName("PARAM");
            this.Property(t => t.SKIP_FLAG).HasColumnName("SKIP_FLAG");
            this.Property(t => t.FORK_FLAG).HasColumnName("FORK_FLAG");
            this.Property(t => t.ABORTCONTINUE_FLAG).HasColumnName("ABORTCONTINUE_FLAG");
            this.Property(t => t.JOB_TYPE).HasColumnName("JOB_TYPE");
            this.Property(t => t.JOB_DESC).HasColumnName("JOB_DESC");
            this.Property(t => t.JOB_LOCATION).HasColumnName("JOB_LOCATION");
            this.Property(t => t.JOB_OWNER).HasColumnName("JOB_OWNER");
            this.Property(t => t.EXEC_DESC).HasColumnName("EXEC_DESC");
            this.Property(t => t.EXECUTION_ID).HasColumnName("EXECUTION_ID");
            this.Property(t => t.DATACAT_SEQ).HasColumnName("DATACAT_SEQ");
            this.Property(t => t.JOB_STAGE_SEQ).HasColumnName("JOB_STAGE_SEQ");
        }
    }
}
