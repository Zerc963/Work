using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XENCRYPTIONMap : EntityTypeConfiguration<XENCRYPTION>
    {
        public XENCRYPTIONMap()
        {
            // Primary Key
            this.HasKey(t => t.SEQ);

            // Properties
            this.Property(t => t.SEQ)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.VALUE)
                .HasMaxLength(100);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XENCRYPTION");
            this.Property(t => t.SEQ).HasColumnName("SEQ");
            this.Property(t => t.VALUE).HasColumnName("VALUE");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
