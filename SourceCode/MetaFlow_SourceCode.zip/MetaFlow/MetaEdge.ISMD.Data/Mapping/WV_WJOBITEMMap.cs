using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WV_WJOBITEMMap : EntityTypeConfiguration<WV_WJOBITEM>
    {
        public WV_WJOBITEMMap()
        {
            // Primary Key
            this.HasKey(t => new { t.JOB_NAME, t.JOB_TYPE, t.JOB_LOCATION, t.JOB_OWNER });

            // Properties
            this.Property(t => t.JOB_LABEL)
                .IsRequired();

            this.Property(t => t.JOB_NAME)
                .IsRequired()
                .HasMaxLength(150);

            this.Property(t => t.JOB_TYPE)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.JOB_TYPE_DESC)
                .IsRequired()
                .HasMaxLength(255);

            this.Property(t => t.JOB_LOCATION)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.JOB_OWNER)
                .IsRequired()
                .HasMaxLength(30);

            this.Property(t => t.TOOL_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.MANUAL_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.DISABLE_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.JOB_DESC)
                .HasMaxLength(1000);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            this.Property(t => t.Is_Used)
                .HasMaxLength(2);

            // Table & Column Mappings
            this.ToTable("WV_WJOBITEM");
            this.Property(t => t.JOB_NAME).HasColumnName("JOB_LABEL");
            this.Property(t => t.JOB_NAME).HasColumnName("JOB_NAME");
            this.Property(t => t.JOB_TYPE).HasColumnName("JOB_TYPE");
            this.Property(t => t.JOB_TYPE_DESC).HasColumnName("JOB_TYPE_DESC");
            this.Property(t => t.JOB_LOCATION).HasColumnName("JOB_LOCATION");
            this.Property(t => t.JOB_OWNER).HasColumnName("JOB_OWNER");
            this.Property(t => t.TOOL_FG).HasColumnName("TOOL_FG");
            this.Property(t => t.MANUAL_FG).HasColumnName("MANUAL_FG");
            this.Property(t => t.DISABLE_FG).HasColumnName("DISABLE_FG");
            this.Property(t => t.JOB_DESC).HasColumnName("JOB_DESC");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
            this.Property(t => t.Is_Used).HasColumnName("Is_Used");
        }
    }
}
