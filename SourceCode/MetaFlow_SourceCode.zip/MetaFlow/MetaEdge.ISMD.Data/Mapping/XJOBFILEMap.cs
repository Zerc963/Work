using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XJOBFILEMap : EntityTypeConfiguration<XJOBFILE>
    {
        public XJOBFILEMap()
        {
            // Primary Key
            this.HasKey(t => new { t.JOB_DATACAT, t.JOB_STAGE, t.JOB_FLOW, t.JOB_SEQ, t.FILE_DATACAT, t.FILE_SEQ });

            // Properties
            this.Property(t => t.JOB_DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.JOB_STAGE)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.JOB_FLOW)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.JOB_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.FILE_DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.FILE_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.NOT_EXIST_SKIP_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XJOBFILE");
            this.Property(t => t.JOB_DATACAT).HasColumnName("JOB_DATACAT");
            this.Property(t => t.JOB_STAGE).HasColumnName("JOB_STAGE");
            this.Property(t => t.JOB_FLOW).HasColumnName("JOB_FLOW");
            this.Property(t => t.JOB_SEQ).HasColumnName("JOB_SEQ");
            this.Property(t => t.FILE_DATACAT).HasColumnName("FILE_DATACAT");
            this.Property(t => t.FILE_SEQ).HasColumnName("FILE_SEQ");
            this.Property(t => t.NOT_EXIST_SKIP_FG).HasColumnName("NOT_EXIST_SKIP_FG");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
