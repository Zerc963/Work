using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XWAITSTATUSMap : EntityTypeConfiguration<XWAITSTATUS>
    {
        public XWAITSTATUSMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.WAIT_SEQ });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PROCESS_TYPE)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.WAIT_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.WAIT_TYPE)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.RSEQ)
                .HasMaxLength(10);

            this.Property(t => t.LSEQ)
                .HasMaxLength(10);

            this.Property(t => t.WAIT_NAME)
                .HasMaxLength(128);

            this.Property(t => t.CHK_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.CHK_FILEDATE_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.WAIT_SKIP_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.NOT_EXIST_SKIP_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.WAIT_STATUS)
                .IsFixedLength()
                .HasMaxLength(10);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XWAITSTATUS");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.BATCH_NO).HasColumnName("BATCH_NO");
            this.Property(t => t.CYCLE_START).HasColumnName("CYCLE_START");
            this.Property(t => t.CYCLE_END).HasColumnName("CYCLE_END");
            this.Property(t => t.PROCESS_TYPE).HasColumnName("PROCESS_TYPE");
            this.Property(t => t.WAIT_SEQ).HasColumnName("WAIT_SEQ");
            this.Property(t => t.WAIT_TYPE).HasColumnName("WAIT_TYPE");
            this.Property(t => t.RSEQ).HasColumnName("RSEQ");
            this.Property(t => t.LSEQ).HasColumnName("LSEQ");
            this.Property(t => t.WAIT_NAME).HasColumnName("WAIT_NAME");
            this.Property(t => t.CHK_FG).HasColumnName("CHK_FG");
            this.Property(t => t.CHK_FILEDATE_FG).HasColumnName("CHK_FILEDATE_FG");
            this.Property(t => t.TOLERANCE).HasColumnName("TOLERANCE");
            this.Property(t => t.WAIT_SKIP_FLAG).HasColumnName("WAIT_SKIP_FLAG");
            this.Property(t => t.NOT_EXIST_SKIP_FG).HasColumnName("NOT_EXIST_SKIP_FG");
            this.Property(t => t.WAIT_STATUS).HasColumnName("WAIT_STATUS");
            this.Property(t => t.WAIT_START_TIME).HasColumnName("WAIT_START_TIME");
            this.Property(t => t.WAIT_END_TIME).HasColumnName("WAIT_END_TIME");
            this.Property(t => t.WAIT_DESC).HasColumnName("WAIT_DESC");
            this.Property(t => t.FILEDATE).HasColumnName("FILEDATE");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
