using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XTABLESTATUSMap : EntityTypeConfiguration<XTABLESTATUS>
    {
        public XTABLESTATUSMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DBNAME, t.TABLENAME });

            // Properties
            this.Property(t => t.DBNAME)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.TABLENAME)
                .IsRequired()
                .HasMaxLength(128);

            // Table & Column Mappings
            this.ToTable("XTABLESTATUS");
            this.Property(t => t.DBNAME).HasColumnName("DBNAME");
            this.Property(t => t.TABLENAME).HasColumnName("TABLENAME");
            this.Property(t => t.CYCLEDATE).HasColumnName("CYCLEDATE");
            this.Property(t => t.LSTMODIFYDT).HasColumnName("LSTMODIFYDT");
        }
    }
}
