using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class CB_DTMap : EntityTypeConfiguration<CB_DT>
    {
        public CB_DTMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATADT, t.Contry2Cd });

            // Properties
            this.Property(t => t.Contry2Cd)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(3);

            this.Property(t => t.DT_CHAR)
                .IsFixedLength()
                .HasMaxLength(8);

            this.Property(t => t.SEMI_YR_NM)
                .IsFixedLength()
                .HasMaxLength(6);

            this.Property(t => t.HOLIDY_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BBOW_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BEOW_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BBOM_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BEOM_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BBOQ_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BEOQ_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BBOS_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BEOS_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BBOY_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.BEOY_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.EOM_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("CB_DT");
            this.Property(t => t.DATADT).HasColumnName("DATADT");
            this.Property(t => t.Contry2Cd).HasColumnName("Contry2Cd");
            this.Property(t => t.DT_CHAR).HasColumnName("DT_CHAR");
            this.Property(t => t.WEEK_DY).HasColumnName("WEEK_DY");
            this.Property(t => t.WEEK_NO).HasColumnName("WEEK_NO");
            this.Property(t => t.YR).HasColumnName("YR");
            this.Property(t => t.MN).HasColumnName("MN");
            this.Property(t => t.DY_IN_MN).HasColumnName("DY_IN_MN");
            this.Property(t => t.DY_IN_YR).HasColumnName("DY_IN_YR");
            this.Property(t => t.SEASON).HasColumnName("SEASON");
            this.Property(t => t.SEMI_YR_NM).HasColumnName("SEMI_YR_NM");
            this.Property(t => t.HOLIDY_FG).HasColumnName("HOLIDY_FG");
            this.Property(t => t.HOLIDY_DY).HasColumnName("HOLIDY_DY");
            this.Property(t => t.CYC_BEG).HasColumnName("CYC_BEG");
            this.Property(t => t.CYC_END).HasColumnName("CYC_END");
            this.Property(t => t.DY_IN_BBOM).HasColumnName("DY_IN_BBOM");
            this.Property(t => t.BBOW_FG).HasColumnName("BBOW_FG");
            this.Property(t => t.BEOW_FG).HasColumnName("BEOW_FG");
            this.Property(t => t.BBOM_FG).HasColumnName("BBOM_FG");
            this.Property(t => t.BEOM_FG).HasColumnName("BEOM_FG");
            this.Property(t => t.BBOQ_FG).HasColumnName("BBOQ_FG");
            this.Property(t => t.BEOQ_FG).HasColumnName("BEOQ_FG");
            this.Property(t => t.BBOS_FG).HasColumnName("BBOS_FG");
            this.Property(t => t.BEOS_FG).HasColumnName("BEOS_FG");
            this.Property(t => t.BBOY_FG).HasColumnName("BBOY_FG");
            this.Property(t => t.BEOY_FG).HasColumnName("BEOY_FG");
            this.Property(t => t.EOM_FG).HasColumnName("EOM_FG");
            this.Property(t => t.TBSDT).HasColumnName("TBSDT");
            this.Property(t => t.LBSDT).HasColumnName("LBSDT");
            this.Property(t => t.NBSDT).HasColumnName("NBSDT");
            this.Property(t => t.NNBSDT).HasColumnName("NNBSDT");
            this.Property(t => t.LBSDY).HasColumnName("LBSDY");
            this.Property(t => t.NBSDY).HasColumnName("NBSDY");
            this.Property(t => t.NNBZDY).HasColumnName("NNBZDY");
            this.Property(t => t.DYCNTEOM).HasColumnName("DYCNTEOM");
            this.Property(t => t.NDYCNTTM).HasColumnName("NDYCNTTM");
            this.Property(t => t.L2MNBDT).HasColumnName("L2MNBDT");
            this.Property(t => t.L2MNEDT).HasColumnName("L2MNEDT");
            this.Property(t => t.L2MNEDYS).HasColumnName("L2MNEDYS");
            this.Property(t => t.LMNBDT).HasColumnName("LMNBDT");
            this.Property(t => t.LMNEDT).HasColumnName("LMNEDT");
            this.Property(t => t.LMNDYS).HasColumnName("LMNDYS");
            this.Property(t => t.TMNBDT).HasColumnName("TMNBDT");
            this.Property(t => t.TMNEDT).HasColumnName("TMNEDT");
            this.Property(t => t.TMNDYS).HasColumnName("TMNDYS");
            this.Property(t => t.FNBSDT).HasColumnName("FNBSDT");
            this.Property(t => t.TQBDT).HasColumnName("TQBDT");
            this.Property(t => t.TQEDT).HasColumnName("TQEDT");
            this.Property(t => t.TQDYS).HasColumnName("TQDYS");
            this.Property(t => t.L1QBDT).HasColumnName("L1QBDT");
            this.Property(t => t.L1QEDT).HasColumnName("L1QEDT");
            this.Property(t => t.L1QDYS).HasColumnName("L1QDYS");
            this.Property(t => t.L2QBDT).HasColumnName("L2QBDT");
            this.Property(t => t.L2QEDT).HasColumnName("L2QEDT");
            this.Property(t => t.L2QDYS).HasColumnName("L2QDYS");
            this.Property(t => t.L3QBDT).HasColumnName("L3QBDT");
            this.Property(t => t.L3QEDT).HasColumnName("L3QEDT");
            this.Property(t => t.L3QDYS).HasColumnName("L3QDYS");
            this.Property(t => t.L4QBDT).HasColumnName("L4QBDT");
            this.Property(t => t.L4QEDT).HasColumnName("L4QEDT");
            this.Property(t => t.L4QDYS).HasColumnName("L4QDYS");
            this.Property(t => t.L5QBDT).HasColumnName("L5QBDT");
            this.Property(t => t.L5QEDT).HasColumnName("L5QEDT");
            this.Property(t => t.L5QDYS).HasColumnName("L5QDYS");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
