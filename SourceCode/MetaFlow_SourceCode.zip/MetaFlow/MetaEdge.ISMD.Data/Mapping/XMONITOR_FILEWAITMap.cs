using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XMONITOR_FILEWAITMap : EntityTypeConfiguration<XMONITOR_FILEWAIT>
    {
        public XMONITOR_FILEWAITMap()
        {
            // Primary Key
            this.HasKey(t => t.DATACAT);

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.START_TIME)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.END_TIME)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XMONITOR_FILEWAIT");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.START_TIME).HasColumnName("START_TIME");
            this.Property(t => t.END_TIME).HasColumnName("END_TIME");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
