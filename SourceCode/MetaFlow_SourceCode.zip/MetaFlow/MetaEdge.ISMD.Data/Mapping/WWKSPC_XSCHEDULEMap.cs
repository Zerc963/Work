using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WWKSPC_XSCHEDULEMap : EntityTypeConfiguration<WWKSPC_XSCHEDULE>
    {
        public WWKSPC_XSCHEDULEMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.PROCESS_TYPE, t.START_TIME, t.LST_MAINT_USR });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PROCESS_TYPE)
                .IsRequired()
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.LST_MAINT_USR)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("WWKSPC_XSCHEDULE");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.PROCESS_TYPE).HasColumnName("PROCESS_TYPE");
            this.Property(t => t.START_TIME).HasColumnName("START_TIME");
            this.Property(t => t.END_TIME).HasColumnName("END_TIME");
            this.Property(t => t.INTERVAL).HasColumnName("INTERVAL");
            this.Property(t => t.EFFECTIVE_TIME).HasColumnName("EFFECTIVE_TIME");
            this.Property(t => t.EXPIRATION_TIME).HasColumnName("EXPIRATION_TIME");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
