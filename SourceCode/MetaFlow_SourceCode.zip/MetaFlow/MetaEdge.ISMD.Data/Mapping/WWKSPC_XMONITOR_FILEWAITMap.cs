using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WWKSPC_XMONITOR_FILEWAITMap : EntityTypeConfiguration<WWKSPC_XMONITOR_FILEWAIT>
    {
        public WWKSPC_XMONITOR_FILEWAITMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.LST_MAINT_USR });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.START_TIME)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.END_TIME)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.LST_MAINT_USR)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("WWKSPC_XMONITOR_FILEWAIT");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.START_TIME).HasColumnName("START_TIME");
            this.Property(t => t.END_TIME).HasColumnName("END_TIME");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
