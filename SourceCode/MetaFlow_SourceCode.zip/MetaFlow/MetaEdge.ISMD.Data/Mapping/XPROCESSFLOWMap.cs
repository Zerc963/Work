using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XPROCESSFLOWMap : EntityTypeConfiguration<XPROCESSFLOW>
    {
        public XPROCESSFLOWMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.PROCESS_ID, t.START_TIME });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PROCESS_ID)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.CLEAN_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.EXECUTION_ID)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XPROCESSFLOW");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.PROCESS_ID).HasColumnName("PROCESS_ID");
            this.Property(t => t.START_TIME).HasColumnName("START_TIME");
            this.Property(t => t.CLEAN_FG).HasColumnName("CLEAN_FG");
            this.Property(t => t.EXECUTION_ID).HasColumnName("EXECUTION_ID");
        }
    }
}
