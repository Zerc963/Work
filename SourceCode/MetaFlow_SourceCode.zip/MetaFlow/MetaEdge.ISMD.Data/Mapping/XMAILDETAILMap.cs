using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XMAILDETAILMap : EntityTypeConfiguration<XMAILDETAIL>
    {
        public XMAILDETAILMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.MAIL_TYPE, t.MAILADR });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.MAIL_TYPE)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.MAILADR)
                .IsRequired()
                .HasMaxLength(4000);

            this.Property(t => t.MAIL_DESC)
                .HasMaxLength(100);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XMAILDETAIL");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.MAIL_TYPE).HasColumnName("MAIL_TYPE");
            this.Property(t => t.MAILADR).HasColumnName("MAILADR");
            this.Property(t => t.MAIL_DESC).HasColumnName("MAIL_DESC");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
