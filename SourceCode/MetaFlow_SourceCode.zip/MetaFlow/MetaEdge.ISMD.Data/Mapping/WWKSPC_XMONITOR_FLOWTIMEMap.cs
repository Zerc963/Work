using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WWKSPC_XMONITOR_FLOWTIMEMap : EntityTypeConfiguration<WWKSPC_XMONITOR_FLOWTIME>
    {
        public WWKSPC_XMONITOR_FLOWTIMEMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.LST_MAINT_USR });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.CHK_STATUS)
                .HasMaxLength(7);

            this.Property(t => t.LST_MAINT_USR)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("WWKSPC_XMONITOR_FLOWTIME");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.MAX_DURATION_TIME).HasColumnName("MAX_DURATION_TIME");
            this.Property(t => t.START_TIME).HasColumnName("START_TIME");
            this.Property(t => t.EXPECT_END_TIME).HasColumnName("EXPECT_END_TIME");
            this.Property(t => t.CHK_TIME).HasColumnName("CHK_TIME");
            this.Property(t => t.CHK_STATUS).HasColumnName("CHK_STATUS");
            this.Property(t => t.BATCH_NO).HasColumnName("BATCH_NO");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
