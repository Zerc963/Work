using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class sysssislogMap : EntityTypeConfiguration<sysssislog>
    {
        public sysssislogMap()
        {
            // Primary Key
            this.HasKey(t => t.id);

            // Properties
            this.Property(t => t.@event)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.computer)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.@operator)
                .IsRequired()
                .HasMaxLength(128);

            this.Property(t => t.source)
                .IsRequired()
                .HasMaxLength(1024);

            this.Property(t => t.message)
                .IsRequired()
                .HasMaxLength(2048);

            // Table & Column Mappings
            this.ToTable("sysssislog");
            this.Property(t => t.id).HasColumnName("id");
            this.Property(t => t.@event).HasColumnName("event");
            this.Property(t => t.computer).HasColumnName("computer");
            this.Property(t => t.@operator).HasColumnName("operator");
            this.Property(t => t.source).HasColumnName("source");
            this.Property(t => t.sourceid).HasColumnName("sourceid");
            this.Property(t => t.executionid).HasColumnName("executionid");
            this.Property(t => t.starttime).HasColumnName("starttime");
            this.Property(t => t.endtime).HasColumnName("endtime");
            this.Property(t => t.datacode).HasColumnName("datacode");
            this.Property(t => t.databytes).HasColumnName("databytes");
            this.Property(t => t.message).HasColumnName("message");
        }
    }
}
