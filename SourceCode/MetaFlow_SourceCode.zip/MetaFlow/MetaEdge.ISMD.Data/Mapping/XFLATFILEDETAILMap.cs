using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XFLATFILEDETAILMap : EntityTypeConfiguration<XFLATFILEDETAIL>
    {
        public XFLATFILEDETAILMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.FILE_SEQ });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.FILE_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.FILE_GROUP)
                .HasMaxLength(50);

            this.Property(t => t.CODEPAGE)
                .HasMaxLength(10);

            this.Property(t => t.RAGGED_FIX)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.DELIMITER)
                .HasMaxLength(50);

            this.Property(t => t.TERMINATOR)
                .HasMaxLength(50);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XFLATFILEDETAIL");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.FILE_SEQ).HasColumnName("FILE_SEQ");
            this.Property(t => t.FILE_GROUP).HasColumnName("FILE_GROUP");
            this.Property(t => t.CODEPAGE).HasColumnName("CODEPAGE");
            this.Property(t => t.RAGGED_FIX).HasColumnName("RAGGED_FIX");
            this.Property(t => t.RECORDLEN).HasColumnName("RECORDLEN");
            this.Property(t => t.RAGGEDLEN).HasColumnName("RAGGEDLEN");
            this.Property(t => t.DELIMITER).HasColumnName("DELIMITER");
            this.Property(t => t.TERMINATOR).HasColumnName("TERMINATOR");
            this.Property(t => t.FIRSTROW).HasColumnName("FIRSTROW");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
