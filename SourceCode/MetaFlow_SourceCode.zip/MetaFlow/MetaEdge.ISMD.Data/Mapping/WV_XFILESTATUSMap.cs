using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WV_XFILESTATUSMap : EntityTypeConfiguration<WV_XFILESTATUS>
    {
        public WV_XFILESTATUSMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.FILE_SEQ, t.CHGSRCNAME_FG, t.TOLERANCE_FG, t.TOLERANCE });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PROCESS_TYPE)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.FILE_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.RSEQ)
                .HasMaxLength(10);

            this.Property(t => t.LSEQ)
                .HasMaxLength(10);

            this.Property(t => t.FILENAME)
                .HasMaxLength(50);

            this.Property(t => t.SRCNAME)
                .HasMaxLength(50);

            this.Property(t => t.SRCCNAME)
                .HasMaxLength(100);

            this.Property(t => t.PARENT_FILENAME)
                .HasMaxLength(50);

            this.Property(t => t.SKIP_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.NOT_EXIST_SKIP_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.ABORTCONTINUE_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.FILE_STATUS)
                .IsFixedLength()
                .HasMaxLength(10);

            this.Property(t => t.CURR_SRCNAME)
                .HasMaxLength(50);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            this.Property(t => t.FILE_RUN_TIME)
                .HasMaxLength(100);

            this.Property(t => t.CHGSRCNAME_FG)
                .IsRequired()
                .HasMaxLength(1);

            this.Property(t => t.CHGSRCNAME)
                .HasMaxLength(50);

            this.Property(t => t.TOLERANCE_FG)
                .IsRequired()
                .HasMaxLength(1);

            this.Property(t => t.FILE_AMT_NM)
                .HasMaxLength(50);

            this.Property(t => t.TOLERANCE)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.CHK_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.UNZIP_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.CRT_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            // Table & Column Mappings
            this.ToTable("WV_XFILESTATUS");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.BATCH_NO).HasColumnName("BATCH_NO");
            this.Property(t => t.CYCLE_START).HasColumnName("CYCLE_START");
            this.Property(t => t.CYCLE_END).HasColumnName("CYCLE_END");
            this.Property(t => t.PROCESS_TYPE).HasColumnName("PROCESS_TYPE");
            this.Property(t => t.FILE_SEQ).HasColumnName("FILE_SEQ");
            this.Property(t => t.RSEQ).HasColumnName("RSEQ");
            this.Property(t => t.LSEQ).HasColumnName("LSEQ");
            this.Property(t => t.FILENAME).HasColumnName("FILENAME");
            this.Property(t => t.SRCNAME).HasColumnName("SRCNAME");
            this.Property(t => t.SRCCNAME).HasColumnName("SRCCNAME");
            this.Property(t => t.PARENT_FILENAME).HasColumnName("PARENT_FILENAME");
            this.Property(t => t.SKIP_FLAG).HasColumnName("SKIP_FLAG");
            this.Property(t => t.NOT_EXIST_SKIP_FG).HasColumnName("NOT_EXIST_SKIP_FG");
            this.Property(t => t.ABORTCONTINUE_FLAG).HasColumnName("ABORTCONTINUE_FLAG");
            this.Property(t => t.FILE_STATUS).HasColumnName("FILE_STATUS");
            this.Property(t => t.FILE_START_TIME).HasColumnName("FILE_START_TIME");
            this.Property(t => t.FILE_END_TIME).HasColumnName("FILE_END_TIME");
            this.Property(t => t.FILE_DESC).HasColumnName("FILE_DESC");
            this.Property(t => t.CURR_SRCNAME).HasColumnName("CURR_SRCNAME");
            this.Property(t => t.FILESIZE).HasColumnName("FILESIZE");
            this.Property(t => t.FILEDATE).HasColumnName("FILEDATE");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
            this.Property(t => t.FILE_RUN_TIME).HasColumnName("FILE_RUN_TIME");
            this.Property(t => t.FILE_SECOND).HasColumnName("FILE_SECOND");
            this.Property(t => t.CHGSRCNAME_FG).HasColumnName("CHGSRCNAME_FG");
            this.Property(t => t.CHGSRCNAME).HasColumnName("CHGSRCNAME");
            this.Property(t => t.TOLERANCE_FG).HasColumnName("TOLERANCE_FG");
            this.Property(t => t.FILE_AMT_NM).HasColumnName("FILE_AMT_NM");
            this.Property(t => t.TOLERANCE).HasColumnName("TOLERANCE");
            this.Property(t => t.CHK_FG).HasColumnName("CHK_FG");
            this.Property(t => t.UNZIP_FG).HasColumnName("UNZIP_FG");
            this.Property(t => t.CRT_FG).HasColumnName("CRT_FG");
        }
    }
}
