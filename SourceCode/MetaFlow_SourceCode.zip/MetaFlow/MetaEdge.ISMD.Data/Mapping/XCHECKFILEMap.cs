using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XCHECKFILEMap : EntityTypeConfiguration<XCHECKFILE>
    {
        public XCHECKFILEMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.CYCLEDATE, t.FILENAME });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.SRCDATE)
                .IsFixedLength()
                .HasMaxLength(8);

            this.Property(t => t.FILENAME)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.SRCNAME)
                .HasMaxLength(50);

            this.Property(t => t.FILE_AMT_NM)
                .HasMaxLength(50);

            this.Property(t => t.SRC_AMT_NM)
                .HasMaxLength(50);

            this.Property(t => t.CHECK_STATUS)
                .IsFixedLength()
                .HasMaxLength(7);

            this.Property(t => t.ORGDATASRC)
                .HasMaxLength(50);

            // Table & Column Mappings
            this.ToTable("XCHECKFILE");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.CYCLEDATE).HasColumnName("CYCLEDATE");
            this.Property(t => t.SRCDATE).HasColumnName("SRCDATE");
            this.Property(t => t.FILENAME).HasColumnName("FILENAME");
            this.Property(t => t.SRCNAME).HasColumnName("SRCNAME");
            this.Property(t => t.SRC_CNT).HasColumnName("SRC_CNT");
            this.Property(t => t.FILE_AMT_NM).HasColumnName("FILE_AMT_NM");
            this.Property(t => t.SRC_AMT_NM).HasColumnName("SRC_AMT_NM");
            this.Property(t => t.SRC_AMT).HasColumnName("SRC_AMT");
            this.Property(t => t.INS_CNT).HasColumnName("INS_CNT");
            this.Property(t => t.INS_AMT).HasColumnName("INS_AMT");
            this.Property(t => t.TOLERANCE).HasColumnName("TOLERANCE");
            this.Property(t => t.CHECK_STATUS).HasColumnName("CHECK_STATUS");
            this.Property(t => t.ORGDATASRC).HasColumnName("ORGDATASRC");
        }
    }
}
