using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WWKSPC_XFILEDETAILMap : EntityTypeConfiguration<WWKSPC_XFILEDETAIL>
    {
        public WWKSPC_XFILEDETAILMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.FILE_SEQ, t.LST_MAINT_USR });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PROCESS_TYPE)
                .IsFixedLength()
                .HasMaxLength(4);

            this.Property(t => t.FILE_SEQ)
                .HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.Property(t => t.RSEQ)
                .HasMaxLength(10);

            this.Property(t => t.LSEQ)
                .HasMaxLength(10);

            this.Property(t => t.FILENAME)
                .HasMaxLength(50);

            this.Property(t => t.SRCNAME)
                .HasMaxLength(50);

            this.Property(t => t.SRCCNAME)
                .HasMaxLength(100);

            this.Property(t => t.PARENT_FILENAME)
                .HasMaxLength(50);

            this.Property(t => t.SKIP_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.NOT_EXIST_SKIP_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.ABORTCONTINUE_FLAG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.CRT_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.CHK_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.UNZIP_FG)
                .IsFixedLength()
                .HasMaxLength(1);

            this.Property(t => t.ZIP_PW)
                .HasMaxLength(100);

            this.Property(t => t.FILE_AMT_NM)
                .HasMaxLength(50);

            this.Property(t => t.LST_MAINT_USR)
                .IsRequired()
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("WWKSPC_XFILEDETAIL");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.PROCESS_TYPE).HasColumnName("PROCESS_TYPE");
            this.Property(t => t.FILE_SEQ).HasColumnName("FILE_SEQ");
            this.Property(t => t.RSEQ).HasColumnName("RSEQ");
            this.Property(t => t.LSEQ).HasColumnName("LSEQ");
            this.Property(t => t.FILENAME).HasColumnName("FILENAME");
            this.Property(t => t.SRCNAME).HasColumnName("SRCNAME");
            this.Property(t => t.SRCCNAME).HasColumnName("SRCCNAME");
            this.Property(t => t.PARENT_FILENAME).HasColumnName("PARENT_FILENAME");
            this.Property(t => t.SKIP_FLAG).HasColumnName("SKIP_FLAG");
            this.Property(t => t.NOT_EXIST_SKIP_FG).HasColumnName("NOT_EXIST_SKIP_FG");
            this.Property(t => t.ABORTCONTINUE_FLAG).HasColumnName("ABORTCONTINUE_FLAG");
            this.Property(t => t.CRT_FG).HasColumnName("CRT_FG");
            this.Property(t => t.CHK_FG).HasColumnName("CHK_FG");
            this.Property(t => t.UNZIP_FG).HasColumnName("UNZIP_FG");
            this.Property(t => t.ZIP_PW).HasColumnName("ZIP_PW");
            this.Property(t => t.FILE_AMT_NM).HasColumnName("FILE_AMT_NM");
            this.Property(t => t.TOLERANCE).HasColumnName("TOLERANCE");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
