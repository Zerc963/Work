using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XSERVERDETAILMap : EntityTypeConfiguration<XSERVERDETAIL>
    {
        public XSERVERDETAILMap()
        {
            // Primary Key
            this.HasKey(t => new { t.SERVERTYPE, t.SERVERNM, t.USERCODE });

            // Properties
            this.Property(t => t.SERVERTYPE)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.SERVERNM)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.USERCODE)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.PW)
                .HasMaxLength(100);

            this.Property(t => t.PORT)
                .IsFixedLength()
                .HasMaxLength(5);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XSERVERDETAIL");
            this.Property(t => t.SERVERTYPE).HasColumnName("SERVERTYPE");
            this.Property(t => t.SERVERNM).HasColumnName("SERVERNM");
            this.Property(t => t.USERCODE).HasColumnName("USERCODE");
            this.Property(t => t.PW).HasColumnName("PW");
            this.Property(t => t.PORT).HasColumnName("PORT");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
