using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class XREMOTEDETAILMap : EntityTypeConfiguration<XREMOTEDETAIL>
    {
        public XREMOTEDETAILMap()
        {
            // Primary Key
            this.HasKey(t => new { t.DATACAT, t.RSEQ });

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.RSEQ)
                .IsRequired()
                .HasMaxLength(10);

            this.Property(t => t.SERVERTYPE)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.SERVERNM)
                .IsRequired()
                .HasMaxLength(50);

            this.Property(t => t.USERCODE)
                .HasMaxLength(100);

            this.Property(t => t.REMOTE_PATH)
                .HasMaxLength(200);

            this.Property(t => t.LST_MAINT_USR)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("XREMOTEDETAIL");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.RSEQ).HasColumnName("RSEQ");
            this.Property(t => t.SERVERTYPE).HasColumnName("SERVERTYPE");
            this.Property(t => t.SERVERNM).HasColumnName("SERVERNM");
            this.Property(t => t.USERCODE).HasColumnName("USERCODE");
            this.Property(t => t.REMOTE_PATH).HasColumnName("REMOTE_PATH");
            this.Property(t => t.LST_MAINT_USR).HasColumnName("LST_MAINT_USR");
            this.Property(t => t.LST_MAINT_DT).HasColumnName("LST_MAINT_DT");
        }
    }
}
