using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace MetaEdge.ISMD.Entity.Models.Mapping
{
    public class WV_XFLOWDETAILMap : EntityTypeConfiguration<WV_XFLOWDETAIL>
    {
        public WV_XFLOWDETAILMap()
        {
            // Primary Key
            this.HasKey(t => t.DATACAT);

            // Properties
            this.Property(t => t.DATACAT)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.DATACATNM)
                .HasMaxLength(100);

            this.Property(t => t.RUN_STATUS)
                .IsFixedLength()
                .HasMaxLength(7);

            // Table & Column Mappings
            this.ToTable("WV_XFLOWDETAIL");
            this.Property(t => t.DATACAT).HasColumnName("DATACAT");
            this.Property(t => t.DATACATNM).HasColumnName("DATACATNM");
            this.Property(t => t.CYCLE_DATE).HasColumnName("CYCLE_DATE");
            this.Property(t => t.RUN_STATUS).HasColumnName("RUN_STATUS");
            this.Property(t => t.AGENT_MODE).HasColumnName("AGENT_MODE");
            this.Property(t => t.START_TIME).HasColumnName("START_TIME");
            this.Property(t => t.END_TIME).HasColumnName("END_TIME");
            this.Property(t => t.NEXT_TIME).HasColumnName("NEXT_TIME");
        }
    }
}
