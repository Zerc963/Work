﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Data.Entity;
using System.Collections.Generic;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XLOCALDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XLOCALDETAIL> Get()
        {
            return db.WWKSPC_XLOCALDETAIL;
        }

        [Queryable]
        public IQueryable<WWKSPC_XLOCALDETAIL> Get([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            return db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
        }

        // POST odata/WWKSPC_XLOCALDETAIL
        public async Task<IHttpActionResult> Post(WWKSPC_XLOCALDETAIL WWKSPC_XLOCALDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WWKSPC_XLOCALDETAIL.Add(WWKSPC_XLOCALDETAIL);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (WWKSPC_XLOCALDETAILExists(WWKSPC_XLOCALDETAIL.DATACAT, WWKSPC_XLOCALDETAIL.LSEQ, WWKSPC_XLOCALDETAIL.LST_MAINT_USR))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XLOCALDETAIL);
        }

        // PUT odata/WWKSPC_XLOCALDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]string LSEQ, [FromODataUri] string LST_MAINT_USR, WWKSPC_XLOCALDETAIL WWKSPC_XLOCALDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == DATACAT && o.LSEQ == LSEQ && o.LST_MAINT_USR == LST_MAINT_USR);

            if (result.Count() == 0)
            {
                return NotFound();
            }
            else
            {
                db.WWKSPC_XLOCALDETAIL.RemoveRange(result);
                db.WWKSPC_XLOCALDETAIL.Add(WWKSPC_XLOCALDETAIL);

                // 同步更新 WWKSPC_XWAITDETAIL 有設定相關 LSEQ 的資料
                var waitDetail = db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.LSEQ == LSEQ && o.LST_MAINT_USR == LST_MAINT_USR);
                foreach (WWKSPC_XWAITDETAIL wait in waitDetail)
                {
                    wait.LSEQ = WWKSPC_XLOCALDETAIL.LSEQ;
                    wait.LST_MAINT_USR = WWKSPC_XLOCALDETAIL.LST_MAINT_USR;
                    wait.LST_MAINT_DT = DateTime.Now;
                    db.Entry(wait).State = EntityState.Modified;
                }

                // 同步更新 WWKSPC_XFILEDETAIL 有設定相關 LSEQ 的資料
                var fileDetail = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LSEQ == LSEQ && o.LST_MAINT_USR == LST_MAINT_USR);
                foreach (WWKSPC_XFILEDETAIL file in fileDetail)
                {
                    file.LSEQ = WWKSPC_XLOCALDETAIL.LSEQ;
                    file.LST_MAINT_USR = WWKSPC_XLOCALDETAIL.LST_MAINT_USR;
                    file.LST_MAINT_DT = DateTime.Now;
                    db.Entry(file).State = EntityState.Modified;
                }

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WWKSPC_XLOCALDETAILExists(DATACAT, LSEQ, LST_MAINT_USR))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return Updated(WWKSPC_XLOCALDETAIL);
            }
        }

        private bool WWKSPC_XLOCALDETAILExists(string DATACAT, string LSEQ, string LST_MAINT_USR)
        {
            return db.WWKSPC_XLOCALDETAIL.Count(o => o.DATACAT == DATACAT && o.LSEQ == LSEQ && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
