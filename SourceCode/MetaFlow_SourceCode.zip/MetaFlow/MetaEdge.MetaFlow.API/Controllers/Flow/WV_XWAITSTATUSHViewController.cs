﻿using MetaEdge.Data;
using MetaEdge.ISMD.Entity.Models;
using MetaEdge.MetaAuthWeb.Data.Models;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WV_XWAITSTATUSHViewController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<WV_XWAITSTATUSView> Get()
        {
            List<WV_XWAITSTATUSView> list = new List<WV_XWAITSTATUSView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            var resultSet = db.WV_XWAITSTATUSH;

            foreach (var item in resultSet)
            {
                WV_XWAITSTATUSView wait = new WV_XWAITSTATUSView();

                wait.DATACAT = item.DATACAT;
                wait.BATCH_NO = item.BATCH_NO;
                wait.CYCLE_START = item.CYCLE_START;
                wait.CYCLE_END = item.CYCLE_END;
                wait.PROCESS_TYPE = item.PROCESS_TYPE;

                if (!string.IsNullOrEmpty(item.PROCESS_TYPE))
                {
                    var PROCESS_TYPENM = parameters.Where(o => o.TypeName == "FLOW_TYPE" && o.ParameterValue == item.PROCESS_TYPE.Trim()).ToList();
                    if (PROCESS_TYPENM.Count() > 0)
                    {
                        wait.PROCESS_TYPENM = PROCESS_TYPENM.First().ParameterName;
                    }
                }

                wait.WAIT_SEQ = item.WAIT_SEQ;
                wait.WAIT_TYPE = item.WAIT_TYPE;

                if (!string.IsNullOrEmpty(item.WAIT_TYPE))
                {
                    var WAIT_TYPENM = parameters.Where(o => o.TypeName == "WAIT_TYPE" && o.ParameterValue == item.WAIT_TYPE.Trim()).ToList();
                    if (WAIT_TYPENM.Count() > 0)
                    {
                        wait.WAIT_TYPENM = WAIT_TYPENM.First().ParameterName;
                    }
                }

                wait.RSEQ = item.RSEQ;
                wait.LSEQ = item.LSEQ;
                wait.WAIT_NAME = item.WAIT_NAME;
                wait.CHK_FG = item.CHK_FG;
                wait.CHK_FILEDATE_FG = item.CHK_FILEDATE_FG;
                wait.TOLERANCE = item.TOLERANCE;
                wait.WAIT_SKIP_FLAG = item.WAIT_SKIP_FLAG;

                if (!string.IsNullOrEmpty(item.WAIT_SKIP_FLAG))
                {
                    var WAIT_SKIP_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.WAIT_SKIP_FLAG.Trim()).ToList();
                    if (WAIT_SKIP_FLAGNM.Count() > 0)
                    {
                        wait.WAIT_SKIP_FLAGNM = WAIT_SKIP_FLAGNM.First().ParameterName;
                    }
                }

                wait.NOT_EXIST_SKIP_FG = item.NOT_EXIST_SKIP_FG;
                wait.WAIT_STATUS = item.WAIT_STATUS;

                if (!string.IsNullOrEmpty(item.WAIT_STATUS))
                {
                    var WAIT_STATUSNM = parameters.Where(o => o.TypeName == "WAIT_STATUS" && o.ParameterValue == item.WAIT_STATUS.Trim()).ToList();
                    if (WAIT_STATUSNM.Count() > 0)
                    {
                        wait.WAIT_STATUSNM = WAIT_STATUSNM.First().ParameterName;
                    }
                }

                wait.WAIT_START_TIME = item.WAIT_START_TIME;
                wait.WAIT_END_TIME = item.WAIT_END_TIME;
                wait.WAIT_DESC = item.WAIT_DESC;
                wait.FILEDATE = item.FILEDATE;
                wait.LST_MAINT_USR = item.LST_MAINT_USR;
                wait.LST_MAINT_DT = item.LST_MAINT_DT;

                list.Add(wait);
            }

            return list.AsQueryable();
        }

        [Queryable]
        public IQueryable<WV_XWAITSTATUSView> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO)
        {
            List<WV_XWAITSTATUSView> list = new List<WV_XWAITSTATUSView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            long batchNo = long.Parse(BATCH_NO);
            var resultSet = db.WV_XWAITSTATUSH.Where(o => o.DATACAT == DATACAT && o.BATCH_NO == batchNo);

            foreach (var item in resultSet)
            {
                WV_XWAITSTATUSView wait = new WV_XWAITSTATUSView();

                wait.DATACAT = item.DATACAT;
                wait.BATCH_NO = item.BATCH_NO;
                wait.CYCLE_START = item.CYCLE_START;
                wait.CYCLE_END = item.CYCLE_END;
                wait.PROCESS_TYPE = item.PROCESS_TYPE;

                if (!string.IsNullOrEmpty(item.PROCESS_TYPE))
                {
                    var PROCESS_TYPENM = parameters.Where(o => o.TypeName == "FLOW_TYPE" && o.ParameterValue == item.PROCESS_TYPE.Trim()).ToList();
                    if (PROCESS_TYPENM.Count() > 0)
                    {
                        wait.PROCESS_TYPENM = PROCESS_TYPENM.First().ParameterName;
                    }
                }

                wait.WAIT_SEQ = item.WAIT_SEQ;
                wait.WAIT_TYPE = item.WAIT_TYPE;

                if (!string.IsNullOrEmpty(item.WAIT_TYPE))
                {
                    var WAIT_TYPENM = parameters.Where(o => o.TypeName == "WAIT_TYPE" && o.ParameterValue == item.WAIT_TYPE.Trim()).ToList();
                    if (WAIT_TYPENM.Count() > 0)
                    {
                        wait.WAIT_TYPENM = WAIT_TYPENM.First().ParameterName;
                    }
                }

                wait.RSEQ = item.RSEQ;
                wait.LSEQ = item.LSEQ;
                wait.WAIT_NAME = item.WAIT_NAME;
                wait.CHK_FG = item.CHK_FG;
                wait.CHK_FILEDATE_FG = item.CHK_FILEDATE_FG;
                wait.TOLERANCE = item.TOLERANCE;
                wait.WAIT_SKIP_FLAG = item.WAIT_SKIP_FLAG;

                if (!string.IsNullOrEmpty(item.WAIT_SKIP_FLAG))
                {
                    var WAIT_SKIP_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.WAIT_SKIP_FLAG.Trim()).ToList();
                    if (WAIT_SKIP_FLAGNM.Count() > 0)
                    {
                        wait.WAIT_SKIP_FLAGNM = WAIT_SKIP_FLAGNM.First().ParameterName;
                    }
                }

                wait.NOT_EXIST_SKIP_FG = item.NOT_EXIST_SKIP_FG;
                wait.WAIT_STATUS = item.WAIT_STATUS;

                if (!string.IsNullOrEmpty(item.WAIT_STATUS))
                {
                    var WAIT_STATUSNM = parameters.Where(o => o.TypeName == "WAIT_STATUS" && o.ParameterValue == item.WAIT_STATUS.Trim()).ToList();
                    if (WAIT_STATUSNM.Count() > 0)
                    {
                        wait.WAIT_STATUSNM = WAIT_STATUSNM.First().ParameterName;
                    }
                }

                wait.WAIT_START_TIME = item.WAIT_START_TIME;
                wait.WAIT_END_TIME = item.WAIT_END_TIME;
                wait.WAIT_DESC = item.WAIT_DESC;
                wait.FILEDATE = item.FILEDATE;
                wait.LST_MAINT_USR = item.LST_MAINT_USR;
                wait.LST_MAINT_DT = item.LST_MAINT_DT;

                list.Add(wait);
            }

            return list.AsQueryable();
        }

        [Queryable]
        public IQueryable<WV_XWAITSTATUSView> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO, [FromODataUri]int WAIT_SEQ)
        {
            List<WV_XWAITSTATUSView> list = new List<WV_XWAITSTATUSView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            long batchNo = long.Parse(BATCH_NO);
            var resultSet = db.WV_XWAITSTATUSH.Where(o => o.DATACAT == DATACAT && o.BATCH_NO == batchNo && o.WAIT_SEQ == WAIT_SEQ);

            foreach (var item in resultSet)
            {
                WV_XWAITSTATUSView wait = new WV_XWAITSTATUSView();

                wait.DATACAT = item.DATACAT;
                wait.BATCH_NO = item.BATCH_NO;
                wait.CYCLE_START = item.CYCLE_START;
                wait.CYCLE_END = item.CYCLE_END;
                wait.PROCESS_TYPE = item.PROCESS_TYPE;

                if (!string.IsNullOrEmpty(item.PROCESS_TYPE))
                {
                    var PROCESS_TYPENM = parameters.Where(o => o.TypeName == "FLOW_TYPE" && o.ParameterValue == item.PROCESS_TYPE.Trim()).ToList();
                    if (PROCESS_TYPENM.Count() > 0)
                    {
                        wait.PROCESS_TYPENM = PROCESS_TYPENM.First().ParameterName;
                    }
                }

                wait.WAIT_SEQ = item.WAIT_SEQ;
                wait.WAIT_TYPE = item.WAIT_TYPE;

                if (!string.IsNullOrEmpty(item.WAIT_TYPE))
                {
                    var WAIT_TYPENM = parameters.Where(o => o.TypeName == "WAIT_TYPE" && o.ParameterValue == item.WAIT_TYPE.Trim()).ToList();
                    if (WAIT_TYPENM.Count() > 0)
                    {
                        wait.WAIT_TYPENM = WAIT_TYPENM.First().ParameterName;
                    }
                }

                wait.RSEQ = item.RSEQ;
                wait.LSEQ = item.LSEQ;
                wait.WAIT_NAME = item.WAIT_NAME;
                wait.CHK_FG = item.CHK_FG;
                wait.CHK_FILEDATE_FG = item.CHK_FILEDATE_FG;
                wait.TOLERANCE = item.TOLERANCE;
                wait.WAIT_SKIP_FLAG = item.WAIT_SKIP_FLAG;

                if (!string.IsNullOrEmpty(item.WAIT_SKIP_FLAG))
                {
                    var WAIT_SKIP_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.WAIT_SKIP_FLAG.Trim()).ToList();
                    if (WAIT_SKIP_FLAGNM.Count() > 0)
                    {
                        wait.WAIT_SKIP_FLAGNM = WAIT_SKIP_FLAGNM.First().ParameterName;
                    }
                }

                wait.NOT_EXIST_SKIP_FG = item.NOT_EXIST_SKIP_FG;
                wait.WAIT_STATUS = item.WAIT_STATUS;

                if (!string.IsNullOrEmpty(item.WAIT_STATUS))
                {
                    var WAIT_STATUSNM = parameters.Where(o => o.TypeName == "WAIT_STATUS" && o.ParameterValue == item.WAIT_STATUS.Trim()).ToList();
                    if (WAIT_STATUSNM.Count() > 0)
                    {
                        wait.WAIT_STATUSNM = WAIT_STATUSNM.First().ParameterName;
                    }
                }

                wait.WAIT_START_TIME = item.WAIT_START_TIME;
                wait.WAIT_END_TIME = item.WAIT_END_TIME;
                wait.WAIT_DESC = item.WAIT_DESC;
                wait.FILEDATE = item.FILEDATE;
                wait.LST_MAINT_USR = item.LST_MAINT_USR;
                wait.LST_MAINT_DT = item.LST_MAINT_DT;

                list.Add(wait);
            }

            return list.AsQueryable();
        }
    }
}
