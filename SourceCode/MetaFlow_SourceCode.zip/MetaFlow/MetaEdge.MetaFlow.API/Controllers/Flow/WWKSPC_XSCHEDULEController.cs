﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Data.Entity;
using System.Collections.Generic;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XSCHEDULEController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XSCHEDULE> Get()
        {
            return db.WWKSPC_XSCHEDULE;
        }

        [Queryable]
        public IQueryable<WWKSPC_XSCHEDULE> Get([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            return db.WWKSPC_XSCHEDULE.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
        }

        // POST odata/WWKSPC_XSCHEDULE
        public async Task<IHttpActionResult> Post(WWKSPC_XSCHEDULE WWKSPC_XSCHEDULE)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WWKSPC_XSCHEDULE.Add(WWKSPC_XSCHEDULE);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (WWKSPC_XSCHEDULEExists(WWKSPC_XSCHEDULE.DATACAT, WWKSPC_XSCHEDULE.PROCESS_TYPE, WWKSPC_XSCHEDULE.START_TIME, WWKSPC_XSCHEDULE.LST_MAINT_USR))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XSCHEDULE);
        }

        // PUT odata/WWKSPC_XSCHEDULE
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]string PROCESS_TYPE, [FromODataUri]int START_TIME_HOUR, [FromODataUri]int START_TIME_MINUTE, [FromODataUri] string LST_MAINT_USR, WWKSPC_XSCHEDULE WWKSPC_XSCHEDULE)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            TimeSpan START_TIME = new TimeSpan(START_TIME_HOUR, START_TIME_MINUTE, 0);

            var result = db.WWKSPC_XSCHEDULE.Where(o => o.DATACAT == DATACAT && o.PROCESS_TYPE == PROCESS_TYPE && o.START_TIME == START_TIME && o.LST_MAINT_USR == LST_MAINT_USR);

            if (result.Count() == 0)
            {
                return NotFound();
            }
            else
            {
                db.WWKSPC_XSCHEDULE.RemoveRange(result);
                db.WWKSPC_XSCHEDULE.Add(WWKSPC_XSCHEDULE);

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WWKSPC_XSCHEDULEExists(DATACAT, PROCESS_TYPE, START_TIME, LST_MAINT_USR))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return Updated(WWKSPC_XSCHEDULE);
            }
        }

        private bool WWKSPC_XSCHEDULEExists(string DATACAT, string PROCESS_TYPE, TimeSpan START_TIME, string LST_MAINT_USR)
        {
            return db.WWKSPC_XSCHEDULE.Count(o => o.DATACAT == DATACAT && o.PROCESS_TYPE == PROCESS_TYPE && o.START_TIME == START_TIME && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
