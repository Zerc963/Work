﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class sysssislogController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<sysssislog> Get()
        {
            return db.sysssislog;
        }

        [Queryable]
        public IEnumerable<sysssislog> Get([FromODataUri]string DATACAT, [FromODataUri]string EVENT, [FromODataUri]string SOURCE, [FromODataUri]string Start_Time, [FromODataUri]string End_Time)
        {
            SqlParameter[] SqlParam = new SqlParameter[5];
            SqlParam[0] = new SqlParameter("@DATACAT", DATACAT);
            SqlParam[1] = new SqlParameter("@EVENT", EVENT);
            SqlParam[2] = new SqlParameter("@SOURCE", SOURCE);
            SqlParam[3] = new SqlParameter("@START_TIME", Start_Time.Replace("T", " "));
            SqlParam[4] = new SqlParameter("@END_TIME", End_Time.Replace("T", " "));

            StringBuilder sbCmd = new StringBuilder();
            sbCmd.Append(@"
                              declare @pC_EVENT as varchar(255);
                              declare @pC_SOURCE as varchar(255);

                              set @pC_EVENT = replace(('%' + isnull(@EVENT,'') + '%'),'_','/_');
                              set @pC_SOURCE = replace(('%' + isnull(@SOURCE,'') + '%'),'_','/_');

                           select *
                             from sysssislog
                            where executionid in (
                                    select replace(replace(execution_id,'{',''),'}','') from dbo.XBATCHFLOW
                                    where DATACAT = @DATACAT)");

            if (!string.IsNullOrEmpty(EVENT))
            {
                sbCmd.Append(" and [event] like @pC_EVENT escape '/'");
            }

            if (!string.IsNullOrEmpty(SOURCE))
            {
                sbCmd.Append(" and [source] like @pC_SOURCE escape '/'");
            }

            if (!string.IsNullOrEmpty(Start_Time))
            {
                sbCmd.Append(" and [starttime] >= @START_TIME");
            }

            if (!string.IsNullOrEmpty(End_Time))
            {
                sbCmd.Append(" and [starttime] <= @END_TIME");
            }

            return db.Database.SqlQuery<sysssislog>(sbCmd.ToString(), SqlParam);
        }

        [Queryable]
        public IEnumerable<sysssislog> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO, [FromODataUri]string EVENT, [FromODataUri]string SOURCE, [FromODataUri]string Start_Time, [FromODataUri]string End_Time)
        {
            SqlParameter[] SqlParam = new SqlParameter[2];
            SqlParam[0] = new SqlParameter("@DATACAT", DATACAT);
            SqlParam[1] = new SqlParameter("@BATCH_NO", BATCH_NO);

            string sqlcmd = @"select * from sysssislog
                               where executionid in (
                                          select replace(replace(execution_id,'{',''),'}','') from dbo.XBATCHFLOWH
                                          where DATACAT = @DATACAT and BATCH_NO = @BATCH_NO)";

            return db.Database.SqlQuery<sysssislog>(sqlcmd, SqlParam);
        }



    }
}
