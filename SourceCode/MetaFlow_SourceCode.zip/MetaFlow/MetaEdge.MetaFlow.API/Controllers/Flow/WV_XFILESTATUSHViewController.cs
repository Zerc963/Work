﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using MetaEdge.Data;
using Newtonsoft.Json.Linq;
using MetaEdge.MetaAuthWeb.Data.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WV_XFILESTATUSHViewController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<WV_XFILESTATUSView> Get()
        {
            List<WV_XFILESTATUSView> list = new List<WV_XFILESTATUSView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            var resultSet = db.WV_XFILESTATUSH;

            foreach (var item in resultSet)
            {
                WV_XFILESTATUSView file = new WV_XFILESTATUSView();

                file.DATACAT = item.DATACAT;
                file.BATCH_NO = item.BATCH_NO;
                file.CYCLE_START = item.CYCLE_START;
                file.CYCLE_END = item.CYCLE_END;
                file.PROCESS_TYPE = item.PROCESS_TYPE;

                if (!string.IsNullOrEmpty(item.PROCESS_TYPE))
                {
                    var PROCESS_TYPENM = parameters.Where(o => o.TypeName == "FLOW_TYPE" && o.ParameterValue == item.PROCESS_TYPE.Trim()).ToList();
                    if (PROCESS_TYPENM.Count() > 0)
                    {
                        file.PROCESS_TYPENM = PROCESS_TYPENM.First().ParameterName;
                    }
                }

                file.FILE_SEQ = item.FILE_SEQ;
                file.RSEQ = item.RSEQ;
                file.LSEQ = item.LSEQ;
                file.FILENAME = item.FILENAME;
                file.SRCNAME = item.SRCNAME;
                file.SRCCNAME = item.SRCCNAME;
                file.PARENT_FILENAME = item.PARENT_FILENAME;
                file.SKIP_FLAG = item.SKIP_FLAG;

                if (!string.IsNullOrEmpty(item.SKIP_FLAG))
                {
                    var SKIP_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.SKIP_FLAG.Trim()).ToList();
                    if (SKIP_FLAGNM.Count() > 0)
                    {
                        file.SKIP_FLAGNM = SKIP_FLAGNM.First().ParameterName;
                    }
                }

                file.NOT_EXIST_SKIP_FG = item.NOT_EXIST_SKIP_FG;
                file.ABORTCONTINUE_FLAG = item.ABORTCONTINUE_FLAG;
                file.FILE_STATUS = item.FILE_STATUS;
                file.FILE_START_TIME = item.FILE_START_TIME;
                file.FILE_END_TIME = item.FILE_END_TIME;
                file.FILE_DESC = item.FILE_DESC;
                file.CURR_SRCNAME = item.CURR_SRCNAME;
                file.FILESIZE = item.FILESIZE;
                file.FILEDATE = item.FILEDATE;
                file.LST_MAINT_USR = item.LST_MAINT_USR;
                file.LST_MAINT_DT = item.LST_MAINT_DT;
                file.FILE_RUN_TIME = item.FILE_RUN_TIME;
                file.CHGSRCNAME_FG = item.CHGSRCNAME_FG;
                file.CHGSRCNAME = item.CHGSRCNAME;
                file.TOLERANCE_FG = item.TOLERANCE_FG;
                file.FILE_AMT_NM = item.FILE_AMT_NM;
                file.TOLERANCE = item.TOLERANCE;
                file.CHK_FG = item.CHK_FG;
                file.UNZIP_FG = item.UNZIP_FG;
                file.CRT_FG = item.CRT_FG;

                list.Add(file);
            }

            return list.AsQueryable();
        }

        [Queryable]
        public IQueryable<WV_XFILESTATUSView> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO)
        {
            List<WV_XFILESTATUSView> list = new List<WV_XFILESTATUSView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            long batchNo = long.Parse(BATCH_NO);
            var resultSet = db.WV_XFILESTATUSH.Where(o => o.DATACAT == DATACAT).Where(o => o.BATCH_NO == batchNo);

            foreach (var item in resultSet)
            {
                WV_XFILESTATUSView file = new WV_XFILESTATUSView();

                file.DATACAT = item.DATACAT;
                file.BATCH_NO = item.BATCH_NO;
                file.CYCLE_START = item.CYCLE_START;
                file.CYCLE_END = item.CYCLE_END;
                file.PROCESS_TYPE = item.PROCESS_TYPE;

                if (!string.IsNullOrEmpty(item.SKIP_FLAG))
                {
                    var PROCESS_TYPENM = parameters.Where(o => o.TypeName == "FLOW_TYPE" && o.ParameterValue == item.PROCESS_TYPE.Trim()).ToList();
                    if (PROCESS_TYPENM.Count() > 0)
                    {
                        file.PROCESS_TYPENM = PROCESS_TYPENM.First().ParameterName;
                    }
                }

                file.FILE_SEQ = item.FILE_SEQ;
                file.RSEQ = item.RSEQ;
                file.LSEQ = item.LSEQ;
                file.FILENAME = item.FILENAME;
                file.SRCNAME = item.SRCNAME;
                file.SRCCNAME = item.SRCCNAME;
                file.PARENT_FILENAME = item.PARENT_FILENAME;
                file.SKIP_FLAG = item.SKIP_FLAG;

                if (!string.IsNullOrEmpty(item.SKIP_FLAG))
                {
                    var SKIP_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.SKIP_FLAG.Trim()).ToList();
                    if (SKIP_FLAGNM.Count() > 0)
                    {
                        file.SKIP_FLAGNM = SKIP_FLAGNM.First().ParameterName;
                    }
                }

                file.NOT_EXIST_SKIP_FG = item.NOT_EXIST_SKIP_FG;
                file.ABORTCONTINUE_FLAG = item.ABORTCONTINUE_FLAG;
                file.FILE_STATUS = item.FILE_STATUS;
                file.FILE_START_TIME = item.FILE_START_TIME;
                file.FILE_END_TIME = item.FILE_END_TIME;
                file.FILE_DESC = item.FILE_DESC;
                file.CURR_SRCNAME = item.CURR_SRCNAME;
                file.FILESIZE = item.FILESIZE;
                file.FILEDATE = item.FILEDATE;
                file.LST_MAINT_USR = item.LST_MAINT_USR;
                file.LST_MAINT_DT = item.LST_MAINT_DT;
                file.FILE_RUN_TIME = item.FILE_RUN_TIME;
                file.CHGSRCNAME_FG = item.CHGSRCNAME_FG;
                file.CHGSRCNAME = item.CHGSRCNAME;
                file.TOLERANCE_FG = item.TOLERANCE_FG;
                file.FILE_AMT_NM = item.FILE_AMT_NM;
                file.TOLERANCE = item.TOLERANCE;
                file.CHK_FG = item.CHK_FG;
                file.UNZIP_FG = item.UNZIP_FG;
                file.CRT_FG = item.CRT_FG;

                list.Add(file);
            }

            return list.AsQueryable();
        }

        [Queryable]
        public IQueryable<WV_XFILESTATUSView> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO, [FromODataUri]int FILE_SEQ)
        {
            List<WV_XFILESTATUSView> list = new List<WV_XFILESTATUSView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            long batchNo = long.Parse(BATCH_NO);
            var resultSet = db.WV_XFILESTATUSH.Where(o => o.DATACAT == DATACAT && o.BATCH_NO == batchNo && o.FILE_SEQ == FILE_SEQ);

            foreach (var item in resultSet)
            {
                WV_XFILESTATUSView file = new WV_XFILESTATUSView();

                file.DATACAT = item.DATACAT;
                file.BATCH_NO = item.BATCH_NO;
                file.CYCLE_START = item.CYCLE_START;
                file.CYCLE_END = item.CYCLE_END;
                file.PROCESS_TYPE = item.PROCESS_TYPE;

                if (!string.IsNullOrEmpty(item.PROCESS_TYPE))
                {
                    var PROCESS_TYPENM = parameters.Where(o => o.TypeName == "FLOW_TYPE" && o.ParameterValue == item.PROCESS_TYPE.Trim()).ToList();
                    if (PROCESS_TYPENM.Count() > 0)
                    {
                        file.PROCESS_TYPENM = PROCESS_TYPENM.First().ParameterName;
                    }
                }

                file.FILE_SEQ = item.FILE_SEQ;
                file.RSEQ = item.RSEQ;
                file.LSEQ = item.LSEQ;
                file.FILENAME = item.FILENAME;
                file.SRCNAME = item.SRCNAME;
                file.SRCCNAME = item.SRCCNAME;
                file.PARENT_FILENAME = item.PARENT_FILENAME;
                file.SKIP_FLAG = item.SKIP_FLAG;

                if (!string.IsNullOrEmpty(item.SKIP_FLAG))
                {
                    var SKIP_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.SKIP_FLAG.Trim()).ToList();
                    if (SKIP_FLAGNM.Count() > 0)
                    {
                        file.SKIP_FLAGNM = SKIP_FLAGNM.First().ParameterName;
                    }
                }

                file.NOT_EXIST_SKIP_FG = item.NOT_EXIST_SKIP_FG;
                file.ABORTCONTINUE_FLAG = item.ABORTCONTINUE_FLAG;
                file.FILE_STATUS = item.FILE_STATUS;

                if (!string.IsNullOrEmpty(item.FILE_STATUS))
                {
                    var FILE_STATUSNM = parameters.Where(o => o.TypeName == "FILE_STATUS" && o.ParameterValue == item.FILE_STATUS.Trim()).ToList();
                    if (FILE_STATUSNM.Count() > 0)
                    {
                        file.FILE_STATUSNM = FILE_STATUSNM.First().ParameterName;
                    }
                }

                file.FILE_START_TIME = item.FILE_START_TIME;
                file.FILE_END_TIME = item.FILE_END_TIME;
                file.FILE_DESC = item.FILE_DESC;
                file.CURR_SRCNAME = item.CURR_SRCNAME;
                file.FILESIZE = item.FILESIZE;
                file.FILEDATE = item.FILEDATE;
                file.LST_MAINT_USR = item.LST_MAINT_USR;
                file.LST_MAINT_DT = item.LST_MAINT_DT;
                file.FILE_RUN_TIME = item.FILE_RUN_TIME;
                file.CHGSRCNAME_FG = item.CHGSRCNAME_FG;
                file.CHGSRCNAME = item.CHGSRCNAME;
                file.TOLERANCE_FG = item.TOLERANCE_FG;
                file.FILE_AMT_NM = item.FILE_AMT_NM;
                file.TOLERANCE = item.TOLERANCE;
                file.CHK_FG = item.CHK_FG;
                file.UNZIP_FG = item.UNZIP_FG;
                file.CRT_FG = item.CRT_FG;

                list.Add(file);
            }

            return list.AsQueryable();
        }
    }
}
