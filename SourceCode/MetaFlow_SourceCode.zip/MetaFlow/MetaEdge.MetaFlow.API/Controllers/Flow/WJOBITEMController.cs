﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System.Data.Entity.Infrastructure;
using System;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WJOBITEMController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WJOBITEM> GetWJOBITEM()
        {
            return db.WJOBITEM;
        }

        [Queryable]
        public IQueryable<WJOBITEM> GetWJOBITEM([FromODataUri]string DISABLE_FG)
        {
            return db.WJOBITEM.Where(o => o.DISABLE_FG == DISABLE_FG || DISABLE_FG == "ALL");
        }

        [Queryable]
        public IQueryable<WJOBITEM> GetWJOBITEM(string JOB_NAME, string JOB_TYPE, string JOB_OWNER)
        {
            return db.WJOBITEM.Where(o => o.JOB_NAME == JOB_NAME && o.JOB_TYPE == JOB_TYPE && o.JOB_OWNER == JOB_OWNER);
        }

        [Queryable]
        public IQueryable<WJOBITEM> GetWJOBITEM(string JOB_NAME, string JOB_TYPE, string JOB_LOCATION, string JOB_OWNER)
        {
            var result = db.WJOBITEM.Where(o => o.JOB_NAME == JOB_NAME && o.JOB_TYPE == JOB_TYPE && o.JOB_LOCATION == JOB_LOCATION && o.JOB_OWNER == JOB_OWNER);
            return result;
        }

        public async Task<IHttpActionResult> Post(WJOBITEM WJOBITEM)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WJOBITEM.Add(WJOBITEM);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (WJOBITEMExists(WJOBITEM.JOB_NAME, WJOBITEM.JOB_TYPE, WJOBITEM.JOB_LOCATION, WJOBITEM.JOB_OWNER))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WJOBITEM);
        }

        // PUT odata/auth_Category(5)
        public async Task<IHttpActionResult> Put([FromODataUri] string JOB_NAME, [FromODataUri]string JOB_TYPE, [FromODataUri]string JOB_LOCATION, [FromODataUri] string JOB_OWNER, WJOBITEM wjobitem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }


            //db.Entry(auth_Category).State = EntityState.Modified;

            db.WJOBITEM.RemoveRange(db.WJOBITEM.Where(o => o.JOB_TYPE == JOB_TYPE && o.JOB_NAME == JOB_NAME && o.JOB_OWNER == JOB_OWNER && o.JOB_LOCATION == JOB_LOCATION));
            db.WJOBITEM.Add(wjobitem);


            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Updated(wjobitem);
        }

        private bool WJOBITEMExists(string JOB_NAME, string JOB_TYPE, string JOB_LOCATION, string JOB_OWNER)
        {
            return db.WJOBITEM.Count(XFLOWDETAIL => XFLOWDETAIL.JOB_NAME == JOB_NAME && XFLOWDETAIL.JOB_TYPE == JOB_TYPE && XFLOWDETAIL.JOB_LOCATION == JOB_LOCATION && XFLOWDETAIL.JOB_OWNER == JOB_OWNER) > 0;
        }


    }
}
