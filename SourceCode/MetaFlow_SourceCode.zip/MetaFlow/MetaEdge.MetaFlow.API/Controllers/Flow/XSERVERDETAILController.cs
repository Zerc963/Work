﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System;
using System.Data.Entity.Infrastructure;
using System.Net;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XSERVERDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XSERVERDETAIL> Get()
        {
            return db.XSERVERDETAIL;
        }

        [Queryable]
        public IQueryable<XSERVERDETAIL> Get([FromODataUri]string SERVERTYPE, [FromODataUri]string SERVERNM, [FromODataUri]string USERCODE)
        {
            return db.XSERVERDETAIL.Where(o => o.SERVERTYPE == SERVERTYPE && o.SERVERNM == SERVERNM && o.USERCODE == USERCODE);
        }

    }
}
