﻿using MetaEdge.ISMD.Entity.Models;
using MetaEdge.MetaAuthWeb.Data.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WV_XFLOWSTATUSViewController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<WV_XFLOWSTATUSView> Get()
        {
            List<WV_XFLOWSTATUSView> list = new List<WV_XFLOWSTATUSView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            var resultSet = db.WV_XFLOWSTATUS;

            foreach (var item in resultSet)
            {
                WV_XFLOWSTATUSView flow = new WV_XFLOWSTATUSView();

                flow.DATACAT = item.DATACAT;
                flow.DATACATNM = item.DATACATNM;

                flow.CYCLE_DATE = item.CYCLE_DATE;
                flow.RUN_STATUS = item.RUN_STATUS;

                if (!string.IsNullOrEmpty(item.RUN_STATUS))
                {
                    var RUN_STATUSNM = parameters.Where(o => o.TypeName == "RUN_STATUS" && o.ParameterValue == item.RUN_STATUS.Trim()).ToList();
                    if (RUN_STATUSNM.Count() > 0)
                    {
                        flow.RUN_STATUSNM = RUN_STATUSNM.First().ParameterName;
                    }
                }

                flow.START_TIME = item.START_TIME;
                flow.END_TIME = item.END_TIME;
                flow.NEXT_TIME = item.NEXT_TIME;
                list.Add(flow);
            }

            return list.AsQueryable();
        }
    }
}
