﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_JobDetail_DropDown_TableController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<DropDownEntity> Get()
        {
            var result = (from s1 in db.XCOLUMNDETAIL
                          group s1 by new { s1.DB_NM, s1.SCHEMA_NM, s1.TABLE_NM } into s2

                          select new
                          {
                              DB_NM = s2.Key.DB_NM
                              ,
                              SCHEMA_NM = s2.Key.SCHEMA_NM
                              ,
                              TABLE_NM = s2.Key.TABLE_NM
                          })
                          .OrderBy(o => o.DB_NM)
                          .ThenBy(o => o.SCHEMA_NM)
                          .ThenBy(o => o.TABLE_NM)
                          .ToList();

            List<DropDownEntity> list = new List<DropDownEntity>();
            foreach (var file in result)
            {
                DropDownEntity option = new DropDownEntity();
                option.OptionText = string.Format("{0}.{1}.{2}", file.DB_NM, file.SCHEMA_NM, file.TABLE_NM);
                option.OptionValue = string.Format("{0}.{1}.{2}", file.DB_NM, file.SCHEMA_NM, file.TABLE_NM);
                list.Add(option);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
