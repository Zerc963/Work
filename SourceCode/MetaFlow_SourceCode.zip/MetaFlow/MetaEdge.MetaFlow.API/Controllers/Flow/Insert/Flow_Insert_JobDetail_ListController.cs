﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_JobDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XJOBDETAIL> GetXJOBDETAIL()
        {
            return db.XJOBDETAIL;
        }


        // POST odata/XJOBDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_JobDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (XJOBDETAIL jobDtail in List.Detail)
                {
                    try
                    {
                        db.XJOBDETAIL.Add(jobDtail);

                        try
                        {
                            await db.SaveChangesAsync();
                        }
                        catch (DbUpdateException)
                        {
                            if (XJOBDETAILExists(jobDtail.DATACAT, jobDtail.JOB_STAGE, jobDtail.JOB_FLOW, jobDtail.JOB_SEQ))
                            {
                                return Conflict();
                            }
                            else
                            {
                                throw;
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }

                dbTransaction.Commit();
            }

            return Created(List);
        }

        private bool XJOBDETAILExists(string DATACAT, string JOB_STAGE, int JOB_FLOW, int JOB_SEQ)
        {
            return db.XJOBDETAIL.Count(XJOBDETAIL => (XJOBDETAIL.DATACAT == DATACAT && XJOBDETAIL.JOB_STAGE == JOB_STAGE && XJOBDETAIL.JOB_FLOW == JOB_FLOW && XJOBDETAIL.JOB_SEQ == JOB_SEQ)) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
