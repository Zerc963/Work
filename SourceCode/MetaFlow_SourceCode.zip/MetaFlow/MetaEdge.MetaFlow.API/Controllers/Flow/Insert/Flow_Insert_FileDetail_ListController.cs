﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_FileDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();


        // POST odata/XFILEDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_FileDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (Flow_Insert_FileDetail_List_Data data in List.Detail)
                {
                    try
                    {
                        string encryptionSeq = string.Empty;

                        if (!string.IsNullOrEmpty(data.ZIP_PW))
                        {
                            encryptionSeq = Guid.NewGuid().ToString().ToLower();
                            
                            XENCRYPTION encryption = new XENCRYPTION();
                            encryption.SEQ = encryptionSeq;
                            encryption.VALUE = data.ZIP_PW;
                            encryption.LST_MAINT_USR = data.LST_MAINT_USR;
                            encryption.LST_MAINT_DT = data.LST_MAINT_DT;

                            db.XENCRYPTION.Add(encryption);
                        }
                        
                        XFILEDETAIL fileDetail = new XFILEDETAIL();
                        fileDetail.DATACAT = data.DATACAT;
                        fileDetail.PROCESS_TYPE = data.PROCESS_TYPE;
                        fileDetail.FILE_SEQ = data.FILE_SEQ;
                        fileDetail.RSEQ = data.RSEQ;
                        fileDetail.LSEQ = data.LSEQ;
                        fileDetail.FILENAME = data.FILENAME;
                        fileDetail.SRCNAME = data.SRCNAME;
                        fileDetail.SRCCNAME = data.SRCCNAME;
                        fileDetail.PARENT_FILENAME = data.PARENT_FILENAME;
                        fileDetail.SKIP_FLAG = data.SKIP_FLAG;
                        fileDetail.NOT_EXIST_SKIP_FG = data.NOT_EXIST_SKIP_FG;
                        fileDetail.ABORTCONTINUE_FLAG = data.ABORTCONTINUE_FLAG;
                        fileDetail.CRT_FG = data.CRT_FG;
                        fileDetail.CHK_FG = data.CHK_FG;
                        fileDetail.UNZIP_FG = data.UNZIP_FG;
                        fileDetail.ZIP_PW = encryptionSeq;
                        fileDetail.FILE_AMT_NM = data.FILE_AMT_NM;
                        fileDetail.TOLERANCE = data.TOLERANCE;
                        fileDetail.LST_MAINT_USR = data.LST_MAINT_USR;
                        fileDetail.LST_MAINT_DT = data.LST_MAINT_DT;

                        db.XFILEDETAIL.Add(fileDetail);

                        // 用data.RAGGED_FIX是否為空，來判斷flatFile存在與否
                        if (string.IsNullOrEmpty(data.RAGGED_FIX))
                        {
                            XFLATFILEDETAIL xflatFile = new XFLATFILEDETAIL();
                            xflatFile.DATACAT = data.DATACAT;
                            xflatFile.FILE_SEQ = data.FILE_SEQ;
                            xflatFile.FILE_GROUP = data.FILE_GROUP;
                            xflatFile.CODEPAGE = data.CODEPAGE;
                            xflatFile.RAGGED_FIX = data.RAGGED_FIX;
                            xflatFile.RECORDLEN = data.RECORDLEN;
                            xflatFile.RAGGEDLEN = data.RAGGEDLEN;
                            xflatFile.DELIMITER = data.DELIMITER;
                            xflatFile.TERMINATOR = data.TERMINATOR;
                            xflatFile.FIRSTROW = data.FIRSTROW;
                            xflatFile.LST_MAINT_USR = data.LST_MAINT_USR;
                            xflatFile.LST_MAINT_DT = data.LST_MAINT_DT;

                            db.XFLATFILEDETAIL.Add(xflatFile);
                        }

                        try
                        {
                            await db.SaveChangesAsync();
                        }
                        catch (DbUpdateException ex)
                        {
                            if (XFILEDETAILExists(data.DATACAT, data.FILE_SEQ) || XFLATFILEDETAILExists(data.DATACAT, data.FILE_SEQ))
                            {
                                return Conflict();
                            }
                            else
                            {
                                throw;
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }

                dbTransaction.Commit();
            }

            return Created(List);
        }

        private bool XFILEDETAILExists(string DATACAT, int FILE_SEQ)
        {
            return db.XFILEDETAIL.Count(XFILEDETAIL => (XFILEDETAIL.DATACAT == DATACAT && XFILEDETAIL.FILE_SEQ == FILE_SEQ)) > 0;
        }

        private bool XFLATFILEDETAILExists(string DATACAT, int FILE_SEQ)
        {
            return db.XFLATFILEDETAIL.Count(XFLATFILEDETAIL => (XFLATFILEDETAIL.DATACAT == DATACAT && XFLATFILEDETAIL.FILE_SEQ == FILE_SEQ)) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
