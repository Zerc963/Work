﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcFileDetail_DeleteInsertController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XFILEDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcFileDetail_DeleteInsert WWKSPC_XFILEDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (WwkspcFileDetail_PrimaryKey primaryKey in WWKSPC_XFILEDETAIL.DeleteDetail)
            {
                db.WWKSPC_XFLATFILEDETAIL.RemoveRange(db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == primaryKey.DATACAT
                                                                                  && o.FILE_SEQ == primaryKey.FILE_SEQ
                                                                                  && o.LST_MAINT_USR == primaryKey.LST_MAINT_USR));

                var oldFileDetail = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == primaryKey.DATACAT
                                                               && o.FILE_SEQ == primaryKey.FILE_SEQ
                                                               && o.LST_MAINT_USR == primaryKey.LST_MAINT_USR).ToList();

                db.WWKSPC_XFILEDETAIL.RemoveRange(oldFileDetail);

                // 刪除解壓縮密碼 XENCRYPTION
                // 若在 InsertDetail 有相同的 ZIP_PW，表示只是移動順序，就不需要刪除
                if (WWKSPC_XFILEDETAIL.InsertDetail.Where(o => o.ZIP_PW == primaryKey.ZIP_PW).Count() == 0)
                {
                    db.WWKSPC_XENCRYPTION.RemoveRange(db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == primaryKey.ZIP_PW
                                                                  && o.LST_MAINT_USR == primaryKey.LST_MAINT_USR));
                }

                // 有刪除、無新增，是只有做刪除的動作，同步清除被設定的 PARENT_FILENAME
                if (oldFileDetail.Count() > 0 && WWKSPC_XFILEDETAIL.InsertDetail.Length == 0)
                {
                    var srcName = oldFileDetail.First().SRCNAME;
                    var childFile = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == primaryKey.DATACAT && o.PARENT_FILENAME == srcName && o.LST_MAINT_USR == primaryKey.LST_MAINT_USR);

                    foreach (WWKSPC_XFILEDETAIL file in childFile)
                    {
                        file.PARENT_FILENAME = null;
                        file.LST_MAINT_USR = primaryKey.LST_MAINT_USR;
                        file.LST_MAINT_DT = DateTime.Now;
                        db.Entry(file).State = EntityState.Modified;
                    }
                }
            }

            foreach (Flow_Insert_WwkspcFileDetail_List fileDetailTemp in WWKSPC_XFILEDETAIL.InsertDetail)
            {
                //string encryptionSeq = null;

                //// WWKSPC_XENCRYPTION
                //if (!string.IsNullOrEmpty(fileDetailTemp.ZIP_PW))
                //{
                //    encryptionSeq = Guid.NewGuid().ToString().ToLower();

                //    WWKSPC_XENCRYPTION encryption = new WWKSPC_XENCRYPTION();
                //    encryption.SEQ = encryptionSeq;
                //    encryption.VALUE = fileDetailTemp.ZIP_PW;
                //    encryption.LST_MAINT_USR = fileDetailTemp.LST_MAINT_USR;
                //    encryption.LST_MAINT_DT = DateTime.Now;

                //    db.WWKSPC_XENCRYPTION.Add(encryption);
                //}

                // WWKSPC_XFILEDETAIL
                WWKSPC_XFILEDETAIL fileDetail = new WWKSPC_XFILEDETAIL();
                fileDetail.DATACAT = fileDetailTemp.DATACAT;
                fileDetail.PROCESS_TYPE = fileDetailTemp.PROCESS_TYPE;
                fileDetail.FILE_SEQ = fileDetailTemp.FILE_SEQ;
                fileDetail.RSEQ = fileDetailTemp.RSEQ;
                fileDetail.LSEQ = fileDetailTemp.LSEQ;
                fileDetail.FILENAME = fileDetailTemp.FILENAME;
                fileDetail.SRCNAME = fileDetailTemp.SRCNAME;
                fileDetail.SRCCNAME = fileDetailTemp.SRCCNAME;
                fileDetail.PARENT_FILENAME = fileDetailTemp.PARENT_FILENAME;
                fileDetail.SKIP_FLAG = fileDetailTemp.SKIP_FLAG;
                fileDetail.NOT_EXIST_SKIP_FG = fileDetailTemp.NOT_EXIST_SKIP_FG;
                fileDetail.ABORTCONTINUE_FLAG = fileDetailTemp.ABORTCONTINUE_FLAG;
                fileDetail.CRT_FG = fileDetailTemp.CRT_FG;
                fileDetail.CHK_FG = fileDetailTemp.CHK_FG;
                fileDetail.UNZIP_FG = fileDetailTemp.UNZIP_FG;
                fileDetail.ZIP_PW = fileDetailTemp.ZIP_PW;
                fileDetail.FILE_AMT_NM = fileDetailTemp.FILE_AMT_NM;
                fileDetail.TOLERANCE = fileDetailTemp.TOLERANCE;
                fileDetail.LST_MAINT_USR = fileDetailTemp.LST_MAINT_USR;
                fileDetail.LST_MAINT_DT = DateTime.Now;
                db.WWKSPC_XFILEDETAIL.Add(fileDetail);

                // WWKSPC_XFLATFILEDETAIL
                // 用data.RAGGED_FIX是否為空，來判斷flatFile存在與否
                if (!string.IsNullOrEmpty(fileDetailTemp.RAGGED_FIX))
                {
                    WWKSPC_XFLATFILEDETAIL xflatFile = new WWKSPC_XFLATFILEDETAIL();
                    xflatFile.DATACAT = fileDetailTemp.DATACAT;
                    xflatFile.FILE_SEQ = fileDetailTemp.FILE_SEQ;
                    xflatFile.FILE_GROUP = fileDetailTemp.FILE_GROUP;
                    xflatFile.CODEPAGE = fileDetailTemp.CODEPAGE;
                    xflatFile.RAGGED_FIX = fileDetailTemp.RAGGED_FIX;
                    xflatFile.RECORDLEN = fileDetailTemp.RECORDLEN;
                    xflatFile.RAGGEDLEN = fileDetailTemp.RAGGEDLEN;
                    xflatFile.DELIMITER = fileDetailTemp.DELIMITER;
                    xflatFile.TERMINATOR = fileDetailTemp.TERMINATOR;
                    xflatFile.FIRSTROW = fileDetailTemp.FIRSTROW;
                    xflatFile.LST_MAINT_USR = fileDetailTemp.LST_MAINT_USR;
                    xflatFile.LST_MAINT_DT = DateTime.Now;

                    db.WWKSPC_XFLATFILEDETAIL.Add(xflatFile);
                }
            }

            // 有刪除、無新增，是只有做刪除的動作，故需重新排序 FILE_SEQ
            //if (WWKSPC_XFILEDETAIL.DeleteDetail.Length > 0 && WWKSPC_XFILEDETAIL.InsertDetail.Length == 0)
            //{
            //    // 取得 WWKSPC_XFILEDETAIL 的所有資料
            //    string LST_MAINT_USR = WWKSPC_XFILEDETAIL.DeleteDetail[0].LST_MAINT_USR;
            //    var result = db.WWKSPC_XFILEDETAIL.Where(o => o.LST_MAINT_USR == LST_MAINT_USR).ToList();

            //    int seq = 1;
            //    foreach (WWKSPC_XFILEDETAIL fileDetailTemp in result)
            //    {
            //        // 忽略刪除的資料 (WWKSPC_XFILEDETAIL 裡面有的 FILE_SEQ)
            //        if (WWKSPC_XFILEDETAIL.DeleteDetail.Where(o => o.FILE_SEQ == fileDetailTemp.FILE_SEQ).Count() == 0)
            //        {
            //            if (fileDetailTemp.FILE_SEQ != seq)
            //            {
            //                WWKSPC_XFILEDETAIL fileDetailTemp_New = new WWKSPC_XFILEDETAIL();
            //                fileDetailTemp_New.DATACAT = fileDetailTemp.DATACAT;
            //                fileDetailTemp_New.PROCESS_TYPE = fileDetailTemp.PROCESS_TYPE;
            //                fileDetailTemp_New.FILE_SEQ = seq;
            //                fileDetailTemp_New.RSEQ = fileDetailTemp.RSEQ;
            //                fileDetailTemp_New.LSEQ = fileDetailTemp.LSEQ;
            //                fileDetailTemp_New.FILENAME = fileDetailTemp.FILENAME;
            //                fileDetailTemp_New.SRCNAME = fileDetailTemp.SRCNAME;
            //                fileDetailTemp_New.SRCCNAME = fileDetailTemp.SRCCNAME;
            //                fileDetailTemp_New.PARENT_FILENAME = fileDetailTemp.PARENT_FILENAME;
            //                fileDetailTemp_New.SKIP_FLAG = fileDetailTemp.SKIP_FLAG;
            //                fileDetailTemp_New.NOT_EXIST_SKIP_FG = fileDetailTemp.NOT_EXIST_SKIP_FG;
            //                fileDetailTemp_New.ABORTCONTINUE_FLAG = fileDetailTemp.ABORTCONTINUE_FLAG;
            //                fileDetailTemp_New.CRT_FG = fileDetailTemp.CRT_FG;
            //                fileDetailTemp_New.CHK_FG = fileDetailTemp.CHK_FG;
            //                fileDetailTemp_New.UNZIP_FG = fileDetailTemp.UNZIP_FG;
            //                fileDetailTemp_New.ZIP_PW = fileDetailTemp.ZIP_PW;
            //                fileDetailTemp_New.FILE_AMT_NM = fileDetailTemp.FILE_AMT_NM;
            //                fileDetailTemp_New.TOLERANCE = fileDetailTemp.TOLERANCE;
            //                fileDetailTemp_New.LST_MAINT_USR = fileDetailTemp.LST_MAINT_USR;
            //                fileDetailTemp_New.LST_MAINT_DT = DateTime.Now;

            //                db.WWKSPC_XFILEDETAIL.Remove(fileDetailTemp);
            //                db.WWKSPC_XFILEDETAIL.Add(fileDetailTemp_New);

            //                var WWKSPC_XFLATFILEDETAIL_DATA = db.WWKSPC_XFLATFILEDETAIL.Where(o => o.FILE_SEQ == fileDetailTemp.FILE_SEQ && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
            //                if (WWKSPC_XFLATFILEDETAIL_DATA.Count() > 0)
            //                {
            //                    WWKSPC_XFLATFILEDETAIL WWKSPC_XFLATFILEDETAIL = WWKSPC_XFLATFILEDETAIL_DATA.First();
            //                    WWKSPC_XFLATFILEDETAIL xflatFile = new WWKSPC_XFLATFILEDETAIL();
            //                    xflatFile.DATACAT = WWKSPC_XFLATFILEDETAIL.DATACAT;
            //                    xflatFile.FILE_SEQ = seq;
            //                    xflatFile.FILE_GROUP = WWKSPC_XFLATFILEDETAIL.FILE_GROUP;
            //                    xflatFile.CODEPAGE = WWKSPC_XFLATFILEDETAIL.CODEPAGE;
            //                    xflatFile.RAGGED_FIX = WWKSPC_XFLATFILEDETAIL.RAGGED_FIX;
            //                    xflatFile.RECORDLEN = WWKSPC_XFLATFILEDETAIL.RECORDLEN;
            //                    xflatFile.RAGGEDLEN = WWKSPC_XFLATFILEDETAIL.RAGGEDLEN;
            //                    xflatFile.DELIMITER = WWKSPC_XFLATFILEDETAIL.DELIMITER;
            //                    xflatFile.TERMINATOR = WWKSPC_XFLATFILEDETAIL.TERMINATOR;
            //                    xflatFile.FIRSTROW = WWKSPC_XFLATFILEDETAIL.FIRSTROW;
            //                    xflatFile.LST_MAINT_USR = WWKSPC_XFLATFILEDETAIL.LST_MAINT_USR;
            //                    xflatFile.LST_MAINT_DT = DateTime.Now;

            //                    db.WWKSPC_XFLATFILEDETAIL.Remove(WWKSPC_XFLATFILEDETAIL);
            //                    db.WWKSPC_XFLATFILEDETAIL.Add(xflatFile);
            //                }
            //            }

            //            seq++;
            //        }
            //    }
            //}

            try
            {
                await db.SaveChangesAsync();
                update_StgTable_SRC_TB(WWKSPC_XFILEDETAIL.DeleteDetail.First().DATACAT, WWKSPC_XFILEDETAIL.DeleteDetail.First().LST_MAINT_USR);
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return Updated(WWKSPC_XFILEDETAIL);
        }

        /// <summary>
        /// 自動更新 WWKSPC_XJOBDETAIL 的 SRC_TB
        /// SRC_TB 以 SrcFileGroup 對應相關的 WWKSPC_XFLATFILEDETAIL，再找到 WWKSPC_XFILEDETAIL 的 SRCNAME
        /// 多個 WWKSPC_XFILEDETAIL 可能會是相同的 FILE_GROUP，因此 SRC_TB 的內容會是 A||B||C
        /// </summary>
        /// <param name="DATACAT"></param>
        /// <param name="LST_MAINT_USR"></param>
        private void update_StgTable_SRC_TB(string DATACAT, string LST_MAINT_USR)
        {
            var jobDetail = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.JOB_NAME == "IS_StgTable_FlatFile" && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

            foreach (WWKSPC_XJOBDETAIL job in jobDetail)
            {
                string SrcFileGroup = job.PARAM.Split(';')[0].Replace("SrcFileGroup=", "");

                var flatFileDetail = db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.FILE_GROUP == SrcFileGroup && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                string srcTable = string.Empty;

                foreach (WWKSPC_XFLATFILEDETAIL file in flatFileDetail)
                {
                    string fileName = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.FILE_SEQ == file.FILE_SEQ && o.LST_MAINT_USR == LST_MAINT_USR).First().SRCNAME;
                    srcTable += fileName + "||";
                }

                if (!string.IsNullOrEmpty(srcTable))
                {
                    job.SRC_TB = srcTable.Substring(0, srcTable.Length - 2);
                    db.Entry(job).State = EntityState.Modified;
                }
            }

            try
            {
                db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
