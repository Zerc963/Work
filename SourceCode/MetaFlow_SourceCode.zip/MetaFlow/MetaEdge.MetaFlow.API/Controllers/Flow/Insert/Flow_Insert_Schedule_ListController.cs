﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_Schedule_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XSCHEDULE> GetXSCHEDULE()
        {
            return db.XSCHEDULE;
        }


        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_Schedule_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (XSCHEDULE schedule in List.Detail)
                {
                    try
                    {
                        db.XSCHEDULE.Add(schedule);

                        try
                        {
                            await db.SaveChangesAsync();
                        }
                        catch (DbUpdateException)
                        {
                            if (XSCHEDULEExists(schedule.DATACAT, schedule.DATACAT, schedule.START_TIME))
                            {
                                return Conflict();
                            }
                            else
                            {
                                throw;
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }

                dbTransaction.Commit();
            }

            return Created(List);
        }

        private bool XSCHEDULEExists(string DATACAT, string PROCESS_TYPE, TimeSpan START_TIME)
        {
            return db.XSCHEDULE.Count(XSCHEDULE => XSCHEDULE.DATACAT == DATACAT && XSCHEDULE.PROCESS_TYPE == PROCESS_TYPE && XSCHEDULE.START_TIME == START_TIME) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
