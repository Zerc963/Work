﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcLocalDetail_DeleteController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XLOCALDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcLocalDetail_Delete WWKSPC_XLOCALDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (WWKSPC_XLOCALDETAIL LocalDetailTemp in WWKSPC_XLOCALDETAIL.Detail)
            {
                db.WWKSPC_XLOCALDETAIL.RemoveRange(db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == LocalDetailTemp.DATACAT
                                                                            && o.LSEQ == LocalDetailTemp.LSEQ
                                                                            && o.LST_MAINT_USR == LocalDetailTemp.LST_MAINT_USR));
            }

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return Updated(WWKSPC_XLOCALDETAIL);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
