﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_LocalDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XSCHEDULE> GetXSCHEDULE()
        {
            return db.XSCHEDULE;
        }


        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_LocalDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (XLOCALDETAIL local in List.LocalDetail)
                {

                    try
                    {
                        db.XLOCALDETAIL.Add(local);
                    }
                    catch (DbUpdateException)
                    {
                        if (XLOCALDETAILExists(local.DATACAT, local.LSEQ))
                        {
                            return Conflict();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }

                foreach (XREMOTEDETAIL remote in List.RemoteDetail)
                {

                    try
                    {
                        db.XREMOTEDETAIL.Add(remote);
                    }
                    catch (DbUpdateException)
                    {
                        if (XREMOTEDETAILExists(remote.DATACAT, remote.RSEQ))
                        {
                            return Conflict();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }

                try
                {
                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(List);
            }
        }

        private bool XLOCALDETAILExists(string DATACAT, string LSEQ)
        {
            return db.XLOCALDETAIL.Count(XLOCALDETAIL => XLOCALDETAIL.DATACAT == DATACAT && XLOCALDETAIL.LSEQ == LSEQ) > 0;
        }

        private bool XREMOTEDETAILExists(string DATACAT, string RSEQ)
        {
            return db.XREMOTEDETAIL.Count(XREMOTEDETAIL => XREMOTEDETAIL.DATACAT == DATACAT && XREMOTEDETAIL.RSEQ == RSEQ) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
