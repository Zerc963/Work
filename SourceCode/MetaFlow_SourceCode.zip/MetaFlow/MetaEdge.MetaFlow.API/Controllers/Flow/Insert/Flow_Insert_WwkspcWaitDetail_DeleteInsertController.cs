﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcWaitDetail_DeleteInsertController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XWAITDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcWaitDetail_DeleteInsert WWKSPC_XWAITDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (WWKSPC_XWAITDETAIL waitDetailTemp in WWKSPC_XWAITDETAIL.DeleteDetail)
            {
                db.WWKSPC_XWAITDETAIL.RemoveRange(db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == waitDetailTemp.DATACAT
                                                                          && o.WAIT_SEQ == waitDetailTemp.WAIT_SEQ
                                                                          && o.LST_MAINT_USR == waitDetailTemp.LST_MAINT_USR));
            }

            foreach (WWKSPC_XWAITDETAIL waitDetailTemp in WWKSPC_XWAITDETAIL.InsertDetail)
            {
                waitDetailTemp.LST_MAINT_DT = DateTime.Now;
                db.WWKSPC_XWAITDETAIL.Add(waitDetailTemp);
            }

            // 有刪除、無新增，是只有做刪除的動作，故需重新排序 WAIT_SEQ
            //if (WWKSPC_XWAITDETAIL.DeleteDetail.Length > 0 && WWKSPC_XWAITDETAIL.InsertDetail.Length == 0)
            //{
            //    // 取得 WWKSPC_XWAITDETAIL 的所有資料
            //    string LST_MAINT_USR = WWKSPC_XWAITDETAIL.DeleteDetail[0].LST_MAINT_USR;
            //    var result = db.WWKSPC_XWAITDETAIL.Where(o => o.LST_MAINT_USR == LST_MAINT_USR).ToList();

            //    int seq = 1;
            //    foreach (WWKSPC_XWAITDETAIL waitDetailTemp in result)
            //    {
            //        // 忽略刪除的資料 (WWKSPC_XWAITDETAIL 裡面有的 WAIT_SEQ)
            //        if (WWKSPC_XWAITDETAIL.DeleteDetail.Where(o => o.WAIT_SEQ == waitDetailTemp.WAIT_SEQ).Count() == 0)
            //        {
            //            if (waitDetailTemp.WAIT_SEQ != seq)
            //            {
            //                WWKSPC_XWAITDETAIL waitDetailTemp_New = new WWKSPC_XWAITDETAIL();
            //                waitDetailTemp_New.DATACAT = "";
            //                waitDetailTemp_New.PROCESS_TYPE = waitDetailTemp.PROCESS_TYPE;
            //                waitDetailTemp_New.WAIT_SEQ = seq;
            //                waitDetailTemp_New.WAIT_TYPE = waitDetailTemp.WAIT_TYPE;
            //                waitDetailTemp_New.RSEQ = waitDetailTemp.RSEQ;
            //                waitDetailTemp_New.LSEQ = waitDetailTemp.LSEQ;
            //                waitDetailTemp_New.WAIT_NAME = waitDetailTemp.WAIT_NAME;
            //                waitDetailTemp_New.CHK_FG = waitDetailTemp.CHK_FG;
            //                waitDetailTemp_New.CHK_FILEDATE_FG = waitDetailTemp.CHK_FILEDATE_FG;
            //                waitDetailTemp_New.TOLERANCE = waitDetailTemp.TOLERANCE;
            //                waitDetailTemp_New.WAIT_SKIP_FLAG = waitDetailTemp.WAIT_SKIP_FLAG;
            //                waitDetailTemp_New.NOT_EXIST_SKIP_FG = waitDetailTemp.NOT_EXIST_SKIP_FG;
            //                waitDetailTemp_New.LST_MAINT_USR = waitDetailTemp.LST_MAINT_USR;
            //                waitDetailTemp_New.LST_MAINT_DT = DateTime.Now;

            //                db.WWKSPC_XWAITDETAIL.Remove(waitDetailTemp);
            //                db.WWKSPC_XWAITDETAIL.Add(waitDetailTemp_New);
            //            }

            //            seq++;
            //        }
            //    }
            //}

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return Updated(WWKSPC_XWAITDETAIL);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
