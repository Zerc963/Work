﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_MailDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XMAILDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_MailDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (XMAILDETAIL_List_Data detail in List.mailDetail)
                {
                    #region [ insert mailDetails ]
                    try
                    {
                        if (detail.notifyRUNOK_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "RUNOK", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                        }
                        if (detail.notifyABORT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "ABORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                        }
                        if (detail.notifyCHECK_FILE_REPORT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "CHECK FILE REPORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                        }
                        if (detail.notifyFLOW_REPORT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "FLOW REPORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                        }
                        if (detail.notifyMONITOR_FILE_WAIT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "MONITOR FILE WAIT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                        }
                        if (detail.notifyMONITOR_FLOW_TIME_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "MONITOR FLOW TIME", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                        }

                        try
                        {
                            await db.SaveChangesAsync();
                        }
                        catch (DbUpdateException)
                        {
                            throw;
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                    #endregion
                }

                if (List.FILEWAIT_checked)
                {
                    #region [ insert XMONITOR_FILEWAIT ]
                    XMONITOR_FILEWAIT monitorFileWait = List.XMONITOR_FILEWAIT;
                    db.XMONITOR_FILEWAIT.Add(monitorFileWait);
                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        if (XMONITOR_FILEWAITExists(monitorFileWait.DATACAT))
                        {
                            return Conflict();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    #endregion
                }

                if (List.FLOWTIME_checked)
                {
                    #region [ insert XMONITOR_FLOWTIME ]
                    XMONITOR_FLOWTIME monitorFlowtime = List.XMONITOR_FLOWTIME;
                    db.XMONITOR_FLOWTIME.Add(monitorFlowtime);
                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        if (XMONITOR_FLOWTIMEExists(monitorFlowtime.DATACAT))
                        {
                            return Conflict();
                        }
                        else
                        {
                            throw;
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                    #endregion
                }
                dbTransaction.Commit();
            }

            return Created(List);
        }

        private bool XMONITOR_FLOWTIMEExists(string DATACAT)
        {
            return db.XMONITOR_FLOWTIME.Count(XMONITOR_FLOWTIME => (XMONITOR_FLOWTIME.DATACAT == DATACAT)) > 0;
        }

        private bool XMONITOR_FILEWAITExists(string DATACAT)
        {
            return db.XMONITOR_FILEWAIT.Count(XMONITOR_FILEWAIT => (XMONITOR_FILEWAIT.DATACAT == DATACAT)) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
