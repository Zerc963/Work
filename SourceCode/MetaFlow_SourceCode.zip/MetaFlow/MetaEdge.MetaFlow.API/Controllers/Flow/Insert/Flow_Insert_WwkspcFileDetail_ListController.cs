﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Data.Entity;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcFileDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XFILEDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcFileDetail_List_Data WWKSPC_XFILEDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            string encryptionSeq = null;

            // XENCRYPTION_TEMP
            if (!string.IsNullOrEmpty(WWKSPC_XFILEDETAIL.ZIP_PW))
            {
                encryptionSeq = Guid.NewGuid().ToString().ToLower();

                WWKSPC_XENCRYPTION encryption = new WWKSPC_XENCRYPTION();
                encryption.SEQ = encryptionSeq;
                encryption.VALUE = WWKSPC_XFILEDETAIL.ZIP_PW;
                encryption.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                encryption.LST_MAINT_DT = DateTime.Now;

                db.WWKSPC_XENCRYPTION.Add(encryption);
                string encryptionValue = db.Database.SqlQuery<string>("select dbo.Encrypt(@Value)", new SqlParameter("Value", WWKSPC_XFILEDETAIL.ZIP_PW)).ToList().First();
                WWKSPC_XFILEDETAIL.ZIP_PW = encryptionValue;
            }

            // WWKSPC_XFILEDETAIL
            WWKSPC_XFILEDETAIL fileDetail = new WWKSPC_XFILEDETAIL();
            fileDetail.DATACAT = WWKSPC_XFILEDETAIL.DATACAT;
            fileDetail.PROCESS_TYPE = WWKSPC_XFILEDETAIL.PROCESS_TYPE;
            fileDetail.FILE_SEQ = WWKSPC_XFILEDETAIL.FILE_SEQ;
            fileDetail.RSEQ = WWKSPC_XFILEDETAIL.RSEQ;
            fileDetail.LSEQ = WWKSPC_XFILEDETAIL.LSEQ;
            fileDetail.FILENAME = WWKSPC_XFILEDETAIL.FILENAME;
            fileDetail.SRCNAME = WWKSPC_XFILEDETAIL.SRCNAME;
            fileDetail.SRCCNAME = WWKSPC_XFILEDETAIL.SRCCNAME;
            fileDetail.PARENT_FILENAME = WWKSPC_XFILEDETAIL.PARENT_FILENAME;
            fileDetail.SKIP_FLAG = WWKSPC_XFILEDETAIL.SKIP_FLAG;
            fileDetail.NOT_EXIST_SKIP_FG = WWKSPC_XFILEDETAIL.NOT_EXIST_SKIP_FG;
            fileDetail.ABORTCONTINUE_FLAG = WWKSPC_XFILEDETAIL.ABORTCONTINUE_FLAG;
            fileDetail.CRT_FG = WWKSPC_XFILEDETAIL.CRT_FG;
            fileDetail.CHK_FG = WWKSPC_XFILEDETAIL.CHK_FG;
            fileDetail.UNZIP_FG = WWKSPC_XFILEDETAIL.UNZIP_FG;
            fileDetail.ZIP_PW = encryptionSeq;
            fileDetail.FILE_AMT_NM = WWKSPC_XFILEDETAIL.FILE_AMT_NM;
            fileDetail.TOLERANCE = WWKSPC_XFILEDETAIL.TOLERANCE;
            fileDetail.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
            fileDetail.LST_MAINT_DT = DateTime.Now;
            db.WWKSPC_XFILEDETAIL.Add(fileDetail);

            // WWKSPC_XFLATFILEDETAIL
            // 用data.RAGGED_FIX是否為空，來判斷flatFile存在與否
            if (!string.IsNullOrEmpty(WWKSPC_XFILEDETAIL.RAGGED_FIX))
            {
                WWKSPC_XFLATFILEDETAIL xflatFile = new WWKSPC_XFLATFILEDETAIL();
                xflatFile.DATACAT = WWKSPC_XFILEDETAIL.DATACAT;
                xflatFile.FILE_SEQ = WWKSPC_XFILEDETAIL.FILE_SEQ;
                xflatFile.FILE_GROUP = WWKSPC_XFILEDETAIL.FILE_GROUP;
                xflatFile.CODEPAGE = WWKSPC_XFILEDETAIL.CODEPAGE;
                xflatFile.RAGGED_FIX = WWKSPC_XFILEDETAIL.RAGGED_FIX;
                xflatFile.RECORDLEN = WWKSPC_XFILEDETAIL.RECORDLEN;
                xflatFile.RAGGEDLEN = WWKSPC_XFILEDETAIL.RAGGEDLEN;
                xflatFile.DELIMITER = WWKSPC_XFILEDETAIL.DELIMITER;
                xflatFile.TERMINATOR = WWKSPC_XFILEDETAIL.TERMINATOR;
                xflatFile.FIRSTROW = WWKSPC_XFILEDETAIL.FIRSTROW;
                xflatFile.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                xflatFile.LST_MAINT_DT = DateTime.Now;

                db.WWKSPC_XFLATFILEDETAIL.Add(xflatFile);
            }

            try
            {
                await db.SaveChangesAsync();
                update_StgTable_SRC_TB(WWKSPC_XFILEDETAIL.DATACAT, WWKSPC_XFILEDETAIL.LST_MAINT_USR);
            }
            catch (DbUpdateException)
            {
                if (WWKSPC_XFILEDETAILExists(WWKSPC_XFILEDETAIL.DATACAT, WWKSPC_XFILEDETAIL.FILE_SEQ, WWKSPC_XFILEDETAIL.LST_MAINT_USR))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            WWKSPC_XFILEDETAIL.ZIP_PW_Value = WWKSPC_XFILEDETAIL.ZIP_PW;
            WWKSPC_XFILEDETAIL.ZIP_PW = encryptionSeq;
            return Created(WWKSPC_XFILEDETAIL);
        }


        // POST odata/WWKSPC_XFILEDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]int FILE_SEQ, [FromODataUri] string LST_MAINT_USR, Flow_Insert_WwkspcFileDetail_List_Data WWKSPC_XFILEDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            string encryptionSeq = string.IsNullOrEmpty(WWKSPC_XFILEDETAIL.ZIP_PW) ? null : WWKSPC_XFILEDETAIL.ZIP_PW;

            // XENCRYPTION_TEMP - Delete
            var result = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == WWKSPC_XFILEDETAIL.DATACAT && o.FILE_SEQ == WWKSPC_XFILEDETAIL.FILE_SEQ && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR).ToList();
            if (result.Count() > 0)
            {
                // 如果舊密碼不是空值，而且舊密碼不等於新密碼，則刪除舊有的密碼
                if (!string.IsNullOrEmpty(result.First().ZIP_PW) && result.First().ZIP_PW != encryptionSeq)
                {
                    string seq = result.First().ZIP_PW;
                    db.WWKSPC_XENCRYPTION.RemoveRange(db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == seq));
                }
            }

            // XENCRYPTION_TEMP - Add
            if (!string.IsNullOrEmpty(WWKSPC_XFILEDETAIL.ZIP_PW))
            {
                string encryptionValue;

                if (db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == WWKSPC_XFILEDETAIL.DATACAT && o.FILE_SEQ == WWKSPC_XFILEDETAIL.FILE_SEQ && o.ZIP_PW == WWKSPC_XFILEDETAIL.ZIP_PW && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR).Count() == 0)
                {
                    encryptionSeq = Guid.NewGuid().ToString().ToLower();

                    WWKSPC_XENCRYPTION encryption = new WWKSPC_XENCRYPTION();
                    encryption.SEQ = encryptionSeq;
                    encryption.VALUE = WWKSPC_XFILEDETAIL.ZIP_PW;
                    encryption.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                    encryption.LST_MAINT_DT = DateTime.Now;

                    db.WWKSPC_XENCRYPTION.Add(encryption);

                    encryptionValue = db.Database.SqlQuery<string>("select dbo.Encrypt(@Value)", new SqlParameter("Value", WWKSPC_XFILEDETAIL.ZIP_PW)).ToList().First();
                    WWKSPC_XFILEDETAIL.ZIP_PW = encryptionValue;
                }
                //else
                //{
                //    WWKSPC_XENCRYPTION encryption = db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == WWKSPC_XFILEDETAIL.ZIP_PW && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR).First();
                //    encryption.VALUE = 
                    
                //    encryptionValue = db.Database.SqlQuery<string>("select dbo.Encrypt(@Value)", new SqlParameter("Value", encryptionValue)).ToList().First();
                //    WWKSPC_XFILEDETAIL.ZIP_PW = encryptionValue;
                //}
            }

            // WWKSPC_XFILEDETAIL
            if (result.Count() > 0)
            {
                WWKSPC_XFILEDETAIL fileDetail = result.First();

                // 判斷 UNZIP_FG 是否取消勾選，是的話需同步清除被設定的 PARENT_FILENAME
                if (fileDetail.UNZIP_FG == "Y" && WWKSPC_XFILEDETAIL.UNZIP_FG == "N")
                {
                    var childFile = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.PARENT_FILENAME == fileDetail.SRCNAME && o.LST_MAINT_USR == LST_MAINT_USR);

                    foreach (WWKSPC_XFILEDETAIL file in childFile)
                    {
                        file.PARENT_FILENAME = null;
                        file.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                        file.LST_MAINT_DT = DateTime.Now;
                        db.Entry(file).State = EntityState.Modified;
                    }
                }
                // 判斷 SRCNAME 是否有異動，並且 UNZIP_FG 設為 Y，是的話需同步更新被設定的 PARENT_FILENAME
                else if (fileDetail.SRCNAME != WWKSPC_XFILEDETAIL.SRCNAME && WWKSPC_XFILEDETAIL.UNZIP_FG == "Y")
                {
                    var childFile = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.PARENT_FILENAME == fileDetail.SRCNAME && o.LST_MAINT_USR == LST_MAINT_USR);

                    foreach (WWKSPC_XFILEDETAIL file in childFile)
                    {
                        file.PARENT_FILENAME = WWKSPC_XFILEDETAIL.SRCNAME;
                        file.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                        file.LST_MAINT_DT = DateTime.Now;
                        db.Entry(file).State = EntityState.Modified;
                    }
                }

                fileDetail.PROCESS_TYPE = WWKSPC_XFILEDETAIL.PROCESS_TYPE;
                fileDetail.RSEQ = WWKSPC_XFILEDETAIL.RSEQ;
                fileDetail.LSEQ = WWKSPC_XFILEDETAIL.LSEQ;
                fileDetail.FILENAME = WWKSPC_XFILEDETAIL.FILENAME;
                fileDetail.SRCNAME = WWKSPC_XFILEDETAIL.SRCNAME;
                fileDetail.SRCCNAME = WWKSPC_XFILEDETAIL.SRCCNAME;
                fileDetail.PARENT_FILENAME = WWKSPC_XFILEDETAIL.PARENT_FILENAME;
                fileDetail.SKIP_FLAG = WWKSPC_XFILEDETAIL.SKIP_FLAG;
                fileDetail.NOT_EXIST_SKIP_FG = WWKSPC_XFILEDETAIL.NOT_EXIST_SKIP_FG;
                fileDetail.ABORTCONTINUE_FLAG = WWKSPC_XFILEDETAIL.ABORTCONTINUE_FLAG;
                fileDetail.CRT_FG = WWKSPC_XFILEDETAIL.CRT_FG;
                fileDetail.CHK_FG = WWKSPC_XFILEDETAIL.CHK_FG;
                fileDetail.UNZIP_FG = WWKSPC_XFILEDETAIL.UNZIP_FG;
                fileDetail.ZIP_PW = encryptionSeq;
                fileDetail.FILE_AMT_NM = WWKSPC_XFILEDETAIL.FILE_AMT_NM;
                fileDetail.TOLERANCE = WWKSPC_XFILEDETAIL.TOLERANCE;

                fileDetail.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                fileDetail.LST_MAINT_DT = DateTime.Now;

                //db.Entry(fileDetail).State = EntityState.Modified;
            }

            var oldFlatFile = db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == WWKSPC_XFILEDETAIL.DATACAT && o.FILE_SEQ == WWKSPC_XFILEDETAIL.FILE_SEQ && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR).ToList();

            // 判斷 FILE_GROUP 是否有異動，並且無其他相同的 FILE_GROUP，是的話需同步異動相關的 XJOBDETAIL
            // 若是取消設定 FILE_GROUP，不同步更新資料，前端必須顯示警示訊息，請使用者自行選擇新的 FILE_GROUP
            if (oldFlatFile.Count() > 0)
            {
                string oldFileGroup = oldFlatFile.First().FILE_GROUP;

                if (oldFileGroup != WWKSPC_XFILEDETAIL.FILE_GROUP && !string.IsNullOrEmpty(WWKSPC_XFILEDETAIL.RAGGED_FIX)
                 && db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == WWKSPC_XFILEDETAIL.DATACAT && o.FILE_GROUP == oldFileGroup && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR).Count() == 1)
                {
                    var jobDetail = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == WWKSPC_XFILEDETAIL.DATACAT && o.JOB_NAME == "IS_StgTable_FlatFile" && o.PARAM.IndexOf(oldFileGroup) > 0 && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR).ToList();

                    foreach (WWKSPC_XJOBDETAIL job in jobDetail)
                    {
                        job.PARAM = job.PARAM.Replace(oldFileGroup, WWKSPC_XFILEDETAIL.FILE_GROUP);
                        job.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                        job.LST_MAINT_DT = DateTime.Now;
                        db.Entry(job).State = EntityState.Modified;
                    }
                }
            }


            // WWKSPC_XFLATFILEDETAIL - Delete
            db.WWKSPC_XFLATFILEDETAIL.RemoveRange(db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == WWKSPC_XFILEDETAIL.DATACAT && o.FILE_SEQ == WWKSPC_XFILEDETAIL.FILE_SEQ && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR));

            // WWKSPC_XFLATFILEDETAIL - Add
            // 用data.RAGGED_FIX是否為空，來判斷flatFile存在與否
            if (!string.IsNullOrEmpty(WWKSPC_XFILEDETAIL.RAGGED_FIX))
            {
                WWKSPC_XFLATFILEDETAIL xflatFile = new WWKSPC_XFLATFILEDETAIL();
                xflatFile.DATACAT = WWKSPC_XFILEDETAIL.DATACAT;
                xflatFile.FILE_SEQ = WWKSPC_XFILEDETAIL.FILE_SEQ;
                xflatFile.FILE_GROUP = WWKSPC_XFILEDETAIL.FILE_GROUP;
                xflatFile.CODEPAGE = WWKSPC_XFILEDETAIL.CODEPAGE;
                xflatFile.RAGGED_FIX = WWKSPC_XFILEDETAIL.RAGGED_FIX;
                xflatFile.RECORDLEN = WWKSPC_XFILEDETAIL.RECORDLEN;
                xflatFile.RAGGEDLEN = WWKSPC_XFILEDETAIL.RAGGEDLEN;
                xflatFile.DELIMITER = WWKSPC_XFILEDETAIL.DELIMITER;
                xflatFile.TERMINATOR = WWKSPC_XFILEDETAIL.TERMINATOR;
                xflatFile.FIRSTROW = WWKSPC_XFILEDETAIL.FIRSTROW;
                xflatFile.LST_MAINT_USR = WWKSPC_XFILEDETAIL.LST_MAINT_USR;
                xflatFile.LST_MAINT_DT = DateTime.Now;

                db.WWKSPC_XFLATFILEDETAIL.Add(xflatFile);
            }

            // 如果舊密碼不是空值，而且舊密碼不等於新密碼，則更新回傳新的密碼
            if (!string.IsNullOrEmpty(result.First().ZIP_PW) && result.First().ZIP_PW != WWKSPC_XFILEDETAIL.ZIP_PW)
            {
                WWKSPC_XFILEDETAIL.ZIP_PW_Value = WWKSPC_XFILEDETAIL.ZIP_PW;
                WWKSPC_XFILEDETAIL.ZIP_PW = encryptionSeq;
            }
            else
            {
                var encryptionList = db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == WWKSPC_XFILEDETAIL.ZIP_PW && o.LST_MAINT_USR == WWKSPC_XFILEDETAIL.LST_MAINT_USR).ToList();

                if (encryptionList.Count() > 0)
                {
                    WWKSPC_XFILEDETAIL.ZIP_PW_Value = db.Database.SqlQuery<string>("select dbo.Encrypt(@Value)", new SqlParameter("Value", encryptionList.First().VALUE)).ToList().First();
                }
            }

            try
            {
                await db.SaveChangesAsync();
                update_StgTable_SRC_TB(WWKSPC_XFILEDETAIL.DATACAT, WWKSPC_XFILEDETAIL.LST_MAINT_USR);
            }
            catch (DbUpdateException)
            {
                if (WWKSPC_XFILEDETAILExists(WWKSPC_XFILEDETAIL.DATACAT, WWKSPC_XFILEDETAIL.FILE_SEQ, WWKSPC_XFILEDETAIL.LST_MAINT_USR))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XFILEDETAIL);
        }

        /// <summary>
        /// 自動更新 WWKSPC_XJOBDETAIL 的 SRC_TB
        /// SRC_TB 以 SrcFileGroup 對應相關的 WWKSPC_XFLATFILEDETAIL，再找到 WWKSPC_XFILEDETAIL 的 SRCNAME
        /// 多個 WWKSPC_XFILEDETAIL 可能會是相同的 FILE_GROUP，因此 SRC_TB 的內容會是 A||B||C
        /// </summary>
        /// <param name="DATACAT"></param>
        /// <param name="LST_MAINT_USR"></param>
        private void update_StgTable_SRC_TB(string DATACAT, string LST_MAINT_USR)
        {
            var jobDetail = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.JOB_NAME == "IS_StgTable_FlatFile" && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

            foreach (WWKSPC_XJOBDETAIL job in jobDetail)
            {
                if (!string.IsNullOrEmpty(job.PARAM))
                {
                    string SrcFileGroup = job.PARAM.Split(';')[0].Replace("SrcFileGroup=", "");

                    var flatFileDetail = db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.FILE_GROUP == SrcFileGroup && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                    string srcTable = string.Empty;

                    foreach (WWKSPC_XFLATFILEDETAIL file in flatFileDetail)
                    {
                        string fileName = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.FILE_SEQ == file.FILE_SEQ && o.LST_MAINT_USR == LST_MAINT_USR).First().SRCNAME;
                        srcTable += fileName + "||";
                    }

                    if (!string.IsNullOrEmpty(srcTable))
                    {
                        job.SRC_TB = srcTable.Substring(0, srcTable.Length - 2);
                        db.Entry(job).State = EntityState.Modified;
                    }
                }
            }

            try
            {
                db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private bool WWKSPC_XFILEDETAILExists(string DATACAT, int FILE_SEQ, string LST_MAINT_USR)
        {
            return db.WWKSPC_XFILEDETAIL.Count(o => o.DATACAT == DATACAT && o.FILE_SEQ == FILE_SEQ && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
