﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcJobDetail_DeleteInsertController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XJOBDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcJobDetail_DeleteInsert WWKSPC_XJOBDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (WWKSPC_XJOBDETAIL jobDetailTemp in WWKSPC_XJOBDETAIL.DeleteDetail)
            {
                // 刪除的是工作流程，同步刪除底下的工作群組、工作項目
                if (jobDetailTemp.DATACAT == jobDetailTemp.JOB_STAGE)
                {
                    string stageName = jobDetailTemp.JOB_NAME.Replace("RunJobFlow", "");
                    var jobs = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == jobDetailTemp.DATACAT && o.JOB_STAGE == stageName && o.LST_MAINT_USR == jobDetailTemp.LST_MAINT_USR);
                    db.WWKSPC_XJOBDETAIL.RemoveRange(jobs);
                }

                // 刪除的是工作群組，同步刪除底下的工作項目
                if (jobDetailTemp.JOB_SEQ == 0)
                {
                    var jobs = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == jobDetailTemp.DATACAT && o.JOB_STAGE == jobDetailTemp.JOB_STAGE && o.JOB_FLOW == jobDetailTemp.JOB_FLOW && o.JOB_SEQ > 0 && o.LST_MAINT_USR == jobDetailTemp.LST_MAINT_USR);
                    db.WWKSPC_XJOBDETAIL.RemoveRange(jobs);
                }

                db.WWKSPC_XJOBDETAIL.RemoveRange(db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == jobDetailTemp.DATACAT
                                                                        && o.JOB_STAGE == jobDetailTemp.JOB_STAGE
                                                                        && o.JOB_FLOW == jobDetailTemp.JOB_FLOW
                                                                        && o.JOB_SEQ == jobDetailTemp.JOB_SEQ
                                                                        && o.LST_MAINT_USR == jobDetailTemp.LST_MAINT_USR));
            }

            // 新增作業，在排序拖拉時，才會有新增的資料
            foreach (WWKSPC_XJOBDETAIL jobDetailTemp in WWKSPC_XJOBDETAIL.InsertDetail)
            {
                jobDetailTemp.LST_MAINT_DT = DateTime.Now;
                db.WWKSPC_XJOBDETAIL.Add(jobDetailTemp);
            }

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return Updated(WWKSPC_XJOBDETAIL);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
