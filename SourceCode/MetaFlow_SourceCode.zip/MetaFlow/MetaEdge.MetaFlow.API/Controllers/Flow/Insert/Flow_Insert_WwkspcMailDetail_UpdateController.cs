﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcMailDetail_UpdateController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XMAILDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcMailDetail_Update WWKSPC_XMAILDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (WWKSPC_XMAILDETAIL.MAILADR != WWKSPC_XMAILDETAIL.Old_MAILADR)
                    {
                        if (WWKSPC_XMAILDETAILExists(WWKSPC_XMAILDETAIL.DATACAT, WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.LST_MAINT_USR))
                        {
                            return Conflict();
                        }
                    }

                    #region [ delete mailDetails ]
                    db.Database.ExecuteSqlCommand("delete from dbo.WWKSPC_XMAILDETAIL where DATACAT=@DATACAT and MAILADR=@MAILADR and LST_MAINT_USR=@LST_MAINT_USR;"
                        , new SqlParameter("DATACAT", WWKSPC_XMAILDETAIL.DATACAT)
                        , new SqlParameter("MAILADR", WWKSPC_XMAILDETAIL.Old_MAILADR)
                        , new SqlParameter("LST_MAINT_USR", WWKSPC_XMAILDETAIL.LST_MAINT_USR));
                    #endregion

                    if (WWKSPC_XMAILDETAIL.notifyRUNOK_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "RUNOK", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    if (WWKSPC_XMAILDETAIL.notifyABORT_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "ABORT", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    if (WWKSPC_XMAILDETAIL.notifyMONITOR_FILE_WAIT_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "MONITOR FILE WAIT", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    if (WWKSPC_XMAILDETAIL.notifyMONITOR_FLOW_TIME_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "MONITOR FLOW TIME", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(WWKSPC_XMAILDETAIL);
        }

        private bool WWKSPC_XMAILDETAILExists(string DATACAT, string MAILADR, string LST_MAINT_USR)
        {
            return db.WWKSPC_XMAILDETAIL.Count(WWKSPC_XMAILDETAIL => WWKSPC_XMAILDETAIL.DATACAT == DATACAT && WWKSPC_XMAILDETAIL.MAILADR == MAILADR && WWKSPC_XMAILDETAIL.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
