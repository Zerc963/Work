﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_JobDetail_DropDown_FlatFileController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<DropDownEntity> Get([FromODataUri]string DATACAT)
        {
            var result = (from s1 in db.XFLATFILEDETAIL
                          where s1.DATACAT == DATACAT
                          group s1 by s1.FILE_GROUP into s2

                          select new
                          {
                              FILE_GROUP = s2.Key
                          })
                          .OrderBy(o => o.FILE_GROUP)
                          .ToList();

            List<DropDownEntity> list = new List<DropDownEntity>();
            foreach (var file in result)
            {
                DropDownEntity option = new DropDownEntity();
                option.OptionText = file.FILE_GROUP;
                option.OptionValue = file.FILE_GROUP;
                list.Add(option);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
