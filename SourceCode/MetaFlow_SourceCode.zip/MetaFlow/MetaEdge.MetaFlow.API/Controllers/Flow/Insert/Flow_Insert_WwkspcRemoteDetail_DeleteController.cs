﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcRemoteDetail_DeleteController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XREMOTEDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcRemoteDetail_Delete WWKSPC_XREMOTEDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (WWKSPC_XREMOTEDETAIL RemoteDetailTemp in WWKSPC_XREMOTEDETAIL.Detail)
            {
                db.WWKSPC_XREMOTEDETAIL.RemoveRange(db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == RemoteDetailTemp.DATACAT
                                                                              && o.RSEQ == RemoteDetailTemp.RSEQ
                                                                              && o.LST_MAINT_USR == RemoteDetailTemp.LST_MAINT_USR));
            }

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return Updated(WWKSPC_XREMOTEDETAIL);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
