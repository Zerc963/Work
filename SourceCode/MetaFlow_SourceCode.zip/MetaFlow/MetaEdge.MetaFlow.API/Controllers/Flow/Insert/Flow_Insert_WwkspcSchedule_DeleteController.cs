﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcSchedule_DeleteController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XSCHEDULE
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcSchedule_Delete WWKSPC_XSCHEDULE)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (WWKSPC_XSCHEDULE scheduleTemp in WWKSPC_XSCHEDULE.Detail)
            {
                db.WWKSPC_XSCHEDULE.RemoveRange(db.WWKSPC_XSCHEDULE.Where(o => o.PROCESS_TYPE == scheduleTemp.PROCESS_TYPE
                                                                        && o.START_TIME == scheduleTemp.START_TIME
                                                                        && o.LST_MAINT_USR == scheduleTemp.LST_MAINT_USR));
            }

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }

            return Updated(WWKSPC_XSCHEDULE);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
