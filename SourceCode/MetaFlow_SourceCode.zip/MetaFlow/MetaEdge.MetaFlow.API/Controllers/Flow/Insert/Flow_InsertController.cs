﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_InsertController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        /**
        public async Task<IHttpActionResult> Post(Flow_Insert FlowInsert)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                SqlParameter[] SqlParam = new SqlParameter[2];
                SqlParam[0] = new SqlParameter("@DATACAT", FlowInsert.FlowDetail.DATACAT);
                SqlParam[1] = new SqlParameter("@LST_MAINT_USR", FlowInsert.FlowDetail.LST_MAINT_USR);
                db.Database.ExecuteSqlCommand("WSP_INS_XFlowTable @DATACAT,@LST_MAINT_USR", SqlParam);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return StatusCode(HttpStatusCode.Created);
        }
        **/

        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert FlowInsert)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                // 1. XFLOWDETAIL
                FlowInsert.FlowDetail.LST_MAINT_DT = DateTime.Now;
                db.XFLOWDETAIL.Add(FlowInsert.FlowDetail);

                db.WWKSPC_XFLOWDETAIL.RemoveRange(db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 2. XSCHEDULE
                foreach (XSCHEDULE schedule in FlowInsert.Schedule)
                {
                    schedule.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    schedule.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    schedule.LST_MAINT_DT = DateTime.Now;
                    db.XSCHEDULE.Add(schedule);
                }

                db.WWKSPC_XSCHEDULE.RemoveRange(db.WWKSPC_XSCHEDULE.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 3-1. XLOCALDETAIL
                foreach (XLOCALDETAIL local in FlowInsert.LocalDetail)
                {
                    local.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    local.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    local.LST_MAINT_DT = DateTime.Now;
                    db.XLOCALDETAIL.Add(local);
                }

                db.WWKSPC_XLOCALDETAIL.RemoveRange(db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 3-2. XREMOTEDETAIL
                foreach (XREMOTEDETAIL remote in FlowInsert.RemoteDetail)
                {
                    remote.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    remote.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    remote.LST_MAINT_DT = DateTime.Now;
                    db.XREMOTEDETAIL.Add(remote);
                }

                db.WWKSPC_XREMOTEDETAIL.RemoveRange(db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 4. XWAITDETAIL
                foreach (XWAITDETAIL wait in FlowInsert.WaitDetail)
                {
                    wait.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    wait.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    wait.LST_MAINT_DT = DateTime.Now;
                    db.XWAITDETAIL.Add(wait);
                }

                db.WWKSPC_XWAITDETAIL.RemoveRange(db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 5. XFILEDETAIL + XENCRYPTION + XFLATFILEDETAIL
                foreach (Flow_Insert_FileDetail_List_Data file in FlowInsert.FileDetail)
                {
                    // 5-1 XENCRYPTION
                    if (!string.IsNullOrEmpty(file.ZIP_PW))
                    {
                        XENCRYPTION encryption = new XENCRYPTION();
                        encryption.SEQ = file.ZIP_PW;

                        encryption.VALUE = db.Database.SqlQuery<string>("select dbo.Decrypt(@Value)", new SqlParameter("Value", file.ZIP_PW_Value)).ToList().First();

                        encryption.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                        encryption.LST_MAINT_DT = DateTime.Now;

                        db.XENCRYPTION.Add(encryption);

                        db.WWKSPC_XENCRYPTION.RemoveRange(db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == file.ZIP_PW));
                    }
                    
                    //5-2 XFILEDETAIL
                    XFILEDETAIL fileDetail = new XFILEDETAIL();
                    fileDetail.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    fileDetail.PROCESS_TYPE = file.PROCESS_TYPE;
                    fileDetail.FILE_SEQ = file.FILE_SEQ;
                    fileDetail.RSEQ = file.RSEQ;
                    fileDetail.LSEQ = file.LSEQ;
                    fileDetail.FILENAME = file.FILENAME;
                    fileDetail.SRCNAME = file.SRCNAME;
                    fileDetail.SRCCNAME = file.SRCCNAME;
                    fileDetail.PARENT_FILENAME = file.PARENT_FILENAME;
                    fileDetail.SKIP_FLAG = file.SKIP_FLAG;
                    fileDetail.NOT_EXIST_SKIP_FG = file.NOT_EXIST_SKIP_FG;
                    fileDetail.ABORTCONTINUE_FLAG = file.ABORTCONTINUE_FLAG;
                    fileDetail.CRT_FG = file.CRT_FG;
                    fileDetail.CHK_FG = file.CHK_FG;
                    fileDetail.UNZIP_FG = file.UNZIP_FG;
                    fileDetail.ZIP_PW = file.ZIP_PW;
                    fileDetail.FILE_AMT_NM = file.FILE_AMT_NM;
                    fileDetail.TOLERANCE = file.TOLERANCE;
                    fileDetail.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    fileDetail.LST_MAINT_DT = DateTime.Now;
                    db.XFILEDETAIL.Add(fileDetail);

                    // 5-3 XFLATFILEDETAIL
                    // 用data.RAGGED_FIX是否為空，來判斷flatFile存在與否
                    if (!string.IsNullOrEmpty(file.RAGGED_FIX))
                    {
                        XFLATFILEDETAIL xflatFile = new XFLATFILEDETAIL();
                        xflatFile.DATACAT = FlowInsert.FlowDetail.DATACAT;
                        xflatFile.FILE_SEQ = file.FILE_SEQ;
                        xflatFile.FILE_GROUP = file.FILE_GROUP;
                        xflatFile.CODEPAGE = file.CODEPAGE;
                        xflatFile.RAGGED_FIX = file.RAGGED_FIX;
                        xflatFile.RECORDLEN = file.RECORDLEN;
                        xflatFile.RAGGEDLEN = file.RAGGEDLEN;
                        xflatFile.DELIMITER = file.DELIMITER;
                        xflatFile.TERMINATOR = file.TERMINATOR;
                        xflatFile.FIRSTROW = file.FIRSTROW;
                        xflatFile.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                        xflatFile.LST_MAINT_DT = DateTime.Now;

                        db.XFLATFILEDETAIL.Add(xflatFile);
                    }
                }

                db.WWKSPC_XFILEDETAIL.RemoveRange(db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));
                db.WWKSPC_XFLATFILEDETAIL.RemoveRange(db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 6. XJOBDETAIL
                foreach (XJOBDETAIL job in FlowInsert.JobDetail)
                {
                    job.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    job.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    job.LST_MAINT_DT = DateTime.Now;
                    db.XJOBDETAIL.Add(job);
                }

                db.WWKSPC_XJOBDETAIL.RemoveRange(db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 7-1. XMAILDETAIL
                foreach (XMAILDETAIL_List_Data detail in FlowInsert.MailDetail.mailDetail)
                {
                    if (detail.notifyRUNOK_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(FlowInsert.FlowDetail.DATACAT, "RUNOK", detail.MAILADR, detail.MAIL_DESC, FlowInsert.FlowDetail.LST_MAINT_USR, DateTime.Now));
                    }
                    if (detail.notifyABORT_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(FlowInsert.FlowDetail.DATACAT, "ABORT", detail.MAILADR, detail.MAIL_DESC, FlowInsert.FlowDetail.LST_MAINT_USR, DateTime.Now));
                    }
                    //if (detail.notifyCHECK_FILE_REPORT_fg)
                    //{
                    //    db.XMAILDETAIL.Add(new XMAILDETAIL(FlowInsert.FlowDetail.DATACAT, "CHECK FILE REPORT", detail.MAILADR, detail.MAIL_DESC, FlowInsert.FlowDetail.LST_MAINT_USR, DateTime.Now));
                    //}
                    //if (detail.notifyFLOW_REPORT_fg)
                    //{
                    //    db.XMAILDETAIL.Add(new XMAILDETAIL(FlowInsert.FlowDetail.DATACAT, "FLOW REPORT", detail.MAILADR, detail.MAIL_DESC, FlowInsert.FlowDetail.LST_MAINT_USR, DateTime.Now));
                    //}
                    if (detail.notifyMONITOR_FILE_WAIT_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(FlowInsert.FlowDetail.DATACAT, "MONITOR FILE WAIT", detail.MAILADR, detail.MAIL_DESC, FlowInsert.FlowDetail.LST_MAINT_USR, DateTime.Now));
                    }
                    if (detail.notifyMONITOR_FLOW_TIME_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(FlowInsert.FlowDetail.DATACAT, "MONITOR FLOW TIME", detail.MAILADR, detail.MAIL_DESC, FlowInsert.FlowDetail.LST_MAINT_USR, DateTime.Now));
                    }
                }

                db.WWKSPC_XMAILDETAIL.RemoveRange(db.WWKSPC_XMAILDETAIL.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 7-2. XMONITOR_FILEWAIT
                if (FlowInsert.MailDetail.FILEWAIT_checked)
                {
                    XMONITOR_FILEWAIT monitorFileWait = FlowInsert.MailDetail.XMONITOR_FILEWAIT;
                    monitorFileWait.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    monitorFileWait.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    monitorFileWait.LST_MAINT_DT = DateTime.Now;
                    db.XMONITOR_FILEWAIT.Add(monitorFileWait);
                }

                db.WWKSPC_XMONITOR_FILEWAIT.RemoveRange(db.WWKSPC_XMONITOR_FILEWAIT.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                // 7-3. XMONITOR_FLOWTIME
                if (FlowInsert.MailDetail.FLOWTIME_checked)
                {
                    XMONITOR_FLOWTIME monitorFlowtime = FlowInsert.MailDetail.XMONITOR_FLOWTIME;
                    monitorFlowtime.DATACAT = FlowInsert.FlowDetail.DATACAT;
                    monitorFlowtime.LST_MAINT_USR = FlowInsert.FlowDetail.LST_MAINT_USR;
                    monitorFlowtime.LST_MAINT_DT = DateTime.Now;
                    db.XMONITOR_FLOWTIME.Add(monitorFlowtime);
                }

                db.WWKSPC_XMONITOR_FLOWTIME.RemoveRange(db.WWKSPC_XMONITOR_FLOWTIME.Where(o => o.DATACAT == FlowInsert.FlowDetail.DATACAT && o.LST_MAINT_USR == FlowInsert.FlowDetail.LST_MAINT_USR));

                try
                {
                    await db.SaveChangesAsync();

                    SqlParameter[] SqlParam = new SqlParameter[1];
                    SqlParam[0] = new SqlParameter("@DATACAT", FlowInsert.FlowDetail.DATACAT);
                    db.Database.ExecuteSqlCommand("WSP_INS_XFlowStatus @DATACAT", SqlParam);

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(FlowInsert);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
