﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcMailDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<Flow_Insert_WwkspcMailDetail_List> Get([FromODataUri]string DATACAT, [FromODataUri]string LST_MAINT_USR)
        {
            var resultSet = (from s1 in db.WWKSPC_XMAILDETAIL

                             where s1.DATACAT == DATACAT
                                && s1.LST_MAINT_USR == LST_MAINT_USR
                             group s1 by new { s1.DATACAT, s1.MAILADR, s1.MAIL_DESC } into s2

                             select new
                             {
                                 DATACAT = s2.Key.DATACAT
                                 ,
                                 MAILADR = s2.Key.MAILADR
                                 ,
                                 MAIL_DESC = s2.Key.MAIL_DESC
                                 ,
                                 notifyRUNOK_fg = (s2.Sum(o => o.MAIL_TYPE == "RUNOK" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyABORT_fg = (s2.Sum(o => o.MAIL_TYPE == "ABORT" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyMONITOR_FILE_WAIT_fg = (s2.Sum(o => o.MAIL_TYPE == "MONITOR FILE WAIT" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyMONITOR_FLOW_TIME_fg = (s2.Sum(o => o.MAIL_TYPE == "MONITOR FLOW TIME" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 LST_MAINT_USR = s2.Min(o => o.LST_MAINT_USR)
                                 ,
                                 LST_MAINT_DT = s2.Max(o => o.LST_MAINT_DT)
                             });

            List<Flow_Insert_WwkspcMailDetail_List> list = new List<Flow_Insert_WwkspcMailDetail_List>();

            foreach (var item in resultSet)
            {
                Flow_Insert_WwkspcMailDetail_List mail = new Flow_Insert_WwkspcMailDetail_List();
                mail.DATACAT = item.DATACAT;
                mail.MAILADR = item.MAILADR;
                mail.MAIL_DESC = item.MAIL_DESC;
                mail.notifyRUNOK_fg = item.notifyRUNOK_fg;
                mail.notifyABORT_fg = item.notifyABORT_fg;
                mail.notifyMONITOR_FILE_WAIT_fg = item.notifyMONITOR_FILE_WAIT_fg;
                mail.notifyMONITOR_FLOW_TIME_fg = item.notifyMONITOR_FLOW_TIME_fg;
                mail.LST_MAINT_USR = item.LST_MAINT_USR;
                mail.LST_MAINT_DT = item.LST_MAINT_DT;

                list.Add(mail);
            }

            return list.AsQueryable();
        }

        // POST odata/WWKSPC_XFILEDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcMailDetail_List WWKSPC_XMAILDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (WWKSPC_XMAILDETAILExists(WWKSPC_XMAILDETAIL.DATACAT, WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.LST_MAINT_USR))
                    {
                        return Conflict();
                    }

                    if (WWKSPC_XMAILDETAIL.notifyRUNOK_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "RUNOK", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    if (WWKSPC_XMAILDETAIL.notifyABORT_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "ABORT", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    if (WWKSPC_XMAILDETAIL.notifyMONITOR_FILE_WAIT_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "MONITOR FILE WAIT", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    if (WWKSPC_XMAILDETAIL.notifyMONITOR_FLOW_TIME_fg)
                    {
                        db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, "MONITOR FLOW TIME", WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));
                    }

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(WWKSPC_XMAILDETAIL);
        }

        private bool WWKSPC_XMAILDETAILExists(string DATACAT, string MAILADR, string LST_MAINT_USR)
        {
            return db.WWKSPC_XMAILDETAIL.Count(WWKSPC_XMAILDETAIL => WWKSPC_XMAILDETAIL.DATACAT == DATACAT && WWKSPC_XMAILDETAIL.MAILADR == MAILADR && WWKSPC_XMAILDETAIL.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
