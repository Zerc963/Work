﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Insert_WwkspcMailDetail_InsertMailTypeController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/WWKSPC_XMAILDETAIL
        public async Task<IHttpActionResult> Post(Flow_Insert_WwkspcMailDetail_InsertMailType WWKSPC_XMAILDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (WWKSPC_XMAILDETAILExists(WWKSPC_XMAILDETAIL.DATACAT, WWKSPC_XMAILDETAIL.MAIL_TYPE, WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.LST_MAINT_USR))
                    {
                        return Conflict();
                    }

                    db.WWKSPC_XMAILDETAIL.Add(new WWKSPC_XMAILDETAIL(WWKSPC_XMAILDETAIL.DATACAT, WWKSPC_XMAILDETAIL.MAIL_TYPE, WWKSPC_XMAILDETAIL.MAILADR, WWKSPC_XMAILDETAIL.MAIL_DESC, WWKSPC_XMAILDETAIL.LST_MAINT_USR, WWKSPC_XMAILDETAIL.LST_MAINT_DT));

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(WWKSPC_XMAILDETAIL);
        }

        private bool WWKSPC_XMAILDETAILExists(string DATACAT, string MAIL_TYPE, string MAILADR, string LST_MAINT_USR)
        {
            return db.WWKSPC_XMAILDETAIL.Count(o => o.DATACAT == DATACAT && o.MAIL_TYPE == MAIL_TYPE && o.MAILADR == MAILADR && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
