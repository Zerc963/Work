﻿using MetaEdge.ISMD.Entity.Models;
using MetaEdge.MetaAuthWeb.Data.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WV_XBATCHFLOWViewController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<WV_XBATCHFLOWView> Get()
        {
            List<WV_XBATCHFLOWView> list = new List<WV_XBATCHFLOWView>();

            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            var resultSet = db.WV_XBATCHFLOW;

            foreach (var item in resultSet)
            {
                WV_XBATCHFLOWView batch = new WV_XBATCHFLOWView();

                batch.DATACAT = item.DATACAT;
                batch.BATCH_NO = item.BATCH_NO;
                batch.CYCLE_START = item.CYCLE_START;
                batch.CYCLE_END = item.CYCLE_END;
                batch.PROCESS_TYPE = item.PROCESS_TYPE;

                if (!string.IsNullOrEmpty(item.PROCESS_TYPE))
                {
                    var PROCESS_TYPENM = parameters.Where(o => o.TypeName == "FLOW_TYPE" && o.ParameterValue == item.PROCESS_TYPE.Trim()).ToList();
                    if (PROCESS_TYPENM.Count() > 0)
                    {
                        batch.PROCESS_TYPENM = PROCESS_TYPENM.First().ParameterName;
                    }
                }

                batch.JOB_STAGE = item.JOB_STAGE;
                batch.JOB_FLOW = item.JOB_FLOW;
                batch.JOB_SEQ = int.Parse(item.JOB_SEQ.ToString());
                batch.JOB_NAME = item.JOB_NAME;
                batch.START_MODE = item.START_MODE;

                if (!string.IsNullOrEmpty(item.START_MODE))
                {
                    var START_MODENM = parameters.Where(o => o.TypeName == "START_MODE" && o.ParameterValue == item.START_MODE.Trim()).ToList();
                    if (START_MODENM.Count() > 0)
                    {
                        batch.START_MODENM = START_MODENM.First().ParameterName;
                    }
                }

                batch.JOB_START_TIME = item.JOB_START_TIME;
                batch.JOB_END_TIME = item.JOB_END_TIME;
                batch.RUN_STATUS = item.RUN_STATUS;

                if (!string.IsNullOrEmpty(item.RUN_STATUS))
                {
                    var RUN_STATUSNM = parameters.Where(o => o.TypeName == "RUN_STATUS" && o.ParameterValue == item.RUN_STATUS.Trim()).ToList();
                    if (RUN_STATUSNM.Count() > 0)
                    {
                        batch.RUN_STATUSNM = RUN_STATUSNM.First().ParameterName;
                    }
                }

                batch.INS_CNT = item.INS_CNT == null ? 0: item.INS_CNT;
                batch.UPD_CNT = item.UPD_CNT == null ? 0: item.UPD_CNT;
                batch.DEL_CNT = item.DEL_CNT == null ? 0: item.DEL_CNT;
                batch.SRC_TB = item.SRC_TB;
                batch.TGT_TB = item.TGT_TB;
                batch.PARAM = item.PARAM;
                batch.SKIP_FLAG = item.SKIP_FLAG;

                if (!string.IsNullOrEmpty(item.SKIP_FLAG))
                {
                    var SKIP_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.SKIP_FLAG.Trim()).ToList();
                    if (SKIP_FLAGNM.Count() > 0)
                    {
                        batch.SKIP_FLAGNM = SKIP_FLAGNM.First().ParameterName;
                    }
                }

                batch.FORK_FLAG = item.FORK_FLAG;

                if (!string.IsNullOrEmpty(item.FORK_FLAG))
                {
                    var FORK_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.FORK_FLAG.Trim()).ToList();
                    if (FORK_FLAGNM.Count() > 0)
                    {
                        batch.FORK_FLAGNM = FORK_FLAGNM.First().ParameterName;
                    }
                }

                batch.ABORTCONTINUE_FLAG = item.ABORTCONTINUE_FLAG;

                if (!string.IsNullOrEmpty(item.ABORTCONTINUE_FLAG))
                {
                    var ABORTCONTINUE_FLAGNM = parameters.Where(o => o.TypeName == "YesNo_Flag" && o.ParameterValue == item.ABORTCONTINUE_FLAG.Trim()).ToList();
                    if (ABORTCONTINUE_FLAGNM.Count() > 0)
                    {
                        batch.ABORTCONTINUE_FLAGNM = ABORTCONTINUE_FLAGNM.First().ParameterName;
                    }
                }

                batch.JOB_TYPE = item.JOB_TYPE;

                if (!string.IsNullOrEmpty(item.JOB_TYPE))
                {
                    var JOB_TYPENM = parameters.Where(o => o.TypeName == "JOB_TYPE" && o.ParameterValue == item.JOB_TYPE.Trim()).ToList();
                    if (JOB_TYPENM.Count() > 0)
                    {
                        batch.JOB_TYPENM = JOB_TYPENM.First().ParameterName;
                    }
                }

                batch.JOB_DESC = item.JOB_DESC;
                batch.JOB_LOCATION = item.JOB_LOCATION;
                batch.JOB_OWNER = item.JOB_OWNER;
                batch.EXEC_DESC = item.EXEC_DESC;
                batch.EXECUTION_ID = item.EXECUTION_ID;
                batch.LST_MAINT_USR = item.LST_MAINT_USR;
                batch.LST_MAINT_DT = item.LST_MAINT_DT;
                batch.JOB_RUN_TIME = item.JOB_RUN_TIME;
                batch.JOB_SECOND = item.JOB_SECOND;
                batch.JOB_LEVEL = item.JOB_LEVEL;
                batch.RUN_SEQ = item.RUN_SEQ;
                batch.JOB_STAGE_REF = item.JOB_STAGE_REF;
                list.Add(batch);
            }

            return list.AsQueryable();
        }
    }
}
