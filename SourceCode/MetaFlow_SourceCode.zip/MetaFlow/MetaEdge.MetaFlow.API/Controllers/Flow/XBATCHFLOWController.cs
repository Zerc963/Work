﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XBATCHFLOWController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XBATCHFLOW> Get()
        {
            return db.XBATCHFLOW;
        }

        public async Task<IHttpActionResult> Put([FromODataUri] string DATACAT, [FromODataUri] string JOB_STAGE, [FromODataUri] int JOB_FLOW, [FromODataUri] int JOB_SEQ, XBATCHFLOW XBATCHFLOW)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (DATACAT != XBATCHFLOW.DATACAT || JOB_STAGE != XBATCHFLOW.JOB_STAGE || JOB_FLOW != XBATCHFLOW.JOB_FLOW || JOB_SEQ != XBATCHFLOW.JOB_SEQ)
            {
                return BadRequest();
            }

            db.Entry(XBATCHFLOW).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!XBATCHFLOWExists(DATACAT, JOB_STAGE, JOB_FLOW, JOB_SEQ))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(XBATCHFLOW);
        }

        private bool XBATCHFLOWExists(string DATACAT, string JOB_STAGE, int JOB_FLOW, int JOB_SEQ)
        {
            return db.XBATCHFLOW.Count(XBATCHFLOW => XBATCHFLOW.DATACAT == DATACAT && XBATCHFLOW.JOB_STAGE == JOB_STAGE && XBATCHFLOW.JOB_FLOW == JOB_FLOW && XBATCHFLOW.JOB_SEQ == JOB_SEQ) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
