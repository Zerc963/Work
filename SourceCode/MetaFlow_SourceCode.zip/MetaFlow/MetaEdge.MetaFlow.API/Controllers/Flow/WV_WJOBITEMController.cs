﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WV_WJOBITEMController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WV_WJOBITEM> GetWV_WJOBITEM()
        {
            return db.WV_WJOBITEM;
        }

        [Queryable]
        public IQueryable<WV_WJOBITEM> GetWV_WJOBITEM([FromODataUri]string DISABLE_FG, [FromODataUri] string Is_Used)
        {
            return db.WV_WJOBITEM.Where(o => (o.DISABLE_FG == DISABLE_FG) && (o.Is_Used == Is_Used || Is_Used == "ALL"));
        }

    }
}
