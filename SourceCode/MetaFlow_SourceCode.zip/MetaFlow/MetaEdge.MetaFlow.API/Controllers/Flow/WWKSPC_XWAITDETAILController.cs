﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Data.Entity;
using System.Collections.Generic;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XWAITDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XWAITDETAIL> Get()
        {
            return db.WWKSPC_XWAITDETAIL;
        }

        [Queryable]
        public IQueryable<WWKSPC_XWAITDETAIL> Get([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            return db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
        }

        // POST odata/WWKSPC_XWAITDETAIL
        public async Task<IHttpActionResult> Post(WWKSPC_XWAITDETAIL WWKSPC_XWAITDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WWKSPC_XWAITDETAIL.Add(WWKSPC_XWAITDETAIL);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (WWKSPC_XWAITDETAILExists(WWKSPC_XWAITDETAIL.DATACAT, WWKSPC_XWAITDETAIL.WAIT_SEQ, WWKSPC_XWAITDETAIL.LST_MAINT_USR))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XWAITDETAIL);
        }

        // PUT odata/WWKSPC_XWAITDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]int WAIT_SEQ, [FromODataUri] string LST_MAINT_USR, WWKSPC_XWAITDETAIL WWKSPC_XWAITDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.WAIT_SEQ == WAIT_SEQ && o.LST_MAINT_USR == LST_MAINT_USR);

            if (result.Count() == 0)
            {
                return NotFound();
            }
            else
            {
                db.WWKSPC_XWAITDETAIL.RemoveRange(result);
                db.WWKSPC_XWAITDETAIL.Add(WWKSPC_XWAITDETAIL);

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WWKSPC_XWAITDETAILExists(DATACAT, WAIT_SEQ, LST_MAINT_USR))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return Updated(WWKSPC_XWAITDETAIL);
            }
        }

        private bool WWKSPC_XWAITDETAILExists(string DATACAT, int WAIT_SEQ, string LST_MAINT_USR)
        {
            return db.WWKSPC_XWAITDETAIL.Count(o => o.DATACAT == DATACAT && o.WAIT_SEQ == WAIT_SEQ && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
