﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Data.Entity;
using System.Collections.Generic;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XREMOTEDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XREMOTEDETAIL> Get()
        {
            return db.WWKSPC_XREMOTEDETAIL;
        }

        [Queryable]
        public IQueryable<WWKSPC_XREMOTEDETAIL> Get([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            return db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
        }

        // POST odata/WWKSPC_XREMOTEDETAIL
        public async Task<IHttpActionResult> Post(WWKSPC_XREMOTEDETAIL WWKSPC_XREMOTEDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WWKSPC_XREMOTEDETAIL.Add(WWKSPC_XREMOTEDETAIL);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (WWKSPC_XREMOTEDETAILExists(WWKSPC_XREMOTEDETAIL.DATACAT, WWKSPC_XREMOTEDETAIL.RSEQ, WWKSPC_XREMOTEDETAIL.LST_MAINT_USR))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XREMOTEDETAIL);
        }

        // PUT odata/WWKSPC_XREMOTEDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]string RSEQ, [FromODataUri] string LST_MAINT_USR, WWKSPC_XREMOTEDETAIL WWKSPC_XREMOTEDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT && o.RSEQ == RSEQ && o.LST_MAINT_USR == LST_MAINT_USR);

            if (result.Count() == 0)
            {
                return NotFound();
            }
            else
            {
                db.WWKSPC_XREMOTEDETAIL.RemoveRange(result);
                db.WWKSPC_XREMOTEDETAIL.Add(WWKSPC_XREMOTEDETAIL);

                // 同步更新 WWKSPC_XWAITDETAIL 有設定相關 RSEQ 的資料
                var waitDetail = db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.RSEQ == RSEQ && o.LST_MAINT_USR == LST_MAINT_USR);
                foreach (WWKSPC_XWAITDETAIL wait in waitDetail)
                {
                    wait.RSEQ = WWKSPC_XREMOTEDETAIL.RSEQ;
                    wait.LST_MAINT_USR = WWKSPC_XREMOTEDETAIL.LST_MAINT_USR;
                    wait.LST_MAINT_DT = DateTime.Now;
                    db.Entry(wait).State = EntityState.Modified;
                }

                // 同步更新 WWKSPC_XFILEDETAIL 有設定相關 RSEQ 的資料
                var fileDetail = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.RSEQ == RSEQ && o.LST_MAINT_USR == LST_MAINT_USR);
                foreach (WWKSPC_XFILEDETAIL file in fileDetail)
                {
                    file.RSEQ = WWKSPC_XREMOTEDETAIL.RSEQ;
                    file.LST_MAINT_USR = WWKSPC_XREMOTEDETAIL.LST_MAINT_USR;
                    file.LST_MAINT_DT = DateTime.Now;
                    db.Entry(file).State = EntityState.Modified;
                }

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!WWKSPC_XREMOTEDETAILExists(DATACAT, RSEQ, LST_MAINT_USR))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }

                return Updated(WWKSPC_XREMOTEDETAIL);
            }
        }

        private bool WWKSPC_XREMOTEDETAILExists(string DATACAT, string RSEQ, string LST_MAINT_USR)
        {
            return db.WWKSPC_XREMOTEDETAIL.Count(o => o.DATACAT == DATACAT && o.RSEQ == RSEQ && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
