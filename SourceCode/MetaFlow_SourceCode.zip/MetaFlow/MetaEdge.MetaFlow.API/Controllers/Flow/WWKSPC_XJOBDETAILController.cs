﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XJOBDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XJOBDETAIL> Get()
        {
            return db.WWKSPC_XJOBDETAIL;
        }

        [Queryable]
        public IQueryable<WWKSPC_XJOBDETAIL> Get([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            return db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
        }

        // POST odata/WWKSPC_XJOBDETAIL
        public async Task<IHttpActionResult> Post(WWKSPC_XJOBDETAIL WWKSPC_XJOBDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                db.WWKSPC_XJOBDETAIL.Add(WWKSPC_XJOBDETAIL);

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {
                    if (WWKSPC_XJOBDETAILExists(WWKSPC_XJOBDETAIL.DATACAT, WWKSPC_XJOBDETAIL.JOB_STAGE, WWKSPC_XJOBDETAIL.JOB_FLOW, WWKSPC_XJOBDETAIL.JOB_SEQ, WWKSPC_XJOBDETAIL.LST_MAINT_USR))
                    {
                        return Conflict();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XJOBDETAIL);
        }

        // POST odata/WWKSPC_XJOBDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]string JOB_STAGE, [FromODataUri] int JOB_FLOW, [FromODataUri] int JOB_SEQ, [FromODataUri] string LST_MAINT_USR, WWKSPC_XJOBDETAIL WWKSPC_XJOBDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.JOB_STAGE == JOB_STAGE && o.JOB_FLOW == JOB_FLOW && o.JOB_SEQ == JOB_SEQ && o.LST_MAINT_USR == LST_MAINT_USR);

            if (result.Count() == 0)
            {
                return NotFound();
            }
            else
            {
                string flowNameOld = result.First().JOB_NAME.Replace("RunJobFlow", "");

                // 如果編輯的是「工作流程」，因有變更流程的名稱，必須一併連動下面的項目
                if (WWKSPC_XJOBDETAIL.DATACAT == WWKSPC_XJOBDETAIL.JOB_STAGE)
                {
                    result.First().JOB_NAME = WWKSPC_XJOBDETAIL.JOB_NAME;
                    result.First().PROCESS_TYPE = WWKSPC_XJOBDETAIL.PROCESS_TYPE;
                    result.First().JOB_DESC = WWKSPC_XJOBDETAIL.JOB_DESC;
                    result.First().SKIP_FLAG = WWKSPC_XJOBDETAIL.SKIP_FLAG;
                    result.First().FORK_FLAG = WWKSPC_XJOBDETAIL.FORK_FLAG;
                    result.First().ABORTCONTINUE_FLAG = WWKSPC_XJOBDETAIL.ABORTCONTINUE_FLAG;
                    result.First().LST_MAINT_USR = WWKSPC_XJOBDETAIL.LST_MAINT_USR;
                    result.First().LST_MAINT_DT = DateTime.Now;

                    string flowName = WWKSPC_XJOBDETAIL.JOB_NAME.Replace("RunJobFlow", "");

                    var groupList = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.JOB_STAGE == flowNameOld && o.JOB_SEQ == 0 && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
                    db.WWKSPC_XJOBDETAIL.RemoveRange(groupList);

                    foreach (WWKSPC_XJOBDETAIL group in groupList)
                    {
                        WWKSPC_XJOBDETAIL groupNew = new WWKSPC_XJOBDETAIL();

                        groupNew.DATACAT = group.DATACAT;
                        groupNew.PROCESS_TYPE = group.PROCESS_TYPE;
                        groupNew.JOB_STAGE = flowName;
                        groupNew.JOB_FLOW = group.JOB_FLOW;
                        groupNew.JOB_SEQ = group.JOB_SEQ;
                        groupNew.JOB_NAME = group.JOB_NAME.Replace(flowNameOld, flowName);
                        groupNew.PARAM = group.PARAM;
                        groupNew.SKIP_FLAG = group.SKIP_FLAG;
                        groupNew.FORK_FLAG = group.FORK_FLAG;
                        groupNew.ABORTCONTINUE_FLAG = group.ABORTCONTINUE_FLAG;
                        groupNew.SRC_TB = group.SRC_TB;
                        groupNew.TGT_TB = group.TGT_TB;
                        groupNew.JOB_TYPE = group.JOB_TYPE;
                        groupNew.JOB_DESC = group.JOB_DESC;
                        groupNew.JOB_LOCATION = group.JOB_LOCATION;
                        groupNew.JOB_OWNER = group.JOB_OWNER;
                        groupNew.LST_MAINT_USR = WWKSPC_XJOBDETAIL.LST_MAINT_USR;
                        groupNew.LST_MAINT_DT = DateTime.Now;

                        db.WWKSPC_XJOBDETAIL.Add(groupNew);
                    }

                    var jobList = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.JOB_STAGE == flowNameOld && o.JOB_SEQ > 0 && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
                    db.WWKSPC_XJOBDETAIL.RemoveRange(jobList);

                    foreach (WWKSPC_XJOBDETAIL job in jobList)
                    {
                        WWKSPC_XJOBDETAIL jobNew = new WWKSPC_XJOBDETAIL();

                        jobNew.DATACAT = job.DATACAT;
                        jobNew.PROCESS_TYPE = job.PROCESS_TYPE;
                        jobNew.JOB_STAGE = flowName;
                        jobNew.JOB_FLOW = job.JOB_FLOW;
                        jobNew.JOB_SEQ = job.JOB_SEQ;
                        jobNew.JOB_NAME = job.JOB_NAME;
                        jobNew.PARAM = job.PARAM;
                        jobNew.SKIP_FLAG = job.SKIP_FLAG;
                        jobNew.FORK_FLAG = job.FORK_FLAG;
                        jobNew.ABORTCONTINUE_FLAG = job.ABORTCONTINUE_FLAG;
                        jobNew.SRC_TB = job.SRC_TB;
                        jobNew.TGT_TB = job.TGT_TB;
                        jobNew.JOB_TYPE = job.JOB_TYPE;
                        jobNew.JOB_DESC = job.JOB_DESC;
                        jobNew.JOB_LOCATION = job.JOB_LOCATION;
                        jobNew.JOB_OWNER = job.JOB_OWNER;
                        jobNew.LST_MAINT_USR = WWKSPC_XJOBDETAIL.LST_MAINT_USR;
                        jobNew.LST_MAINT_DT = DateTime.Now;

                        db.WWKSPC_XJOBDETAIL.Add(jobNew);
                    }
                }
                else
                {
                    WWKSPC_XJOBDETAIL job = result.First();
                    job.DATACAT = WWKSPC_XJOBDETAIL.DATACAT;
                    job.PROCESS_TYPE = WWKSPC_XJOBDETAIL.PROCESS_TYPE;
                    job.JOB_STAGE = WWKSPC_XJOBDETAIL.JOB_STAGE;
                    job.JOB_FLOW = WWKSPC_XJOBDETAIL.JOB_FLOW;
                    job.JOB_SEQ = WWKSPC_XJOBDETAIL.JOB_SEQ;
                    job.JOB_NAME = WWKSPC_XJOBDETAIL.JOB_NAME;
                    job.PARAM = WWKSPC_XJOBDETAIL.PARAM;
                    job.SKIP_FLAG = WWKSPC_XJOBDETAIL.SKIP_FLAG;
                    job.FORK_FLAG = WWKSPC_XJOBDETAIL.FORK_FLAG;
                    job.ABORTCONTINUE_FLAG = WWKSPC_XJOBDETAIL.ABORTCONTINUE_FLAG;
                    job.SRC_TB = WWKSPC_XJOBDETAIL.SRC_TB;
                    job.TGT_TB = WWKSPC_XJOBDETAIL.TGT_TB;
                    job.JOB_TYPE = WWKSPC_XJOBDETAIL.JOB_TYPE;
                    job.JOB_DESC = WWKSPC_XJOBDETAIL.JOB_DESC;
                    job.JOB_LOCATION = WWKSPC_XJOBDETAIL.JOB_LOCATION;
                    job.JOB_OWNER = WWKSPC_XJOBDETAIL.JOB_OWNER;
                    job.LST_MAINT_USR = WWKSPC_XJOBDETAIL.LST_MAINT_USR;
                    job.LST_MAINT_DT = DateTime.Now;
                }

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (DbUpdateException)
                {
                    if (WWKSPC_XJOBDETAILExists(WWKSPC_XJOBDETAIL.DATACAT, WWKSPC_XJOBDETAIL.JOB_STAGE, WWKSPC_XJOBDETAIL.JOB_FLOW, WWKSPC_XJOBDETAIL.JOB_SEQ, WWKSPC_XJOBDETAIL.LST_MAINT_USR))
                    {
                        return Conflict();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return Updated(WWKSPC_XJOBDETAIL);
        }

        private bool WWKSPC_XJOBDETAILExists(string DATACAT, string JOB_STAGE, int JOB_FLOW, int JOB_SEQ, string LST_MAINT_USR)
        {
            return db.WWKSPC_XJOBDETAIL.Count(o => o.JOB_STAGE == JOB_STAGE && o.JOB_FLOW == JOB_FLOW && o.JOB_SEQ == JOB_SEQ && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}
