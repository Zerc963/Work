﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Dashboard_Qry_WaitStatusChartController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<Flow_Dashboard_Qry_StatisticsChart> Get([FromODataUri]string LightGroup)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    var result = (from s1 in db.WV_XWAITSTATUS
                                  where s1.WAIT_SKIP_FLAG != "Y"
                                  group s1 by s1.DATACAT into s2

                                  select new
                                  {
                                      DATACAT = s2.Key
                                      ,
                                      WAIT_START_TIME = s2.Min(o => o.WAIT_START_TIME)
                                      ,
                                      WAIT_END_TIME = s2.Max(o => o.WAIT_END_TIME)
                                      ,
                                      WAIT_SECOND = s2.Sum(o => o.WAIT_SECOND)
                                  })
                                  .OrderByDescending(o => o.WAIT_SECOND)
                                  .ToList();

                    //取得所有Flow的所屬顏色類別
                    SqlParameter[] SqlParam = new SqlParameter[1];
                    SqlParam[0] = new SqlParameter("@DATACAT", DBNull.Value);
                    var flowProgress = db.Database.SqlQuery<WSP_QRY_FlowProgress>("WSP_QRY_FlowProgress @DATACAT", SqlParam).ToList();

                    List<Flow_Dashboard_Qry_StatisticsChart> list = new List<Flow_Dashboard_Qry_StatisticsChart>();

                    foreach (var fs in result)
                    {
                        if (list.Count() >= 10) break; //只取得最大值的前10筆

                        Flow_Dashboard_Qry_StatisticsChart chart = new Flow_Dashboard_Qry_StatisticsChart();

                        var LightGroupData = flowProgress.Where(o => o.DATACAT == fs.DATACAT).ToList();
                        if (LightGroupData.Count() > 0)
                        {
                            chart.Color = LightGroupData[0].LIGHTGROUP;
                        }

                        if (string.IsNullOrEmpty(LightGroup) || chart.Color == LightGroup)
                        {
                            chart.Name = fs.DATACAT;
                            chart.Value = fs.WAIT_SECOND.ToString();
                            chart.ToolTip = string.Format("流程名稱 : {0}<br />等待處理時間 : {1}", fs.DATACAT, parseWaitSecond(fs.WAIT_SECOND));

                            list.Add(chart);
                        }
                    }

                    //取得最大值，用於決定Y軸的刻度顯示單位
                    double maxValue = 0;
                    if (list.Count() > 0)
                    {
                        maxValue = double.Parse(list[0].Value);
                    }

                    //將所有值轉換成合適的刻度顯示單位
                    foreach (var item in list)
                    {
                        if (maxValue > (60 * 60 * 24))
                        {
                            item.Value = (double.Parse(item.Value.ToString()) / (60 * 60 * 24)).ToString();
                        }
                        //刻度顯示單位：時
                        else if (maxValue > (60 * 60))
                        {
                            item.Value = (double.Parse(item.Value.ToString()) / (60 * 60)).ToString();
                        }
                        //刻度顯示單位：分
                        else if (maxValue > 60)
                        {
                            item.Value = (double.Parse(item.Value.ToString()) / 60).ToString();
                        }
                        //刻度顯示單位：秒
                        else
                        {
                            item.Value = item.Value.ToString();
                        }
                    }

                    return list.AsQueryable();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
        }

        private string parseWaitSecond(int? waitSecond)
        {
            try
            {
                if (waitSecond == null || waitSecond == 0)
                    return "0秒";

                int val = int.Parse(waitSecond.ToString());
                StringBuilder sbResult = new StringBuilder();

                int day = val / (60 * 60 * 24);
                if (day > 0)
                {
                    sbResult.Append(day + "天");
                    val -= day * (60 * 60 * 24);
                }

                int hour = val / (60 * 60);
                if (hour > 0)
                {
                    sbResult.Append(hour + "時");
                    val -= hour * (60 * 60);
                }

                int minute = val / (60);
                if (minute > 0)
                {
                    sbResult.Append(minute + "分");
                    val -= minute * 60;
                }

                if (val > 0)
                {
                    sbResult.Append(val + "秒");
                }

                return sbResult.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
