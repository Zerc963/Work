﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WSP_INS_XFlowagentController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        public async Task<IHttpActionResult> POST(WSP_INS_XFlowagent list)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    foreach (WSP_INS_XFlowagentDetail detail in list.Detail )
                    {
                        SqlParameter[] SqlParam = new SqlParameter[4];
                        SqlParam[0] = new SqlParameter("@DATACAT", detail.DATACAT);

                        if (string.IsNullOrEmpty(detail.CYCLEDATE))
                        {
                            SqlParam[1] = new SqlParameter("@CYCLEDATE", DBNull.Value);
                        }
                        else
                        {
                            SqlParam[1] = new SqlParameter("@CYCLEDATE", detail.CYCLEDATE);
                        }

                        SqlParam[2] = new SqlParameter("@START_MODE", detail.START_MODE);
                        SqlParam[3] = new SqlParameter("@CREATE_USER", detail.CREATE_USER);
                        db.Database.ExecuteSqlCommand("WSP_INS_XFlowagent @DATACAT,@CYCLEDATE,@START_MODE,@CREATE_USER", SqlParam);
                    }

                    dbTransaction.Commit();

                    return StatusCode(HttpStatusCode.NoContent);
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
        }
    }
}
