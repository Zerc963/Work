﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WSP_QRY_FlowStatusHController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WSP_QRY_FlowStatus> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    SqlParameter[] SqlParam = new SqlParameter[2];
                    SqlParam[0] = new SqlParameter("@DATACAT", DATACAT);
                    SqlParam[1] = new SqlParameter("@BATCH_NO", BATCH_NO);

                    return db.Database.SqlQuery<WSP_QRY_FlowStatus>("WSP_QRY_FlowStatusH @DATACAT,@BATCH_NO", SqlParam).AsQueryable();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
        }



    }
}
