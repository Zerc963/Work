﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Dashboard_Qry_WaitStatusController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WV_XWAITSTATUS> Get()
        {
            return db.WV_XWAITSTATUS.Where(o => o.WAIT_STATUS != "WAITOK" && o.WAIT_SKIP_FLAG != "Y");
        }        
        

        
    }
}
