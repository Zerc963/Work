﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Dashboard_Qry_RunningBatchFlowController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WV_XBATCHFLOW> Get()
        {
            return db.WV_XBATCHFLOW.Where(o => o.RUN_STATUS == "Running" && o.SKIP_FLAG != "Y" && o.DATACAT != o.JOB_STAGE && o.JOB_SEQ != 0);
        }        
        

        
    }
}
