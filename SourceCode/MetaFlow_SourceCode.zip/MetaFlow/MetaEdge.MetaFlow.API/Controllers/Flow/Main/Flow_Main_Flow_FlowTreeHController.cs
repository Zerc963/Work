﻿using MetaEdge.ISMD.Entity.Models;
using MetaEdge.MetaAuthWeb.Data.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Main_Flow_FlowTreeHController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<ETLFlowTree> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO)
        {
            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            //Get ETL FLOW ALL Information
            ETLFlowTree objResult = new ETLFlowTree();
            List<ETLFlowTree> ListResult = new List<ETLFlowTree>();
            objResult.name = "等待流程";
            objResult.runstatus = "RUNOK";
            objResult.children = new List<FileHandleTree>();

            FileHandleTree objFileHandle = new FileHandleTree();
            List<FileHandleTree> ListFileHandle = new List<FileHandleTree>();
            objFileHandle.name = "檔案處理";
            objFileHandle.runstatus = "RUNOK";
            objFileHandle.children = new List<FlowTree>();

            long batchNo = long.Parse(BATCH_NO);

            IQueryable<WV_XBATCHFLOWH> SrcFlow = db.WV_XBATCHFLOWH.Where(o => o.DATACAT == DATACAT && o.BATCH_NO == batchNo)
                                                                  .OrderBy(o => o.RUN_SEQ);

            //Get ETL FLOW Level Information
            FlowTree objFlowLevel = new FlowTree();
            List<FlowTree> ListFlowLevel = new List<FlowTree>();
            IQueryable<WV_XBATCHFLOWH> FlowLevel = SrcFlow.Where(o => o.JOB_LEVEL == "1")
                                                          .OrderBy(o => o.RUN_SEQ);
            //Get ETL FLOW Stage Level Information
            StageTree objStageLevel = new StageTree();
            IQueryable<WV_XBATCHFLOWH> StageLevel = SrcFlow.Where(o => o.JOB_LEVEL == "2")
                                                           .OrderBy(o => o.RUN_SEQ);
            //Get ETL FLOW Job Level Information
            JobTree objJobLevel = new JobTree();
            IQueryable<WV_XBATCHFLOWH> JobLevel = SrcFlow.Where(o => o.JOB_LEVEL == "3")
                                                         .OrderBy(o => o.RUN_SEQ);

            foreach (WV_XBATCHFLOWH ListFlow in FlowLevel)
            {
                objFlowLevel = new FlowTree();
                objFlowLevel.name = ListFlow.JOB_STAGE_REF.Trim();
                objFlowLevel.DATACAT = ListFlow.DATACAT.Trim();
                objFlowLevel.JOB_STAGE = ListFlow.JOB_STAGE.Trim();
                objFlowLevel.JOB_FLOW = ListFlow.JOB_FLOW;
                objFlowLevel.JOB_SEQ = ListFlow.JOB_SEQ;
                objFlowLevel.runstatus = ListFlow.RUN_STATUS.Trim();
                objFlowLevel.FORK_FLAG = ListFlow.FORK_FLAG;
                objFlowLevel.ABORTCONTINUE_FLAG = ListFlow.ABORTCONTINUE_FLAG;
                objFlowLevel.children = new List<StageTree>();
                ListFlowLevel.Add(objFlowLevel);
            }

            foreach (WV_XBATCHFLOWH ListFlow in StageLevel)
            {
                objStageLevel = new StageTree();
                objStageLevel.name = "工作群組 " + ListFlow.JOB_FLOW.ToString();
                objStageLevel.DATACAT = ListFlow.DATACAT.Trim();
                objStageLevel.JOB_STAGE = ListFlow.JOB_STAGE.Trim();
                objStageLevel.JOB_FLOW = ListFlow.JOB_FLOW;
                objStageLevel.JOB_SEQ = ListFlow.JOB_SEQ;
                objStageLevel.runstatus = ListFlow.RUN_STATUS.Trim();
                objStageLevel.FORK_FLAG = ListFlow.FORK_FLAG;
                objStageLevel.ABORTCONTINUE_FLAG = ListFlow.ABORTCONTINUE_FLAG;
                objStageLevel.children = new List<JobTree>();

                for (int i = 0; i < ListFlowLevel.Count; i++)
                {
                    if (ListFlowLevel[i].name.Trim() == ListFlow.JOB_STAGE)
                    {
                        ListFlowLevel[i].children.Add(objStageLevel);
                    }
                }
            }

            foreach (WV_XBATCHFLOWH ListFlow in JobLevel)
            {
                objJobLevel = new JobTree();
                objJobLevel.name = ListFlow.JOB_NAME.Trim();
                objJobLevel.DATACAT = ListFlow.DATACAT.Trim();
                objJobLevel.JOB_STAGE = ListFlow.JOB_STAGE.Trim();
                objJobLevel.JOB_FLOW = ListFlow.JOB_FLOW;
                objJobLevel.JOB_SEQ = ListFlow.JOB_SEQ;
                objJobLevel.runstatus = ListFlow.RUN_STATUS.Trim();
                objJobLevel.SKIP_FLAG = ListFlow.SKIP_FLAG.Trim();
                objJobLevel.FORK_FLAG = ListFlow.FORK_FLAG.Trim();
                objJobLevel.ABORTCONTINUE_FLAG = ListFlow.ABORTCONTINUE_FLAG.Trim();

                if (!string.IsNullOrEmpty(ListFlow.JOB_TYPE))
                {
                    var JOB_TYPENM = parameters.Where(o => o.TypeName == "JOB_TYPE" && o.ParameterValue == ListFlow.JOB_TYPE.Trim()).ToList();
                    if (JOB_TYPENM.Count() > 0)
                    {
                        objJobLevel.JOB_TYPENM = JOB_TYPENM.First().ParameterName;
                    }
                }

                if (!string.IsNullOrEmpty(ListFlow.JOB_DESC))
                {
                    objJobLevel.JOB_DESC = ListFlow.JOB_DESC.Trim();
                }

                for (int i = 0; i < ListFlowLevel.Count; i++)
                {
                    for (int j = 0; j < ListFlowLevel[i].children.Count; j++)
                    {
                        if (ListFlowLevel[i].children[j].JOB_STAGE == ListFlow.JOB_STAGE
                         && ListFlowLevel[i].children[j].JOB_FLOW == ListFlow.JOB_FLOW)
                        {
                            ListFlowLevel[i].children[j].children.Add(objJobLevel);
                        }
                    }
                }
            }

            
            for (int i = 0; i < ListFlowLevel.Count; i++)
            {
                ListFlowLevel[i].name = "工作流程 " + ListFlowLevel[i].name;
                objFileHandle.children.Add(ListFlowLevel[i]);
            }
            ListFileHandle.Add(objFileHandle);
            objResult.children.Add(ListFileHandle[0]);
            ListResult.Add(objResult);
            return ListResult.AsQueryable();
        }

    }
}
