﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_TestController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<Flow_Test> Get([FromODataUri]string DATACAT)
        {
            List<Flow_Test> flowList = new List<Flow_Test>();
            var flow = new Flow_Test();


            var flowDetail = db.XFLOWDETAIL.Where(o => o.DATACAT == DATACAT).First();

            flow.FlowDetail.DATACAT = flowDetail.DATACAT;
            flow.FlowDetail.FLOW_TYPE = flowDetail.FLOW_TYPE;
            flow.FlowDetail.DATACATNM = flowDetail.DATACATNM;
            flow.FlowDetail.DT_TYPE = flowDetail.DT_TYPE;
            flow.FlowDetail.DT_CHG_HR = flowDetail.DT_CHG_HR;
            flow.FlowDetail.CYC_RERUN_FG = flowDetail.CYC_RERUN_FG;
            flow.FlowDetail.CURR_CYC_FG = flowDetail.CURR_CYC_FG;
            flow.FlowDetail.RETRY_TIMES = flowDetail.RETRY_TIMES;
            flow.FlowDetail.ABORT_RESTART_INTERVAL = flowDetail.ABORT_RESTART_INTERVAL;
            flow.FlowDetail.ABORT_NOTIFY_SKIP_TIMES = flowDetail.ABORT_NOTIFY_SKIP_TIMES;
            flow.FlowDetail.AGENT_MODE = flowDetail.AGENT_MODE;
            flow.FlowDetail.LOCAL_MODE = flowDetail.LOCAL_MODE;
            flow.FlowDetail.LST_MAINT_USR = flowDetail.LST_MAINT_USR;
            flow.FlowDetail.LST_MAINT_DT = flowDetail.LST_MAINT_DT;


            var scheduleList = db.XSCHEDULE.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XSCHEDULE schedule in scheduleList)
            {
                Flow_Test_XSCHEDULE item = new Flow_Test_XSCHEDULE();

                item.DATACAT = schedule.DATACAT;
                item.PROCESS_TYPE = schedule.PROCESS_TYPE;
                item.START_TIME = schedule.START_TIME;
                item.END_TIME = schedule.END_TIME;
                item.INTERVAL = schedule.INTERVAL;
                item.EFFECTIVE_TIME = schedule.EFFECTIVE_TIME;
                item.EXPIRATION_TIME = schedule.EXPIRATION_TIME;
                item.LST_MAINT_USR = schedule.LST_MAINT_USR;
                item.LST_MAINT_DT = schedule.LST_MAINT_DT;

                flow.Schedule.Add(item);
            }


            var localDetailList = db.XLOCALDETAIL.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XLOCALDETAIL local in localDetailList)
            {
                Flow_Test_XLOCALDETAIL item = new Flow_Test_XLOCALDETAIL();

                item.DATACAT = local.DATACAT;
                item.LSEQ = local.LSEQ;
                item.LOCAL_PATH = local.LOCAL_PATH;
                item.WORK_PATH = local.WORK_PATH;
                item.BACKUP_PATH = local.BACKUP_PATH;
                item.LST_MAINT_USR = local.LST_MAINT_USR;
                item.LST_MAINT_DT = local.LST_MAINT_DT;

                flow.LocalDetail.Add(item);
            }


            var remoteDetailList = db.XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XREMOTEDETAIL remote in remoteDetailList)
            {
                Flow_Test_XREMOTEDETAIL item = new Flow_Test_XREMOTEDETAIL();

                item.DATACAT = remote.DATACAT;
                item.RSEQ = remote.RSEQ;
                item.SERVERTYPE = remote.SERVERTYPE;
                item.SERVERNM = remote.SERVERNM;
                item.USERCODE = remote.USERCODE;
                item.REMOTE_PATH = remote.REMOTE_PATH;
                item.LST_MAINT_USR = remote.LST_MAINT_USR;
                item.LST_MAINT_DT = remote.LST_MAINT_DT;

                flow.RemoteDetail.Add(item);
            }


            var waitDetailList = db.XWAITDETAIL.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XWAITDETAIL wait in waitDetailList)
            {
                Flow_Test_XWAITDETAIL item = new Flow_Test_XWAITDETAIL();

                item.DATACAT = wait.DATACAT;
                item.PROCESS_TYPE = wait.PROCESS_TYPE;
                item.WAIT_SEQ = wait.WAIT_SEQ;
                item.WAIT_TYPE = wait.WAIT_TYPE;
                item.RSEQ = wait.RSEQ;
                item.LSEQ = wait.LSEQ;
                item.WAIT_NAME = wait.WAIT_NAME;
                item.CHK_FG = wait.CHK_FG;
                item.CHK_FILEDATE_FG = wait.CHK_FILEDATE_FG;
                item.TOLERANCE = wait.TOLERANCE;
                item.WAIT_SKIP_FLAG = wait.WAIT_SKIP_FLAG;
                item.NOT_EXIST_SKIP_FG = wait.NOT_EXIST_SKIP_FG;
                item.LST_MAINT_USR = wait.LST_MAINT_USR;
                item.LST_MAINT_DT = wait.LST_MAINT_DT;

                flow.WaitDetail.Add(item);
            }


            var fileDetailList = db.XFILEDETAIL.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XFILEDETAIL file in fileDetailList)
            {
                Flow_Test_XFILEDETAIL item = new Flow_Test_XFILEDETAIL();

                item.DATACAT = file.DATACAT;
                item.PROCESS_TYPE = file.PROCESS_TYPE;
                item.FILE_SEQ = file.FILE_SEQ;
                item.RSEQ = file.RSEQ;
                item.LSEQ = file.LSEQ;
                item.FILENAME = file.FILENAME;
                item.SRCNAME = file.SRCNAME;
                item.SRCCNAME = file.SRCCNAME;
                item.PARENT_FILENAME = file.PARENT_FILENAME;
                item.SKIP_FLAG = file.SKIP_FLAG;
                item.NOT_EXIST_SKIP_FG = file.NOT_EXIST_SKIP_FG;
                item.ABORTCONTINUE_FLAG = file.ABORTCONTINUE_FLAG;
                item.CRT_FG = file.CRT_FG;
                item.CHK_FG = file.CHK_FG;
                item.UNZIP_FG = file.UNZIP_FG;
                item.ZIP_PW = file.ZIP_PW;
                item.FILE_AMT_NM = file.FILE_AMT_NM;
                item.TOLERANCE = file.TOLERANCE;
                item.LST_MAINT_USR = file.LST_MAINT_USR;
                item.LST_MAINT_DT = file.LST_MAINT_DT;

                flow.FileDetail.Add(item);
            }


            var flatFileDetailList = db.XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XFLATFILEDETAIL flatFile in flatFileDetailList)
            {
                Flow_Test_XFLATFILEDETAIL item = new Flow_Test_XFLATFILEDETAIL();

                item.DATACAT = flatFile.DATACAT;
                item.FILE_SEQ = flatFile.FILE_SEQ;
                item.FILE_GROUP = flatFile.FILE_GROUP;
                item.CODEPAGE = flatFile.CODEPAGE;
                item.RAGGED_FIX = flatFile.RAGGED_FIX;
                item.RECORDLEN = flatFile.RECORDLEN;
                item.RAGGEDLEN = flatFile.RAGGEDLEN;
                item.DELIMITER = flatFile.DELIMITER;
                item.TERMINATOR = flatFile.TERMINATOR;
                item.FIRSTROW = flatFile.FIRSTROW;
                item.LST_MAINT_USR = flatFile.LST_MAINT_USR;
                item.LST_MAINT_DT = flatFile.LST_MAINT_DT;

                flow.FlatFileDetail.Add(item);
            }


            var jobDetailList = db.XJOBDETAIL.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XJOBDETAIL job in jobDetailList)
            {
                Flow_Test_XJOBDETAIL item = new Flow_Test_XJOBDETAIL();

                item.DATACAT = job.DATACAT;
                item.PROCESS_TYPE = job.PROCESS_TYPE;
                item.JOB_STAGE = job.JOB_STAGE;
                item.JOB_FLOW = job.JOB_FLOW;
                item.JOB_SEQ = job.JOB_SEQ;
                item.JOB_NAME = job.JOB_NAME;
                item.PARAM = job.PARAM;
                item.SKIP_FLAG = job.SKIP_FLAG;
                item.FORK_FLAG = job.FORK_FLAG;
                item.ABORTCONTINUE_FLAG = job.ABORTCONTINUE_FLAG;
                item.SRC_TB = job.SRC_TB;
                item.TGT_TB = job.TGT_TB;
                item.JOB_TYPE = job.JOB_TYPE;
                item.JOB_DESC = job.JOB_DESC;
                item.JOB_LOCATION = job.JOB_LOCATION;
                item.JOB_OWNER = job.JOB_OWNER;
                item.LST_MAINT_USR = job.LST_MAINT_USR;
                item.LST_MAINT_DT = job.LST_MAINT_DT;

                flow.JobDetail.Add(item);
            }


            var mailDetailList = db.XMAILDETAIL.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XMAILDETAIL mail in mailDetailList)
            {
                Flow_Test_XMAILDETAIL item = new Flow_Test_XMAILDETAIL();

                item.DATACAT = mail.DATACAT;
                item.MAIL_TYPE = mail.MAIL_TYPE;
                item.MAILADR = mail.MAILADR;
                item.MAIL_DESC = mail.MAIL_DESC;
                item.LST_MAINT_USR = mail.LST_MAINT_USR;
                item.LST_MAINT_DT = mail.LST_MAINT_DT;

                flow.MailDetail.Add(item);
            }


            var monitorFileWaitDetailList = db.XMONITOR_FILEWAIT.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XMONITOR_FILEWAIT fileWait in monitorFileWaitDetailList)
            {
                Flow_Test_XMONITOR_FILEWAIT item = new Flow_Test_XMONITOR_FILEWAIT();

                item.DATACAT = fileWait.DATACAT;
                item.START_TIME = fileWait.START_TIME;
                item.END_TIME = fileWait.END_TIME;
                item.LST_MAINT_USR = fileWait.LST_MAINT_USR;
                item.LST_MAINT_DT = fileWait.LST_MAINT_DT;

                flow.MonitorFileWait.Add(item);
            }


            var monitorFlowTimeDetailList = db.XMONITOR_FLOWTIME.Where(o => o.DATACAT == DATACAT).ToList();

            foreach (XMONITOR_FLOWTIME flowTime in monitorFlowTimeDetailList)
            {
                Flow_Test_XMONITOR_FLOWTIME item = new Flow_Test_XMONITOR_FLOWTIME();

                item.DATACAT = flowTime.DATACAT;
                item.MAX_DURATION_TIME = flowTime.MAX_DURATION_TIME;
                item.START_TIME = flowTime.START_TIME;
                item.EXPECT_END_TIME = flowTime.EXPECT_END_TIME;
                item.CHK_TIME = flowTime.CHK_TIME;
                item.CHK_STATUS = flowTime.CHK_STATUS;
                item.BATCH_NO = flowTime.BATCH_NO;
                item.LST_MAINT_USR = flowTime.LST_MAINT_USR;
                item.LST_MAINT_DT = flowTime.LST_MAINT_DT;

                flow.MonitorFlowTime.Add(item);
            }


            flowList.Add(flow);

            return flowList.AsQueryable();

        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
