﻿using MetaEdge.ISMD.Entity.Models;
using MetaEdge.MetaAuthWeb.Data.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Main_Flow_FlowTreeController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<ETLFlowTree> Get([FromODataUri]string DATACAT)
        {
            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            //Get ETL FLOW ALL Information
            ETLFlowTree objResult = new ETLFlowTree();
            List<ETLFlowTree> ListResult = new List<ETLFlowTree>();

            var SrcWait = (from s1 in db.WV_XWAITSTATUS
                           where s1.DATACAT == DATACAT
                           orderby s1.STATUS_LEVEL
                           select new
                           {
                               name = s1.DATACAT,
                               waitseq = s1.WAIT_SEQ,
                               runstatus = (s1.STATUS_LEVEL == 1 ? "ABORT" :
                                            s1.STATUS_LEVEL == 2 ? "WAITING" : "RUNOK")
                           }).ToList();
            objResult.name = "等待流程";
            objResult.waitseq = SrcWait.Count == 0 ? 0 : SrcWait.First().waitseq;
            objResult.runstatus = SrcWait.Count == 0 ? "RUNOK" : SrcWait.First().runstatus;
            objResult.children = new List<FileHandleTree>();

            FileHandleTree objFileHandle = new FileHandleTree();
            List<FileHandleTree> ListFileHandle = new List<FileHandleTree>();

            var SrcFile = (from s1 in db.WV_XFILESTATUS
                           where s1.DATACAT == DATACAT
                           orderby s1.STATUS_LEVEL
                           select new
                           {
                               name = s1.DATACAT,
                               fileseq = s1.FILE_SEQ,
                               runstatus = (s1.STATUS_LEVEL == 1 ? "ABORT" :
                                            s1.STATUS_LEVEL == 2 ? "RUNNING" : "RUNOK"),
                           }).ToList();

            objFileHandle.name = "檔案處理";
            objFileHandle.fileseq = SrcFile.Count == 0 ? 0 : SrcFile.First().fileseq;
            objFileHandle.runstatus = SrcFile.Count == 0 ? "RUNOK" : SrcFile.First().runstatus;
            objFileHandle.children = new List<FlowTree>();

            IQueryable<WV_XBATCHFLOW> SrcFlow = db.WV_XBATCHFLOW.Where(o => o.DATACAT == DATACAT)
                                                                .OrderBy(o => o.RUN_SEQ);

            //Get ETL FLOW Level Information
            FlowTree objFlowLevel = new FlowTree();
            List<FlowTree> ListFlowLevel = new List<FlowTree>();
            IQueryable<WV_XBATCHFLOW> FlowLevel = SrcFlow.Where(o => o.JOB_LEVEL == "1")
                                                         .OrderBy(o => o.RUN_SEQ);
            //Get ETL FLOW Stage Level Information
            StageTree objStageLevel = new StageTree();
            IQueryable<WV_XBATCHFLOW> StageLevel = SrcFlow.Where(o => o.JOB_LEVEL == "2")
                                                          .OrderBy(o => o.RUN_SEQ);
            //Get ETL FLOW Job Level Information
            JobTree objJobLevel = new JobTree();
            IQueryable<WV_XBATCHFLOW> JobLevel = SrcFlow.Where(o => o.JOB_LEVEL == "3")
                                                        .OrderBy(o => o.RUN_SEQ);

            foreach (WV_XBATCHFLOW ListFlow in FlowLevel)
            {
                objFlowLevel = new FlowTree();
                objFlowLevel.name = ListFlow.JOB_STAGE_REF != null ? ListFlow.JOB_STAGE_REF.Trim() : "";
                objFlowLevel.DATACAT = ListFlow.DATACAT != null ? ListFlow.DATACAT.Trim() : "";
                objFlowLevel.JOB_STAGE = ListFlow.JOB_STAGE != null ? ListFlow.JOB_STAGE.Trim() : "";
                objFlowLevel.JOB_FLOW = ListFlow.JOB_FLOW;
                objFlowLevel.JOB_SEQ = ListFlow.JOB_SEQ;
                objFlowLevel.runstatus = ListFlow.RUN_STATUS != null ? ListFlow.RUN_STATUS.Trim() : "";
                objFlowLevel.FORK_FLAG = ListFlow.FORK_FLAG != null ? ListFlow.FORK_FLAG.Trim() : "";
                objFlowLevel.ABORTCONTINUE_FLAG = ListFlow.ABORTCONTINUE_FLAG != null ? ListFlow.ABORTCONTINUE_FLAG.Trim() : "";

                if (!string.IsNullOrEmpty(ListFlow.JOB_DESC))
                {
                    objFlowLevel.JOB_DESC = ListFlow.JOB_DESC.Trim();
                }

                objFlowLevel.children = new List<StageTree>();
                ListFlowLevel.Add(objFlowLevel);
            }

            foreach (WV_XBATCHFLOW ListFlow in StageLevel)
            {
                objStageLevel = new StageTree();
                objStageLevel.name = "工作群組 " + ListFlow.JOB_FLOW.ToString();
                objStageLevel.DATACAT = ListFlow.DATACAT != null ? ListFlow.DATACAT.Trim() : "";
                objStageLevel.JOB_STAGE = ListFlow.JOB_STAGE != null ? ListFlow.JOB_STAGE.Trim() : "";
                objStageLevel.JOB_FLOW = ListFlow.JOB_FLOW;
                objStageLevel.JOB_SEQ = ListFlow.JOB_SEQ;
                objStageLevel.runstatus = ListFlow.RUN_STATUS != null ? ListFlow.RUN_STATUS.Trim() : "";
                objStageLevel.FORK_FLAG = ListFlow.FORK_FLAG != null ? ListFlow.FORK_FLAG.Trim() : "";
                objStageLevel.ABORTCONTINUE_FLAG = ListFlow.ABORTCONTINUE_FLAG != null ? ListFlow.ABORTCONTINUE_FLAG.Trim() : "";

                if (!string.IsNullOrEmpty(ListFlow.JOB_DESC))
                {
                    objStageLevel.JOB_DESC = ListFlow.JOB_DESC.Trim();
                }

                objStageLevel.children = new List<JobTree>();

                for (int i = 0; i < ListFlowLevel.Count; i++)
                {
                    if (ListFlowLevel[i].name.Trim() == ListFlow.JOB_STAGE)
                    {
                        ListFlowLevel[i].children.Add(objStageLevel);
                    }
                }
            }

            foreach (WV_XBATCHFLOW ListFlow in JobLevel)
            {
                objJobLevel = new JobTree();
                objJobLevel.name = ListFlow.JOB_NAME != null ? ListFlow.JOB_NAME.Trim() : "";
                objJobLevel.DATACAT = ListFlow.DATACAT != null ? ListFlow.DATACAT.Trim() : "";
                objJobLevel.JOB_STAGE = ListFlow.JOB_STAGE != null ? ListFlow.JOB_STAGE.Trim() : "";
                objJobLevel.JOB_FLOW = ListFlow.JOB_FLOW;
                objJobLevel.JOB_SEQ = ListFlow.JOB_SEQ;
                objJobLevel.runstatus = ListFlow.RUN_STATUS != null ? ListFlow.RUN_STATUS.Trim() : "";
                objJobLevel.SKIP_FLAG = ListFlow.SKIP_FLAG != null ? ListFlow.SKIP_FLAG.Trim() : "";
                objJobLevel.FORK_FLAG = ListFlow.FORK_FLAG != null ? ListFlow.FORK_FLAG.Trim() : "";
                objJobLevel.ABORTCONTINUE_FLAG = ListFlow.JOB_NAME != null ? ListFlow.ABORTCONTINUE_FLAG.Trim() : "";

                if (!string.IsNullOrEmpty(ListFlow.JOB_TYPE))
                {
                    var JOB_TYPENM = parameters.Where(o => o.TypeName == "JOB_TYPE" && o.ParameterValue == ListFlow.JOB_TYPE.Trim()).ToList();
                    if (JOB_TYPENM.Count() > 0)
                    {
                        objJobLevel.JOB_TYPENM = JOB_TYPENM.First().ParameterName;
                    }
                }

                if (!string.IsNullOrEmpty(ListFlow.JOB_DESC))
                {
                    objJobLevel.JOB_DESC = ListFlow.JOB_DESC.Trim();
                }

                for (int i = 0; i < ListFlowLevel.Count; i++)
                {
                    for (int j = 0; j < ListFlowLevel[i].children.Count; j++)
                    {
                        if (ListFlowLevel[i].children[j].JOB_STAGE == ListFlow.JOB_STAGE
                         && ListFlowLevel[i].children[j].JOB_FLOW == ListFlow.JOB_FLOW)
                        {
                            ListFlowLevel[i].children[j].children.Add(objJobLevel);
                        }
                    }
                }
            }

            for (int i = 0; i < ListFlowLevel.Count; i++)
            {
                ListFlowLevel[i].name = "工作流程 " + ListFlowLevel[i].name;
                objFileHandle.children.Add(ListFlowLevel[i]);
            }
            ListFileHandle.Add(objFileHandle);
            objResult.children.Add(ListFileHandle[0]);
            ListResult.Add(objResult);
            return ListResult.AsQueryable();

        }

        [Queryable]
        public IQueryable<WV_XBATCHFLOW> Get()
        {
            return db.WV_XBATCHFLOW;
        }
    }
}
