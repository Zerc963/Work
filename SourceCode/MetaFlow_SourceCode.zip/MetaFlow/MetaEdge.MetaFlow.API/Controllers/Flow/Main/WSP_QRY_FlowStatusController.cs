﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WSP_QRY_FlowStatusController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WSP_QRY_FlowStatus> Get([FromODataUri]string DATACAT)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    SqlParameter[] SqlParam = new SqlParameter[1];

                    if (string.IsNullOrEmpty(DATACAT))
                    {
                        SqlParam[0] = new SqlParameter("@DATACAT", DBNull.Value);
                    }
                    else
                    {
                        SqlParam[0] = new SqlParameter("@DATACAT", DATACAT);
                    }

                    return db.Database.SqlQuery<WSP_QRY_FlowStatus>("WSP_QRY_FlowStatus @DATACAT", SqlParam).AsQueryable();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
        }



    }
}
