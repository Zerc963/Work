﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Dashboard_Qry_NextRunTimeChartController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<Flow_Dashboard_Qry_StatisticsChart> Get([FromODataUri]string LightGroup)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    SqlParameter[] SqlParam = new SqlParameter[1];
                    SqlParam[0] = new SqlParameter("@DATACAT", DBNull.Value);
                    var flowStatus = db.Database.SqlQuery<WSP_QRY_FlowStatus>("WSP_QRY_FlowStatus @DATACAT", SqlParam).ToList();

                    //取得所有Flow的所屬顏色類別
                    SqlParameter[] SqlParam2 = new SqlParameter[1];
                    SqlParam2[0] = new SqlParameter("@DATACAT", DBNull.Value);
                    var flowProgress = db.Database.SqlQuery<WSP_QRY_FlowProgress>("WSP_QRY_FlowProgress @DATACAT", SqlParam2).ToList();

                    var result = (from s1 in flowStatus

                                   join s2 in flowProgress
                                   on s1.DATACAT equals s2.DATACAT
                                  where !s1.NEXT_TIME.Contains("--")
                                     && !s1.NEXT_TIME.Contains("9999")

                                 select new
                                 {
                                     DATACAT = s1.DATACAT
                                     ,
                                     NEXT_TIME_TOTAL = parseNextTime(s1.NEXT_TIME)
                                     ,
                                     NEXT_TIME = s1.NEXT_TIME
                                     ,
                                     LIGHTGROUP = s2.LIGHTGROUP
                                 })
                                 .Where(o => o.LIGHTGROUP == (!string.IsNullOrEmpty(LightGroup) ? LightGroup : o.LIGHTGROUP)
                                          && o.NEXT_TIME_TOTAL > -1)
                                 .OrderBy(o => o.NEXT_TIME_TOTAL)
                                 .Take(10)
                                 .ToList();

                    //取得最大值，用於決定Y軸的刻度顯示單位
                    double maxValue = 0;
                    if (result.Count() > 0)
                    {
                        maxValue = double.Parse(result[result.Count() - 1].NEXT_TIME_TOTAL.ToString());
                    }

                    List<Flow_Dashboard_Qry_StatisticsChart> list = new List<Flow_Dashboard_Qry_StatisticsChart>();

                    foreach (var fs in result)
                    {
                        Flow_Dashboard_Qry_StatisticsChart chart = new Flow_Dashboard_Qry_StatisticsChart();
                        chart.Name = fs.DATACAT;

                        if (maxValue > (60 * 60 * 24))
                        {
                            chart.Value = (double.Parse(fs.NEXT_TIME_TOTAL.ToString()) / (60 * 60 * 24)).ToString();
                        }
                        //刻度顯示單位：時
                        else if (maxValue > (60 * 60))
                        {
                            chart.Value = (double.Parse(fs.NEXT_TIME_TOTAL.ToString()) / (60 * 60)).ToString();
                        }
                        //刻度顯示單位：分
                        else if (maxValue > 60)
                        {
                            chart.Value = (double.Parse(fs.NEXT_TIME_TOTAL.ToString()) / 60).ToString();
                        }
                        //刻度顯示單位：秒
                        else
                        {
                            chart.Value = fs.NEXT_TIME_TOTAL.ToString();
                        }

                        chart.ToolTip = string.Format("流程名稱 : {0}<br />下次執行時間 : {1}<br />距離下次執行時間剩下 : {2}", fs.DATACAT, fs.NEXT_TIME.Replace("-", "/"), parseNextTime2(fs.NEXT_TIME));
                        chart.Color = fs.LIGHTGROUP;
                        list.Add(chart);
                    }

                    return list.AsQueryable();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
        }

        private double parseNextTime(string nextTime)
        {
            try
            {
                DateTime dtNextTime = DateTime.Parse(nextTime);
                DateTime dtNow = DateTime.Now;
                TimeSpan ts = dtNextTime - dtNow;

                if (ts.TotalSeconds > 0)
                {
                    return ts.TotalSeconds;
                }
                else
                {
                    return double.Parse("-1");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string parseNextTime2(string nextTime)
        {
            try
            {
                DateTime dtNextTime = DateTime.Parse(nextTime);
                DateTime dtNow = DateTime.Now;
                TimeSpan ts = dtNextTime - dtNow;

                string result = string.Empty;

                if (ts.Days > 0)
                {
                    result += ts.Days + "天";
                }

                if (ts.Hours > 0)
                {
                    result += ts.Hours + "時";
                }

                if (ts.Minutes > 0)
                {
                    result += ts.Minutes + "分";
                }

                if (ts.Seconds > 0)
                {
                    result += ts.Seconds + "秒";
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
