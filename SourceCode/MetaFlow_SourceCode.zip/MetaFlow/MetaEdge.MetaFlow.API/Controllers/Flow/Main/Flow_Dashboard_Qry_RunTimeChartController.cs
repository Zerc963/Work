﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Dashboard_Qry_RunTimeChartController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<Flow_Dashboard_Qry_StatisticsChart> Get([FromODataUri]string LightGroup)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    SqlParameter[] SqlParam = new SqlParameter[1];
                    SqlParam[0] = new SqlParameter("@DATACAT", DBNull.Value);
                    var flowStatus = db.Database.SqlQuery<WSP_QRY_FlowStatus>("WSP_QRY_FlowStatus @DATACAT", SqlParam).ToList();

                    //取得所有Flow的所屬顏色類別
                    SqlParameter[] SqlParam2 = new SqlParameter[1];
                    SqlParam2[0] = new SqlParameter("@DATACAT", DBNull.Value);
                    var flowProgress = db.Database.SqlQuery<WSP_QRY_FlowProgress>("WSP_QRY_FlowProgress @DATACAT", SqlParam2).ToList();

                    var result = (from s1 in flowStatus

                                   join s2 in flowProgress
                                   on s1.DATACAT equals s2.DATACAT

                                   select new
                                   {
                                       DATACAT = s1.DATACAT
                                       ,
                                       RUN_TIME_TOTAL = parseRunTime(s1.RUN_TIME)
                                       ,
                                       RUN_TIME = s1.RUN_TIME
                                       ,
                                       LIGHTGROUP = s2.LIGHTGROUP
                                   })
                                 .Where(o => o.LIGHTGROUP == (!string.IsNullOrEmpty(LightGroup) ? LightGroup : o.LIGHTGROUP))
                                 .OrderByDescending(o => o.RUN_TIME_TOTAL)
                                 .Take(10)
                                 .ToList();

                    //取得最大值，用於決定Y軸的刻度顯示單位
                    double maxValue = 0;
                    if (result.Count() > 0)
                    {
                        maxValue = double.Parse(result[0].RUN_TIME_TOTAL.ToString());
                    }

                    List<Flow_Dashboard_Qry_StatisticsChart> list = new List<Flow_Dashboard_Qry_StatisticsChart>();

                    foreach (var fs in result)
                    {
                        Flow_Dashboard_Qry_StatisticsChart chart = new Flow_Dashboard_Qry_StatisticsChart();
                        chart.Name = fs.DATACAT;

                        if (maxValue > (60 * 60 * 24))
                        {
                            chart.Value = (double.Parse(fs.RUN_TIME_TOTAL.ToString()) / (60 * 60 * 24)).ToString();
                        }
                        //刻度顯示單位：時
                        else if (maxValue > (60 * 60))
                        {
                            chart.Value = (double.Parse(fs.RUN_TIME_TOTAL.ToString()) / (60 * 60)).ToString();
                        }
                        //刻度顯示單位：分
                        else if (maxValue > 60)
                        {
                            chart.Value = (double.Parse(fs.RUN_TIME_TOTAL.ToString()) / 60).ToString();
                        }
                        //刻度顯示單位：秒
                        else
                        {
                            chart.Value = fs.RUN_TIME_TOTAL.ToString();
                        }

                        chart.ToolTip = string.Format("流程名稱 : {0}<br />執行時間 : {1}", fs.DATACAT, fs.RUN_TIME);
                        chart.Color = fs.LIGHTGROUP;
                        list.Add(chart);
                    }

                    return list.AsQueryable();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
        }

        private double parseRunTime(string runTime)
        {
            try
            {
                runTime = runTime.Replace(" ", "");

                int day = 0;
                if (runTime.IndexOf("天") > 0)
                {
                    day = int.Parse(runTime.Substring(0, runTime.IndexOf("天")));
                    runTime = runTime.Replace(day + "天", "");
                }

                int hour = 0;
                if (runTime.IndexOf("時") > 0)
                {
                    hour = int.Parse(runTime.Substring(0, runTime.IndexOf("時")));
                    runTime = runTime.Replace(hour + "時", "");
                }

                int minite = 0;
                if (runTime.IndexOf("分") > 0)
                {
                    minite = int.Parse(runTime.Substring(0, runTime.IndexOf("分")));
                    runTime = runTime.Replace(minite + "分", "");
                }

                int second = 0;
                if (runTime.IndexOf("秒") > 0 && runTime.IndexOf("<") < 0)
                {
                    second = int.Parse(runTime.Substring(0, runTime.IndexOf("秒")));
                }

                double total = (day * 60 * 60 * 24) + (hour * 60 * 60) + (minite * 60) + second;

                return total;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
