﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WSP_DEL_XFlowTableController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        public async Task<IHttpActionResult> POST(WSP_DEL_XFlowTable data)
        {
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    foreach (string datacat in data.DATACAT)
                    {
                        SqlParameter[] SqlParam = new SqlParameter[1];
                        SqlParam[0] = new SqlParameter("@DATACAT", datacat);
                        db.Database.ExecuteSqlCommand("WSP_DEL_XFlowTable @DATACAT", SqlParam);
                    }

                    dbTransaction.Commit();

                    return StatusCode(HttpStatusCode.NoContent);
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }
        }
    }
}
