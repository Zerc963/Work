﻿using MetaEdge.ISMD.Entity.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_FileDetail_List_DataController : ODataController
    {
        private ISMDContext db = new ISMDContext();


        [Queryable]
        public IQueryable<Flow_Update_FileDetail_List_Data> Get([FromODataUri]string DATACAT)
        {
            var result = (from s1 in db.XFILEDETAIL//.Where(o => o.DATACAT ==DATACAT)
                          join s2 in db.XFLATFILEDETAIL//.Where(o => o.DATACAT ==DATACAT)
                          on new { s1.DATACAT, s1.FILE_SEQ } equals new { s2.DATACAT, s2.FILE_SEQ }
                          into subGrp

                          from s in subGrp.DefaultIfEmpty()
                          select new
                          {
                              s1.DATACAT
                              ,
                              s1.PROCESS_TYPE
                              ,
                              s1.FILE_SEQ
                              ,
                              s1.RSEQ
                              ,
                              s1.LSEQ
                              ,
                              s1.FILENAME
                              ,
                              s1.SRCNAME
                              ,
                              s1.SRCCNAME
                              ,
                              s1.PARENT_FILENAME
                              ,
                              s1.SKIP_FLAG
                              ,
                              s1.NOT_EXIST_SKIP_FG
                              ,
                              s1.ABORTCONTINUE_FLAG
                              ,
                              s1.CRT_FG
                              ,
                              s1.CHK_FG
                              ,
                              s1.UNZIP_FG
                              ,
                              s1.ZIP_PW
                              ,
                              s1.FILE_AMT_NM
                              ,
                              s1.TOLERANCE
                              ,
                              FILE_GROUP = s.FILE_GROUP ?? null
                              ,
                              CODEPAGE = s.CODEPAGE ?? null
                              ,
                              RAGGED_FIX = s.RAGGED_FIX ?? null
                              ,
                              RECORDLEN = s.RECORDLEN ?? null
                              ,
                              RAGGEDLEN = s.RAGGEDLEN ?? null
                              ,
                              DELIMITER = s.DELIMITER ?? null
                              ,
                              TERMINATOR = s.TERMINATOR ?? null
                              ,
                              FIRSTROW = s.FIRSTROW ?? null
                              ,
                              s1.LST_MAINT_USR
                              ,
                              s1.LST_MAINT_DT
                              //,
                              //ZIP_PW_value = "XXXXXXXX"

                          })
                          .Where(o => o.DATACAT == DATACAT)
                          .OrderBy(o => o.FILE_SEQ)
                          .ToList();


            List<Flow_Update_FileDetail_List_Data> list = new List<Flow_Update_FileDetail_List_Data>();

            foreach (var item in result)
            {
                Flow_Update_FileDetail_List_Data data = new Flow_Update_FileDetail_List_Data();

                data.DATACAT = item.DATACAT;
                data.PROCESS_TYPE = item.PROCESS_TYPE;
                data.FILE_SEQ = item.FILE_SEQ;
                data.RSEQ = item.RSEQ;
                data.LSEQ = item.LSEQ;
                data.FILENAME = item.FILENAME;
                data.SRCNAME = item.SRCNAME;
                data.SRCCNAME = item.SRCCNAME;
                data.PARENT_FILENAME = item.PARENT_FILENAME;
                data.SKIP_FLAG = item.SKIP_FLAG;
                data.NOT_EXIST_SKIP_FG = item.NOT_EXIST_SKIP_FG;
                data.ABORTCONTINUE_FLAG = item.ABORTCONTINUE_FLAG;
                data.CRT_FG = item.CRT_FG;
                data.CHK_FG = item.CHK_FG;
                data.UNZIP_FG = item.UNZIP_FG;
                data.ZIP_PW = item.ZIP_PW;
                data.FILE_AMT_NM = item.FILE_AMT_NM;
                data.TOLERANCE = item.TOLERANCE;
                data.FILE_GROUP = item.FILE_GROUP ?? null;
                data.CODEPAGE = item.CODEPAGE ?? null;
                data.RAGGED_FIX = item.RAGGED_FIX ?? null;
                data.RECORDLEN = item.RECORDLEN ?? null;
                data.RAGGEDLEN = item.RAGGEDLEN ?? null;
                data.DELIMITER = item.DELIMITER ?? null;
                data.TERMINATOR = item.TERMINATOR ?? null;
                data.FIRSTROW = item.FIRSTROW ?? null;
                data.LST_MAINT_USR = item.LST_MAINT_USR;
                data.LST_MAINT_DT = item.LST_MAINT_DT;
                list.Add(data);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
