﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_WaitDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();



        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, Flow_Update_WaitDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    foreach (XWAITDETAIL_PrimaryKey deletePrimaryKey in List.DeleteDetail)
                    {
                        db.XWAITDETAIL.RemoveRange(db.XWAITDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.WAIT_SEQ == deletePrimaryKey.WAIT_SEQ));
                        await db.SaveChangesAsync();
                    }

                    foreach (XWAITDETAIL xwaitdetail in List.InsertDetail)
                    {
                        db.XWAITDETAIL.Add(xwaitdetail);
                        await db.SaveChangesAsync();
                    }

                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                dbTransaction.Commit();

            }
            return Created(List);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
