﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_LocalRemoteDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();



        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, Flow_Update_LocalRemoteDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {

                    foreach (XLOCALDETAIL_PrimaryKey deletePrimaryKey in List.DeleteLocalDetail)
                    {
                        db.XLOCALDETAIL.RemoveRange(db.XLOCALDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.LSEQ == deletePrimaryKey.LSEQ));
                        await db.SaveChangesAsync();
                    }

                    foreach (XLOCALDETAIL xlocaldetail in List.InsertLocalDetail)
                    {
                        db.XLOCALDETAIL.Add(xlocaldetail);
                        await db.SaveChangesAsync();
                    }


                    foreach (XREMOTEDETAIL_PrimaryKey deletePrimaryKey in List.DeleteRemoteDetail)
                    {
                        db.XREMOTEDETAIL.RemoveRange(db.XREMOTEDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.RSEQ == deletePrimaryKey.RSEQ));
                        await db.SaveChangesAsync();
                    }

                    foreach (XREMOTEDETAIL xremotedetail in List.InsertRemoteDetail)
                    {
                        db.XREMOTEDETAIL.Add(xremotedetail);
                        await db.SaveChangesAsync();
                    }

                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                dbTransaction.Commit();
            }
            return Created(List);

        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
