﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_JobDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XJOBDETAIL> GetXJOBDETAIL()
        {
            return db.XJOBDETAIL;
        }


        // POST odata/XJOBDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, Flow_Update_JobDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    foreach (XJOBDETAIL_PrimaryKey deletePrimaryKey in List.DeleteDetail)
                    {
                        db.XJOBDETAIL.RemoveRange(db.XJOBDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.JOB_STAGE == deletePrimaryKey.JOB_STAGE && o.JOB_FLOW == deletePrimaryKey.JOB_FLOW && o.JOB_SEQ == deletePrimaryKey.JOB_SEQ));
                        await db.SaveChangesAsync();
                    }

                    foreach (XJOBDETAIL xjobdetail in List.InsertDetail)
                    {
                        db.XJOBDETAIL.Add(xjobdetail);
                        await db.SaveChangesAsync();
                    }

                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                dbTransaction.Commit();
            }

            return Created(List);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
