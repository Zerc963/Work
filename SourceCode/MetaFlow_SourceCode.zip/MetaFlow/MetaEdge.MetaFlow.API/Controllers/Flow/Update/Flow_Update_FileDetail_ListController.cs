﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_FileDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();



        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, Flow_Update_FileDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {

                try
                {
                    foreach (XFILEDETAIL_PrimaryKey deletePrimaryKey in List.DeleteDetail)
                    {
                        var deleteFileDetail = db.XFILEDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.FILE_SEQ == deletePrimaryKey.FILE_SEQ);

                        if (deleteFileDetail.Count() > 0)
                        {
                            string zipPw = deleteFileDetail.First().ZIP_PW;

                            // 判斷要刪除的 XENCRYPTION 不存在於 List.InsertDetail
                            var insertFileDetail = List.InsertDetail.Where(o => o.ZIP_PW == zipPw);

                            if (!string.IsNullOrEmpty(zipPw) && insertFileDetail.Count() == 0)
                            {
                                db.XENCRYPTION.RemoveRange(db.XENCRYPTION.Where(o => o.SEQ == zipPw));
                            }
                        }

                        db.XFILEDETAIL.RemoveRange(db.XFILEDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.FILE_SEQ == deletePrimaryKey.FILE_SEQ));
                        db.XFLATFILEDETAIL.RemoveRange(db.XFLATFILEDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.FILE_SEQ == deletePrimaryKey.FILE_SEQ));
                        await db.SaveChangesAsync();
                    }

                    foreach (Flow_Update_FileDetail_List_Data data in List.InsertDetail)
                    {
                        string encryptionSeq = data.ZIP_PW;

                        if (!string.IsNullOrEmpty(data.ZIP_PW) && !XENCRYPTIONExists(data.ZIP_PW))
                        {
                            encryptionSeq = Guid.NewGuid().ToString().ToLower();

                            XENCRYPTION encryption = new XENCRYPTION();
                            encryption.SEQ = encryptionSeq;
                            encryption.VALUE = data.ZIP_PW;
                            encryption.LST_MAINT_USR = data.LST_MAINT_USR;
                            encryption.LST_MAINT_DT = data.LST_MAINT_DT;

                            db.XENCRYPTION.Add(encryption);
                        }

                        //5-2 XFILEDETAIL
                        XFILEDETAIL fileDetail = new XFILEDETAIL();
                        fileDetail.DATACAT = data.DATACAT;

                        fileDetail.PROCESS_TYPE = data.PROCESS_TYPE;
                        fileDetail.FILE_SEQ = data.FILE_SEQ;
                        fileDetail.RSEQ = data.RSEQ;
                        fileDetail.LSEQ = data.LSEQ;
                        fileDetail.FILENAME = data.FILENAME;
                        fileDetail.SRCNAME = data.SRCNAME;
                        fileDetail.SRCCNAME = data.SRCCNAME;
                        fileDetail.PARENT_FILENAME = data.PARENT_FILENAME;
                        fileDetail.SKIP_FLAG = data.SKIP_FLAG;
                        fileDetail.NOT_EXIST_SKIP_FG = data.NOT_EXIST_SKIP_FG;
                        fileDetail.ABORTCONTINUE_FLAG = data.ABORTCONTINUE_FLAG;
                        fileDetail.CRT_FG = data.CRT_FG;
                        fileDetail.CHK_FG = data.CHK_FG;
                        fileDetail.UNZIP_FG = data.UNZIP_FG;
                        fileDetail.ZIP_PW = encryptionSeq;
                        fileDetail.FILE_AMT_NM = data.FILE_AMT_NM;
                        fileDetail.TOLERANCE = data.TOLERANCE;

                        fileDetail.LST_MAINT_USR = data.LST_MAINT_USR;
                        fileDetail.LST_MAINT_DT = DateTime.Now;
                        db.XFILEDETAIL.Add(fileDetail);
                        await db.SaveChangesAsync();

                        // 5-3 XFLATFILEDETAIL
                        // 用data.RAGGED_FIX是否為空，來判斷flatFile存在與否
                        if (!string.IsNullOrEmpty(data.RAGGED_FIX))
                        {
                            XFLATFILEDETAIL xflatFile = new XFLATFILEDETAIL();
                            xflatFile.DATACAT = data.DATACAT;
                            xflatFile.FILE_SEQ = data.FILE_SEQ;
                            xflatFile.FILE_GROUP = data.FILE_GROUP;
                            xflatFile.CODEPAGE = data.CODEPAGE;
                            xflatFile.RAGGED_FIX = data.RAGGED_FIX;
                            xflatFile.RECORDLEN = data.RECORDLEN;
                            xflatFile.RAGGEDLEN = data.RAGGEDLEN;
                            xflatFile.DELIMITER = data.DELIMITER;
                            xflatFile.TERMINATOR = data.TERMINATOR;
                            xflatFile.FIRSTROW = data.FIRSTROW;
                            xflatFile.LST_MAINT_USR = data.LST_MAINT_USR;
                            xflatFile.LST_MAINT_DT = DateTime.Now;

                            db.XFLATFILEDETAIL.Add(xflatFile);
                        }
                        await db.SaveChangesAsync();
                    }

                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
                dbTransaction.Commit();
                return Created(List);
            }
        }

        private bool XENCRYPTIONExists(string SEQ)
        {
            return db.XENCRYPTION.Count(XENCRYPTION => (XENCRYPTION.SEQ == SEQ)) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
