﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_InitialLoadController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]string LST_MAINT_USR)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                // 刪除編輯的暫存資料
                // ================================================================================
                db.WWKSPC_XFLOWDETAIL.RemoveRange(db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XSCHEDULE.RemoveRange(db.WWKSPC_XSCHEDULE.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XLOCALDETAIL.RemoveRange(db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XREMOTEDETAIL.RemoveRange(db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XWAITDETAIL.RemoveRange(db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));

                var tmpFileList = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
                foreach (WWKSPC_XFILEDETAIL tmpFile in tmpFileList)
                {
                    db.WWKSPC_XENCRYPTION.RemoveRange(db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == tmpFile.ZIP_PW && o.LST_MAINT_USR == LST_MAINT_USR));
                }
                db.WWKSPC_XFILEDETAIL.RemoveRange(tmpFileList);
                db.WWKSPC_XFLATFILEDETAIL.RemoveRange(db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XJOBDETAIL.RemoveRange(db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XMAILDETAIL.RemoveRange(db.WWKSPC_XMAILDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XMONITOR_FILEWAIT.RemoveRange(db.WWKSPC_XMONITOR_FILEWAIT.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XMONITOR_FLOWTIME.RemoveRange(db.WWKSPC_XMONITOR_FLOWTIME.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                // ================================================================================

                // 將編輯的資料複製到暫存區
                // ================================================================================
                var flow = db.XFLOWDETAIL.Where(o => o.DATACAT == DATACAT);
                if (flow.Count() > 0)
                {
                    WWKSPC_XFLOWDETAIL tmpFlow = new WWKSPC_XFLOWDETAIL();
                    tmpFlow.DATACAT = flow.First().DATACAT;
                    tmpFlow.FLOW_TYPE = flow.First().FLOW_TYPE;
                    tmpFlow.DATACATNM = flow.First().DATACATNM;
                    tmpFlow.DT_TYPE = flow.First().DT_TYPE;
                    tmpFlow.DT_CHG_HR = flow.First().DT_CHG_HR;
                    tmpFlow.CYC_RERUN_FG = flow.First().CYC_RERUN_FG;
                    tmpFlow.CURR_CYC_FG = flow.First().CURR_CYC_FG;
                    tmpFlow.RETRY_TIMES = flow.First().RETRY_TIMES;
                    tmpFlow.ABORT_RESTART_INTERVAL = flow.First().ABORT_RESTART_INTERVAL;
                    tmpFlow.ABORT_NOTIFY_SKIP_TIMES = flow.First().ABORT_NOTIFY_SKIP_TIMES;
                    tmpFlow.AGENT_MODE = flow.First().AGENT_MODE;
                    tmpFlow.LOCAL_MODE = flow.First().LOCAL_MODE;
                    tmpFlow.LST_MAINT_USR = LST_MAINT_USR;
                    tmpFlow.LST_MAINT_DT = flow.First().LST_MAINT_DT;

                    db.WWKSPC_XFLOWDETAIL.Add(tmpFlow);
                }

                var scheduleList = db.XSCHEDULE.Where(o => o.DATACAT == DATACAT);
                foreach (XSCHEDULE schedule in scheduleList)
                {
                    WWKSPC_XSCHEDULE tmpSchedule = new WWKSPC_XSCHEDULE();
                    tmpSchedule.DATACAT = schedule.DATACAT;
                    tmpSchedule.PROCESS_TYPE = schedule.PROCESS_TYPE;
                    tmpSchedule.START_TIME = schedule.START_TIME;
                    tmpSchedule.END_TIME = schedule.END_TIME;
                    tmpSchedule.INTERVAL = schedule.INTERVAL;
                    tmpSchedule.EFFECTIVE_TIME = schedule.EFFECTIVE_TIME;
                    tmpSchedule.EXPIRATION_TIME = schedule.EXPIRATION_TIME;
                    tmpSchedule.LST_MAINT_USR = LST_MAINT_USR;
                    tmpSchedule.LST_MAINT_DT = schedule.LST_MAINT_DT;

                    db.WWKSPC_XSCHEDULE.Add(tmpSchedule);
                }

                var localList = db.XLOCALDETAIL.Where(o => o.DATACAT == DATACAT);
                foreach (XLOCALDETAIL local in localList)
                {
                    WWKSPC_XLOCALDETAIL tmpLocal = new WWKSPC_XLOCALDETAIL();
                    tmpLocal.DATACAT = local.DATACAT;
                    tmpLocal.LSEQ = local.LSEQ;
                    tmpLocal.LOCAL_PATH = local.LOCAL_PATH;
                    tmpLocal.WORK_PATH = local.WORK_PATH;
                    tmpLocal.BACKUP_PATH = local.BACKUP_PATH;
                    tmpLocal.LST_MAINT_USR = LST_MAINT_USR;
                    tmpLocal.LST_MAINT_DT = local.LST_MAINT_DT;

                    db.WWKSPC_XLOCALDETAIL.Add(tmpLocal);
                }

                var remoteList = db.XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT);
                foreach (XREMOTEDETAIL remote in remoteList)
                {
                    WWKSPC_XREMOTEDETAIL tmpRemote = new WWKSPC_XREMOTEDETAIL();
                    tmpRemote.DATACAT = remote.DATACAT;
                    tmpRemote.RSEQ = remote.RSEQ;
                    tmpRemote.SERVERTYPE = remote.SERVERTYPE;
                    tmpRemote.SERVERNM = remote.SERVERNM;
                    tmpRemote.USERCODE = remote.USERCODE;
                    tmpRemote.REMOTE_PATH = remote.REMOTE_PATH;
                    tmpRemote.LST_MAINT_USR = LST_MAINT_USR;
                    tmpRemote.LST_MAINT_DT = remote.LST_MAINT_DT;

                    db.WWKSPC_XREMOTEDETAIL.Add(tmpRemote);
                }

                var waitList = db.XWAITDETAIL.Where(o => o.DATACAT == DATACAT);
                foreach (XWAITDETAIL wait in waitList)
                {
                    WWKSPC_XWAITDETAIL tmpWait = new WWKSPC_XWAITDETAIL();
                    tmpWait.DATACAT = wait.DATACAT;
                    tmpWait.PROCESS_TYPE = wait.PROCESS_TYPE;
                    tmpWait.WAIT_SEQ = wait.WAIT_SEQ;
                    tmpWait.WAIT_TYPE = wait.WAIT_TYPE;
                    tmpWait.RSEQ = wait.RSEQ;
                    tmpWait.LSEQ = wait.LSEQ;
                    tmpWait.WAIT_NAME = wait.WAIT_NAME;
                    tmpWait.CHK_FG = wait.CHK_FG;
                    tmpWait.CHK_FILEDATE_FG = wait.CHK_FILEDATE_FG;
                    tmpWait.TOLERANCE = wait.TOLERANCE;
                    tmpWait.WAIT_SKIP_FLAG = wait.WAIT_SKIP_FLAG;
                    tmpWait.NOT_EXIST_SKIP_FG = wait.NOT_EXIST_SKIP_FG;
                    tmpWait.LST_MAINT_USR = LST_MAINT_USR;
                    tmpWait.LST_MAINT_DT = wait.LST_MAINT_DT;

                    db.WWKSPC_XWAITDETAIL.Add(tmpWait);
                }

                var fileList = db.XFILEDETAIL.Where(o => o.DATACAT == DATACAT).ToList();
                foreach (XFILEDETAIL file in fileList)
                {
                    WWKSPC_XFILEDETAIL tmpFile = new WWKSPC_XFILEDETAIL();
                    tmpFile.DATACAT = file.DATACAT;
                    tmpFile.PROCESS_TYPE = file.PROCESS_TYPE;
                    tmpFile.FILE_SEQ = file.FILE_SEQ;
                    tmpFile.RSEQ = file.RSEQ;
                    tmpFile.LSEQ = file.LSEQ;
                    tmpFile.FILENAME = file.FILENAME;
                    tmpFile.SRCNAME = file.SRCNAME;
                    tmpFile.SRCCNAME = file.SRCCNAME;
                    tmpFile.PARENT_FILENAME = file.PARENT_FILENAME;
                    tmpFile.SKIP_FLAG = file.SKIP_FLAG;
                    tmpFile.NOT_EXIST_SKIP_FG = file.NOT_EXIST_SKIP_FG;
                    tmpFile.ABORTCONTINUE_FLAG = file.ABORTCONTINUE_FLAG;
                    tmpFile.CRT_FG = file.CRT_FG;
                    tmpFile.CHK_FG = file.CHK_FG;
                    tmpFile.UNZIP_FG = file.UNZIP_FG;
                    tmpFile.ZIP_PW = file.ZIP_PW;
                    tmpFile.FILE_AMT_NM = file.FILE_AMT_NM;
                    tmpFile.TOLERANCE = file.TOLERANCE;
                    tmpFile.LST_MAINT_USR = LST_MAINT_USR;
                    tmpFile.LST_MAINT_DT = file.LST_MAINT_DT;

                    db.WWKSPC_XFILEDETAIL.Add(tmpFile);

                    if (!string.IsNullOrEmpty(file.ZIP_PW))
                    {
                        var encryptionList = db.XENCRYPTION.Where(o => o.SEQ == file.ZIP_PW).ToList();

                        if (encryptionList.Count() > 0)
                        {
                            WWKSPC_XENCRYPTION tmpEncryption = new WWKSPC_XENCRYPTION();
                            tmpEncryption.SEQ = encryptionList.First().SEQ;

                            string encryptionValue = db.Database.SqlQuery<string>("select dbo.Decrypt(@Value)", new SqlParameter("Value", encryptionList.First().VALUE)).ToList().First();
                            tmpEncryption.VALUE = encryptionValue;

                            tmpEncryption.LST_MAINT_USR = LST_MAINT_USR;
                            tmpEncryption.LST_MAINT_DT = encryptionList.First().LST_MAINT_DT;

                            db.WWKSPC_XENCRYPTION.Add(tmpEncryption);
                        }
                    }
                }

                var flatFileList = db.XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT);
                foreach (XFLATFILEDETAIL flatFile in flatFileList)
                {
                    WWKSPC_XFLATFILEDETAIL tmpFlatFile = new WWKSPC_XFLATFILEDETAIL();
                    tmpFlatFile.DATACAT = flatFile.DATACAT;
                    tmpFlatFile.FILE_SEQ = flatFile.FILE_SEQ;
                    tmpFlatFile.FILE_GROUP = flatFile.FILE_GROUP;
                    tmpFlatFile.CODEPAGE = flatFile.CODEPAGE;
                    tmpFlatFile.RAGGED_FIX = flatFile.RAGGED_FIX;
                    tmpFlatFile.RECORDLEN = flatFile.RECORDLEN;
                    tmpFlatFile.RAGGEDLEN = flatFile.RAGGEDLEN;
                    tmpFlatFile.DELIMITER = flatFile.DELIMITER;
                    tmpFlatFile.TERMINATOR = flatFile.TERMINATOR;
                    tmpFlatFile.FIRSTROW = flatFile.FIRSTROW;
                    tmpFlatFile.LST_MAINT_USR = LST_MAINT_USR;
                    tmpFlatFile.LST_MAINT_DT = flatFile.LST_MAINT_DT;

                    db.WWKSPC_XFLATFILEDETAIL.Add(tmpFlatFile);
                }

                var jobList = db.XJOBDETAIL.Where(o => o.DATACAT == DATACAT);
                foreach (XJOBDETAIL job in jobList)
                {
                    WWKSPC_XJOBDETAIL tmpJob = new WWKSPC_XJOBDETAIL();
                    tmpJob.DATACAT = job.DATACAT;
                    tmpJob.PROCESS_TYPE = job.PROCESS_TYPE;
                    tmpJob.JOB_STAGE = job.JOB_STAGE;
                    tmpJob.JOB_FLOW = job.JOB_FLOW;
                    tmpJob.JOB_SEQ = job.JOB_SEQ;
                    tmpJob.JOB_NAME = job.JOB_NAME;
                    tmpJob.PARAM = job.PARAM;
                    tmpJob.SKIP_FLAG = job.SKIP_FLAG;
                    tmpJob.FORK_FLAG = job.FORK_FLAG;
                    tmpJob.ABORTCONTINUE_FLAG = job.ABORTCONTINUE_FLAG;
                    tmpJob.SRC_TB = job.SRC_TB;
                    tmpJob.TGT_TB = job.TGT_TB;
                    tmpJob.JOB_TYPE = job.JOB_TYPE;
                    tmpJob.JOB_DESC = job.JOB_DESC;
                    tmpJob.JOB_LOCATION = job.JOB_LOCATION;
                    tmpJob.JOB_OWNER = job.JOB_OWNER;
                    tmpJob.LST_MAINT_USR = LST_MAINT_USR;
                    tmpJob.LST_MAINT_DT = job.LST_MAINT_DT;

                    db.WWKSPC_XJOBDETAIL.Add(tmpJob);
                }

                var mailList = db.XMAILDETAIL.Where(o => o.DATACAT == DATACAT);
                foreach (XMAILDETAIL mail in mailList)
                {
                    WWKSPC_XMAILDETAIL tmpMail = new WWKSPC_XMAILDETAIL();
                    tmpMail.DATACAT = mail.DATACAT;
                    tmpMail.MAIL_TYPE = mail.MAIL_TYPE;
                    tmpMail.MAILADR = mail.MAILADR;
                    tmpMail.MAIL_DESC = mail.MAIL_DESC;
                    tmpMail.LST_MAINT_USR = LST_MAINT_USR;
                    tmpMail.LST_MAINT_DT = mail.LST_MAINT_DT;

                    db.WWKSPC_XMAILDETAIL.Add(tmpMail);
                }

                var monitorFileWaitList = db.XMONITOR_FILEWAIT.Where(o => o.DATACAT == DATACAT);
                foreach (XMONITOR_FILEWAIT monitorFileWait in monitorFileWaitList)
                {
                    WWKSPC_XMONITOR_FILEWAIT tmpMonitorFileWait = new WWKSPC_XMONITOR_FILEWAIT();
                    tmpMonitorFileWait.DATACAT = monitorFileWait.DATACAT;
                    tmpMonitorFileWait.START_TIME = monitorFileWait.START_TIME;
                    tmpMonitorFileWait.END_TIME = monitorFileWait.END_TIME;
                    tmpMonitorFileWait.LST_MAINT_USR = LST_MAINT_USR;
                    tmpMonitorFileWait.LST_MAINT_DT = monitorFileWait.LST_MAINT_DT;

                    db.WWKSPC_XMONITOR_FILEWAIT.Add(tmpMonitorFileWait);
                }

                var monitorFlowTimeList = db.XMONITOR_FLOWTIME.Where(o => o.DATACAT == DATACAT);
                foreach (XMONITOR_FLOWTIME monitorFlowTime in monitorFlowTimeList)
                {
                    WWKSPC_XMONITOR_FLOWTIME tmpMonitorFlowTime = new WWKSPC_XMONITOR_FLOWTIME();
                    tmpMonitorFlowTime.DATACAT = monitorFlowTime.DATACAT;
                    tmpMonitorFlowTime.MAX_DURATION_TIME = monitorFlowTime.MAX_DURATION_TIME;
                    tmpMonitorFlowTime.START_TIME = monitorFlowTime.START_TIME;
                    tmpMonitorFlowTime.EXPECT_END_TIME = monitorFlowTime.EXPECT_END_TIME;
                    tmpMonitorFlowTime.CHK_TIME = monitorFlowTime.CHK_TIME;
                    tmpMonitorFlowTime.CHK_STATUS = monitorFlowTime.CHK_STATUS;
                    tmpMonitorFlowTime.BATCH_NO = monitorFlowTime.BATCH_NO;
                    tmpMonitorFlowTime.LST_MAINT_USR = LST_MAINT_USR;
                    tmpMonitorFlowTime.LST_MAINT_DT = monitorFlowTime.LST_MAINT_DT;

                    db.WWKSPC_XMONITOR_FLOWTIME.Add(tmpMonitorFlowTime);
                }
                // ================================================================================

                try
                {
                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return StatusCode(HttpStatusCode.Created);
            }
        }

        private bool XENCRYPTIONExists(string SEQ)
        {
            return db.XENCRYPTION.Count(XENCRYPTION => (XENCRYPTION.SEQ == SEQ)) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
