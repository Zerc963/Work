﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_Schedule_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();


        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, Flow_Update_Schedule_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    foreach (XSCHEDULE_PrimaryKey deletePrimaryKey in List.DeleteDetail)
                    {
                        db.XSCHEDULE.RemoveRange(db.XSCHEDULE.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.PROCESS_TYPE == deletePrimaryKey.PROCESS_TYPE && o.START_TIME == deletePrimaryKey.START_TIME));
                        await db.SaveChangesAsync();
                    }

                    foreach (XSCHEDULE xschedule in List.InsertDetail)
                    {
                        db.XSCHEDULE.Add(xschedule);
                        await db.SaveChangesAsync();
                    }
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                dbTransaction.Commit();
            }

            return Created(List);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
