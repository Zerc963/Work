﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;
using System.Data.SqlClient;
using System.Text;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_UpdateController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, [FromODataUri]string LST_MAINT_USR, Flow_Update FlowUpdate)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (DATACAT != FlowUpdate.FlowDetail.DATACAT || LST_MAINT_USR != FlowUpdate.FlowDetail.LST_MAINT_USR)
            {
                return BadRequest();
            }

            StringBuilder sbException = new StringBuilder();

            // 資料檢核 Start
            // ========================================================================

            // 1. WaitDetail檢核LSEQ、RSEQ是否有對應的資料
            // =========================================
            if (FlowUpdate.WaitDetailIsLoaded == false)
            {
                var waitCheckList = db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                if (FlowUpdate.LocalDetailIsLoaded == true)
                {
                    foreach (WWKSPC_XWAITDETAIL wait in waitCheckList)
                    {
                        switch (wait.WAIT_TYPE)
                        {
                            case "F":
                                if (FlowUpdate.LocalDetail.Where(o => o.LSEQ == wait.LSEQ).Count() == 0)
                                {
                                    sbException.Append("XWAITDETAIL;");
                                }
                                if (!string.IsNullOrEmpty(wait.RSEQ))
                                {
                                    if (FlowUpdate.RemoteDetail.Where(o => o.RSEQ == wait.RSEQ).Count() == 0)
                                    {
                                        sbException.Append("XWAITDETAIL;");
                                    }
                                }

                                break;
                            case "D":
                                if (FlowUpdate.LocalDetail.Where(o => o.LSEQ == wait.LSEQ).Count() == 0)
                                {
                                    sbException.Append("XWAITDETAIL;");
                                }
                                break;
                            case "B":
                                break;
                            case "J":
                                break;
                        }
                    }
                }
                else
                {
                    var localDetail = db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
                    var remoteDetail = db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                    foreach (WWKSPC_XWAITDETAIL wait in waitCheckList)
                    {
                        switch (wait.WAIT_TYPE)
                        {
                            case "F":
                                if (localDetail.Where(o => o.LSEQ == wait.LSEQ).Count() == 0)
                                {
                                    sbException.Append("XWAITDETAIL;");
                                }
                                if (!string.IsNullOrEmpty(wait.RSEQ))
                                {
                                    if (remoteDetail.Where(o => o.RSEQ == wait.RSEQ).Count() == 0)
                                    {
                                        sbException.Append("XWAITDETAIL;");
                                    }
                                }
                                break;
                            case "D":
                                if (localDetail.Where(o => o.LSEQ == wait.LSEQ).Count() == 0)
                                {
                                    sbException.Append("XWAITDETAIL;");
                                }
                                break;
                            case "B":
                                break;
                            case "J":
                                break;
                        }
                    }
                }
            }
            // =========================================

            // 2. FileDetail檢核LSEQ、RSEQ是否有對應的資料
            // =========================================
            if (FlowUpdate.FileDetailIsLoaded == false)
            {
                var fileCheckList = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                if (FlowUpdate.LocalDetailIsLoaded)
                {
                    foreach (WWKSPC_XFILEDETAIL file in fileCheckList)
                    {
                        if (FlowUpdate.LocalDetail.Where(o => o.LSEQ == file.LSEQ).Count() == 0)
                        {
                            sbException.Append("XFILEDETAIL;");
                        }
                        if (!string.IsNullOrEmpty(file.RSEQ))
                        {
                            if (FlowUpdate.RemoteDetail.Where(o => o.RSEQ == file.RSEQ).Count() == 0)
                            {
                                sbException.Append("XFILEDETAIL;");
                            }
                        }
                    }
                }
                else
                {
                    var localDetail = db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
                    var remoteDetail = db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                    foreach (WWKSPC_XFILEDETAIL file in fileCheckList)
                    {
                        if (localDetail.Where(o => o.LSEQ == file.LSEQ).Count() == 0)
                        {
                            sbException.Append("XFILEDETAIL;");
                        }
                        if (!string.IsNullOrEmpty(file.RSEQ))
                        {
                            if (remoteDetail.Where(o => o.RSEQ == file.RSEQ).Count() == 0)
                            {
                                sbException.Append("XFILEDETAIL;");
                            }
                        }
                    }
                }
            }
            // =========================================

            // 3. JobDetail檢核IS_StgTable_FlatFile是否有對應的FileGroup
            // =========================================
            if (FlowUpdate.JobDetailIsLoaded == false)
            {
                var jobCheckList = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.JOB_NAME == "IS_StgTable_FlatFile" && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                if (FlowUpdate.FileDetailIsLoaded == true && jobCheckList.Count() > 0)
                {
                    if (FlowUpdate.FileDetail.Count() == 0)
                    {
                        sbException.Append("XJOBDETAIL;");
                    }
                    else
                    {
                        foreach (WWKSPC_XJOBDETAIL job in jobCheckList)
                        {
                            string SrcFileGroup = string.IsNullOrEmpty(job.PARAM) ? string.Empty : job.PARAM.Split(';')[0].Replace("SrcFileGroup=", "");
                            if (!string.IsNullOrEmpty(SrcFileGroup))
                            {
                                if (FlowUpdate.FileDetail.Where(o => o.FILE_GROUP == SrcFileGroup).Count() == 0)
                                {
                                    sbException.Append("XJOBDETAIL;");
                                }
                            }
                        }
                    }
                }
            }
            // =========================================

            if (sbException.Length > 0)
            {
                throw new Exception(sbException.ToString());
            }

            // 資料檢核 End
            // ========================================================================


            bool isScheduleUpdated = false; // 紀錄「排程時間」是否有異動，有的話，需要重新計算「下次執行時間」

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                DateTime updateTime = (DateTime)FlowUpdate.FlowDetail.LST_MAINT_DT;

                // 1. XFLOWDETAIL
                FlowUpdate.FlowDetail.LST_MAINT_DT = DateTime.Now;
                db.Entry(FlowUpdate.FlowDetail).State = EntityState.Modified;

                db.WWKSPC_XFLOWDETAIL.RemoveRange(db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                // 2. XSCHEDULE
                // if 1.有維護資料，則刪除再新增
                // if 2.無維護資料，並且 ScheduleIsLoaded 判斷頁面已載入，故刪除所有資料
                if (FlowUpdate.Schedule.Count() > 0)
                {
                    isScheduleUpdated = true;

                    db.XSCHEDULE.RemoveRange(db.XSCHEDULE.Where(o => o.DATACAT == DATACAT));

                    foreach (XSCHEDULE schedule in FlowUpdate.Schedule)
                    {
                        if (schedule.LST_MAINT_DT > updateTime)
                        {
                            schedule.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            schedule.LST_MAINT_DT = DateTime.Now;
                        }

                        db.XSCHEDULE.Add(schedule);
                    }
                }
                else if (FlowUpdate.ScheduleIsLoaded == true)
                {
                    isScheduleUpdated = true;
                    db.XSCHEDULE.RemoveRange(db.XSCHEDULE.Where(o => o.DATACAT == DATACAT));
                }

                db.WWKSPC_XSCHEDULE.RemoveRange(db.WWKSPC_XSCHEDULE.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                // 3-1. XLOCALDETAIL
                // if 1.有維護資料，則刪除再新增
                // if 2.無維護資料，並且 LocalDetailIsLoaded 判斷頁面已載入，故刪除所有資料
                if (FlowUpdate.LocalDetail.Count() > 0)
                {
                    db.XLOCALDETAIL.RemoveRange(db.XLOCALDETAIL.Where(o => o.DATACAT == DATACAT));

                    foreach (XLOCALDETAIL local in FlowUpdate.LocalDetail)
                    {
                        if (local.LST_MAINT_DT > updateTime)
                        {
                            local.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            local.LST_MAINT_DT = DateTime.Now;
                        }

                        db.XLOCALDETAIL.Add(local);
                    }
                }
                else if (FlowUpdate.LocalDetailIsLoaded == true)
                {
                    db.XLOCALDETAIL.RemoveRange(db.XLOCALDETAIL.Where(o => o.DATACAT == DATACAT));
                }

                db.WWKSPC_XLOCALDETAIL.RemoveRange(db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                // 3-2. XREMOTEDETAIL
                // if 1.有維護資料，則刪除再新增
                // if 2.無維護資料，並且 RemoteDetailIsLoaded 判斷頁面已載入，故刪除所有資料
                if (FlowUpdate.RemoteDetail.Count() > 0)
                {
                    db.XREMOTEDETAIL.RemoveRange(db.XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT));

                    foreach (XREMOTEDETAIL remote in FlowUpdate.RemoteDetail)
                    {
                        if (remote.LST_MAINT_DT > updateTime)
                        {
                            remote.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            remote.LST_MAINT_DT = DateTime.Now;
                        }

                        db.XREMOTEDETAIL.Add(remote);
                    }
                }
                else if (FlowUpdate.RemoteDetailIsLoaded == true)
                {
                    db.XREMOTEDETAIL.RemoveRange(db.XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT));
                }

                db.WWKSPC_XREMOTEDETAIL.RemoveRange(db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                // 4. XWAITDETAIL
                // if 1.有維護資料，則刪除再新增
                // if 2.無維護資料，並且 WaitDetailIsLoaded 判斷頁面已載入，故刪除所有資料
                // if 3.無維護資料，並且 WaitDetailIsLoaded 判斷頁面沒有載入，XLOCALDETAIL 或 XREMOTEDETAIL 有維護資料，而且 WWKSPC_XWAITDETAIL 也有資料
                //      以 WWKSPC_XWAITDETAIL 為主，刪除再新增
                if (FlowUpdate.WaitDetail.Count() > 0)
                {
                    db.XWAITDETAIL.RemoveRange(db.XWAITDETAIL.Where(o => o.DATACAT == DATACAT));

                    foreach (XWAITDETAIL wait in FlowUpdate.WaitDetail)
                    {
                        if (wait.LST_MAINT_DT > updateTime)
                        {
                            wait.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            wait.LST_MAINT_DT = DateTime.Now;
                        }

                        db.XWAITDETAIL.Add(wait);
                    }
                }
                else if (FlowUpdate.WaitDetailIsLoaded == true)
                {
                    db.XWAITDETAIL.RemoveRange(db.XWAITDETAIL.Where(o => o.DATACAT == DATACAT));
                }
                else if ((FlowUpdate.LocalDetail.Count() > 0 || FlowUpdate.RemoteDetail.Count() > 0) && db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).Count() > 0)
                {
                    db.XWAITDETAIL.RemoveRange(db.XWAITDETAIL.Where(o => o.DATACAT == DATACAT));

                    var waitList = db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);

                    foreach (WWKSPC_XWAITDETAIL tmpWait in waitList)
                    {
                        XWAITDETAIL wait = new XWAITDETAIL();
                        wait.DATACAT = tmpWait.DATACAT;
                        wait.PROCESS_TYPE = tmpWait.PROCESS_TYPE;
                        wait.WAIT_SEQ = tmpWait.WAIT_SEQ;
                        wait.WAIT_TYPE = tmpWait.WAIT_TYPE;
                        wait.RSEQ = tmpWait.RSEQ;
                        wait.LSEQ = tmpWait.LSEQ;
                        wait.WAIT_NAME = tmpWait.WAIT_NAME;
                        wait.CHK_FG = tmpWait.CHK_FG;
                        wait.CHK_FILEDATE_FG = tmpWait.CHK_FILEDATE_FG;
                        wait.TOLERANCE = tmpWait.TOLERANCE;
                        wait.WAIT_SKIP_FLAG = tmpWait.WAIT_SKIP_FLAG;
                        wait.NOT_EXIST_SKIP_FG = tmpWait.NOT_EXIST_SKIP_FG;

                        if (tmpWait.LST_MAINT_DT > updateTime)
                        {
                            wait.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            wait.LST_MAINT_DT = DateTime.Now;
                        }
                        else
                        {
                            wait.LST_MAINT_USR = tmpWait.LST_MAINT_USR;
                            wait.LST_MAINT_DT = tmpWait.LST_MAINT_DT;
                        }

                        db.XWAITDETAIL.Add(wait);
                    }
                }

                db.WWKSPC_XWAITDETAIL.RemoveRange(db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                // 5. XFILEDETAIL + XENCRYPTION + XFLATFILEDETAIL
                // if 1.有維護資料，則刪除再新增
                // if 2.無維護資料，並且 FileDetailIsLoaded 判斷頁面已載入，故刪除所有資料
                // if 3.無維護資料，並且 FileDetailIsLoaded 判斷頁面沒有載入，XLOCALDETAIL 或 XREMOTEDETAIL 有維護資料，而且 WWKSPC_XFILEDETAIL 也有資料
                //      以 XFILEDETAIL + XENCRYPTION + XFLATFILEDETAIL 為主，刪除再新增
                if (FlowUpdate.FileDetail.Count() > 0)
                {
                    var tmpFileList = db.XFILEDETAIL.Where(o => o.DATACAT == DATACAT).ToList();
                    foreach (XFILEDETAIL tmpFile in tmpFileList)
                    {
                        db.XENCRYPTION.RemoveRange(db.XENCRYPTION.Where(o => o.SEQ == tmpFile.ZIP_PW));
                    }
                    db.XFILEDETAIL.RemoveRange(tmpFileList);
                    db.XFLATFILEDETAIL.RemoveRange(db.XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT));

                    foreach (Flow_Insert_FileDetail_List_Data file in FlowUpdate.FileDetail)
                    {
                        // 5-1 XENCRYPTION
                        if (!string.IsNullOrEmpty(file.ZIP_PW))
                        {
                            XENCRYPTION encryption = new XENCRYPTION();
                            encryption.SEQ = file.ZIP_PW;

                            encryption.VALUE = db.Database.SqlQuery<string>("select dbo.Decrypt(@Value)", new SqlParameter("Value", file.ZIP_PW_Value)).ToList().First();

                            if (file.LST_MAINT_DT > updateTime)
                            {
                                encryption.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                                encryption.LST_MAINT_DT = DateTime.Now;
                            }
                            else
                            {
                                encryption.LST_MAINT_USR = file.LST_MAINT_USR;
                                encryption.LST_MAINT_DT = file.LST_MAINT_DT;
                            }

                            db.XENCRYPTION.Add(encryption);
                        }

                        //5-2 XFILEDETAIL
                        XFILEDETAIL fileDetail = new XFILEDETAIL();
                        fileDetail.DATACAT = FlowUpdate.FlowDetail.DATACAT;
                        fileDetail.PROCESS_TYPE = file.PROCESS_TYPE;
                        fileDetail.FILE_SEQ = file.FILE_SEQ;
                        fileDetail.RSEQ = file.RSEQ;
                        fileDetail.LSEQ = file.LSEQ;
                        fileDetail.FILENAME = file.FILENAME;
                        fileDetail.SRCNAME = file.SRCNAME;
                        fileDetail.SRCCNAME = file.SRCCNAME;
                        fileDetail.PARENT_FILENAME = file.PARENT_FILENAME;
                        fileDetail.SKIP_FLAG = file.SKIP_FLAG;
                        fileDetail.NOT_EXIST_SKIP_FG = file.NOT_EXIST_SKIP_FG;
                        fileDetail.ABORTCONTINUE_FLAG = file.ABORTCONTINUE_FLAG;
                        fileDetail.CRT_FG = file.CRT_FG;
                        fileDetail.CHK_FG = file.CHK_FG;
                        fileDetail.UNZIP_FG = file.UNZIP_FG;
                        fileDetail.ZIP_PW = file.ZIP_PW;
                        fileDetail.FILE_AMT_NM = file.FILE_AMT_NM;
                        fileDetail.TOLERANCE = file.TOLERANCE;

                        if (file.LST_MAINT_DT > updateTime)
                        {
                            fileDetail.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            fileDetail.LST_MAINT_DT = DateTime.Now;
                        }
                        else
                        {
                            fileDetail.LST_MAINT_USR = file.LST_MAINT_USR;
                            fileDetail.LST_MAINT_DT = file.LST_MAINT_DT;
                        }

                        db.XFILEDETAIL.Add(fileDetail);

                        // 5-3 XFLATFILEDETAIL
                        // 用data.RAGGED_FIX是否為空，來判斷flatFile存在與否
                        if (!string.IsNullOrEmpty(file.RAGGED_FIX))
                        {
                            XFLATFILEDETAIL xflatFile = new XFLATFILEDETAIL();
                            xflatFile.DATACAT = FlowUpdate.FlowDetail.DATACAT;
                            xflatFile.FILE_SEQ = file.FILE_SEQ;
                            xflatFile.FILE_GROUP = file.FILE_GROUP;
                            xflatFile.CODEPAGE = file.CODEPAGE;
                            xflatFile.RAGGED_FIX = file.RAGGED_FIX;
                            xflatFile.RECORDLEN = file.RECORDLEN;
                            xflatFile.RAGGEDLEN = file.RAGGEDLEN;
                            xflatFile.DELIMITER = file.DELIMITER;
                            xflatFile.TERMINATOR = file.TERMINATOR;
                            xflatFile.FIRSTROW = file.FIRSTROW;

                            if (file.LST_MAINT_DT > updateTime)
                            {
                                xflatFile.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                                xflatFile.LST_MAINT_DT = DateTime.Now;
                            }
                            else
                            {
                                xflatFile.LST_MAINT_USR = file.LST_MAINT_USR;
                                xflatFile.LST_MAINT_DT = file.LST_MAINT_DT;
                            }

                            db.XFLATFILEDETAIL.Add(xflatFile);
                        }
                    }
                }
                else if (FlowUpdate.FileDetailIsLoaded == true)
                {
                    var fileList = db.XFILEDETAIL.Where(o => o.DATACAT == DATACAT).ToList();
                    foreach (XFILEDETAIL file in fileList)
                    {
                        db.XENCRYPTION.RemoveRange(db.XENCRYPTION.Where(o => o.SEQ == file.ZIP_PW));
                    }
                    db.XFILEDETAIL.RemoveRange(fileList);
                    db.XFLATFILEDETAIL.RemoveRange(db.XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT));
                }
                else if ((FlowUpdate.LocalDetail.Count() > 0 || FlowUpdate.RemoteDetail.Count() > 0) && db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).Count() > 0)
                {
                    var fileList = db.XFILEDETAIL.Where(o => o.DATACAT == DATACAT).ToList();
                    foreach (XFILEDETAIL file in fileList)
                    {
                        db.XENCRYPTION.RemoveRange(db.XENCRYPTION.Where(o => o.SEQ == file.ZIP_PW));
                    }
                    db.XFILEDETAIL.RemoveRange(fileList);
                    db.XFLATFILEDETAIL.RemoveRange(db.XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT));

                    var tmpFileList = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();

                    foreach (WWKSPC_XFILEDETAIL tmpFile in tmpFileList)
                    {
                        // 5-1 XFILEDETAIL
                        XFILEDETAIL file = new XFILEDETAIL();
                        file.DATACAT = tmpFile.DATACAT;
                        file.PROCESS_TYPE = tmpFile.PROCESS_TYPE;
                        file.FILE_SEQ = tmpFile.FILE_SEQ;
                        file.RSEQ = tmpFile.RSEQ;
                        file.LSEQ = tmpFile.LSEQ;
                        file.FILENAME = tmpFile.FILENAME;
                        file.SRCNAME = tmpFile.SRCNAME;
                        file.SRCCNAME = tmpFile.SRCCNAME;
                        file.PARENT_FILENAME = tmpFile.PARENT_FILENAME;
                        file.SKIP_FLAG = tmpFile.SKIP_FLAG;
                        file.NOT_EXIST_SKIP_FG = tmpFile.NOT_EXIST_SKIP_FG;
                        file.ABORTCONTINUE_FLAG = tmpFile.ABORTCONTINUE_FLAG;
                        file.CRT_FG = tmpFile.CRT_FG;
                        file.CHK_FG = tmpFile.CHK_FG;
                        file.UNZIP_FG = tmpFile.UNZIP_FG;
                        file.ZIP_PW = tmpFile.ZIP_PW;
                        file.FILE_AMT_NM = tmpFile.FILE_AMT_NM;
                        file.TOLERANCE = tmpFile.TOLERANCE;

                        if (file.LST_MAINT_DT > updateTime)
                        {
                            file.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            file.LST_MAINT_DT = DateTime.Now;
                        }
                        else
                        {
                            file.LST_MAINT_USR = tmpFile.LST_MAINT_USR;
                            file.LST_MAINT_DT = tmpFile.LST_MAINT_DT;
                        }

                        db.XFILEDETAIL.Add(file);

                        // 5-2 XENCRYPTION
                        if (!string.IsNullOrEmpty(file.ZIP_PW))
                        {
                            var encryptionList = db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == file.ZIP_PW && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
                            if (encryptionList.Count() > 0)
                            {
                                XENCRYPTION encryption = new XENCRYPTION();
                                encryption.SEQ = file.ZIP_PW;

                                encryption.VALUE = db.Database.SqlQuery<string>("select dbo.Encrypt(@Value)", new SqlParameter("Value", encryptionList.First().VALUE)).ToList().First();

                                if (file.LST_MAINT_DT > updateTime)
                                {
                                    encryption.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                                    encryption.LST_MAINT_DT = DateTime.Now;
                                }
                                else
                                {
                                    encryption.LST_MAINT_USR = file.LST_MAINT_USR;
                                    encryption.LST_MAINT_DT = file.LST_MAINT_DT;
                                }

                                db.XENCRYPTION.Add(encryption);
                            }
                        }
                    }


                    // 5-3 XFLATFILEDETAIL
                    var tmpFlatFileList = db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);

                    foreach (WWKSPC_XFLATFILEDETAIL tmpFlatFile in tmpFlatFileList)
                    {
                        XFLATFILEDETAIL flatFile = new XFLATFILEDETAIL();
                        flatFile.DATACAT = tmpFlatFile.DATACAT;
                        flatFile.FILE_SEQ = tmpFlatFile.FILE_SEQ;
                        flatFile.FILE_GROUP = tmpFlatFile.FILE_GROUP;
                        flatFile.CODEPAGE = tmpFlatFile.CODEPAGE;
                        flatFile.RAGGED_FIX = tmpFlatFile.RAGGED_FIX;
                        flatFile.RECORDLEN = tmpFlatFile.RECORDLEN;
                        flatFile.RAGGEDLEN = tmpFlatFile.RAGGEDLEN;
                        flatFile.DELIMITER = tmpFlatFile.DELIMITER;
                        flatFile.TERMINATOR = tmpFlatFile.TERMINATOR;
                        flatFile.FIRSTROW = tmpFlatFile.FIRSTROW;

                        if (flatFile.LST_MAINT_DT > updateTime)
                        {
                            flatFile.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            flatFile.LST_MAINT_DT = DateTime.Now;
                        }
                        else
                        {
                            flatFile.LST_MAINT_USR = tmpFlatFile.LST_MAINT_USR;
                            flatFile.LST_MAINT_DT = tmpFlatFile.LST_MAINT_DT;
                        }

                        db.XFLATFILEDETAIL.Add(flatFile);
                    }
                }

                var tmpFileList2 = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
                foreach (WWKSPC_XFILEDETAIL file in tmpFileList2)
                {
                    db.WWKSPC_XENCRYPTION.RemoveRange(db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == file.ZIP_PW && o.LST_MAINT_USR == LST_MAINT_USR));
                }
                db.WWKSPC_XFILEDETAIL.RemoveRange(tmpFileList2);
                db.WWKSPC_XFLATFILEDETAIL.RemoveRange(db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                // 6. XJOBDETAIL
                // if 1.有維護資料，則刪除再新增
                // if 2.無維護資料，並且 JobDetailIsLoaded 判斷頁面已載入，故刪除所有資料
                // if 3.無維護資料，並且 JobDetailIsLoaded 判斷頁面沒有載入，XFILEDETAIL 有維護資料，而且 WWKSPC_XJOBDETAIL 也有資料
                //      以 WWKSPC_XJOBDETAIL 為主，刪除再新增
                if (FlowUpdate.JobDetail.Count() > 0)
                {
                    db.XJOBDETAIL.RemoveRange(db.XJOBDETAIL.Where(o => o.DATACAT == DATACAT));

                    foreach (XJOBDETAIL job in FlowUpdate.JobDetail)
                    {
                        if (job.LST_MAINT_DT > updateTime)
                        {
                            job.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            job.LST_MAINT_DT = DateTime.Now;
                        }

                        db.XJOBDETAIL.Add(job);
                    }
                }
                else if (FlowUpdate.JobDetailIsLoaded == true)
                {
                    db.XJOBDETAIL.RemoveRange(db.XJOBDETAIL.Where(o => o.DATACAT == DATACAT));
                }
                else if (FlowUpdate.FileDetail.Count() > 0 && db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR).Count() > 0)
                {
                    db.XJOBDETAIL.RemoveRange(db.XJOBDETAIL.Where(o => o.DATACAT == DATACAT));

                    var jobList = db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);

                    foreach (WWKSPC_XJOBDETAIL tmpJob in jobList)
                    {
                        XJOBDETAIL job = new XJOBDETAIL();
                        job.DATACAT = tmpJob.DATACAT;
                        job.PROCESS_TYPE = tmpJob.PROCESS_TYPE;
                        job.JOB_STAGE = tmpJob.JOB_STAGE;
                        job.JOB_FLOW = tmpJob.JOB_FLOW;
                        job.JOB_SEQ = tmpJob.JOB_SEQ;
                        job.JOB_NAME = tmpJob.JOB_NAME;
                        job.PARAM = tmpJob.PARAM;
                        job.SKIP_FLAG = tmpJob.SKIP_FLAG;
                        job.FORK_FLAG = tmpJob.FORK_FLAG;
                        job.ABORTCONTINUE_FLAG = tmpJob.ABORTCONTINUE_FLAG;
                        job.SRC_TB = tmpJob.SRC_TB;
                        job.TGT_TB = tmpJob.TGT_TB;
                        job.JOB_TYPE = tmpJob.JOB_TYPE;
                        job.JOB_DESC = tmpJob.JOB_DESC;
                        job.JOB_LOCATION = tmpJob.JOB_LOCATION;
                        job.JOB_OWNER = tmpJob.JOB_OWNER;

                        if (tmpJob.LST_MAINT_DT > updateTime)
                        {
                            job.LST_MAINT_USR = FlowUpdate.FlowDetail.LST_MAINT_USR;
                            job.LST_MAINT_DT = DateTime.Now;
                        }
                        else
                        {
                            job.LST_MAINT_USR = tmpJob.LST_MAINT_USR;
                            job.LST_MAINT_DT = tmpJob.LST_MAINT_DT;
                        }

                        db.XJOBDETAIL.Add(job);
                    }
                }

                db.WWKSPC_XJOBDETAIL.RemoveRange(db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                // 7-1. XMAILDETAIL
                // if 1.有維護資料，則刪除再新增
                if (FlowUpdate.MailDetail != null)
                {
                    db.XMAILDETAIL.RemoveRange(db.XMAILDETAIL.Where(o => o.DATACAT == DATACAT));

                    foreach (XMAILDETAIL_List_Data mail in FlowUpdate.MailDetail.mailDetail)
                    {
                        string lstMaintUsr = mail.LST_MAINT_DT > updateTime ? FlowUpdate.FlowDetail.LST_MAINT_USR : mail.LST_MAINT_USR;
                        DateTime lstMaintDt = mail.LST_MAINT_DT > updateTime ? DateTime.Now : (DateTime)mail.LST_MAINT_DT;

                        if (mail.notifyRUNOK_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(FlowUpdate.FlowDetail.DATACAT, "RUNOK", mail.MAILADR, mail.MAIL_DESC, lstMaintUsr, lstMaintDt));
                        }
                        if (mail.notifyABORT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(FlowUpdate.FlowDetail.DATACAT, "ABORT", mail.MAILADR, mail.MAIL_DESC, lstMaintUsr, lstMaintDt));
                        }
                        if (mail.notifyMONITOR_FILE_WAIT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(FlowUpdate.FlowDetail.DATACAT, "MONITOR FILE WAIT", mail.MAILADR, mail.MAIL_DESC, lstMaintUsr, lstMaintDt));
                        }
                        if (mail.notifyMONITOR_FLOW_TIME_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(FlowUpdate.FlowDetail.DATACAT, "MONITOR FLOW TIME", mail.MAILADR, mail.MAIL_DESC, lstMaintUsr, lstMaintDt));
                        }
                    }

                    // 7-2. XMONITOR_FILEWAIT
                    db.XMONITOR_FILEWAIT.RemoveRange(db.XMONITOR_FILEWAIT.Where(s => s.DATACAT == FlowUpdate.FlowDetail.DATACAT));
                    if (FlowUpdate.MailDetail.FILEWAIT_checked)
                    {
                        XMONITOR_FILEWAIT monitorFileWait = FlowUpdate.MailDetail.XMONITOR_FILEWAIT;
                        monitorFileWait.LST_MAINT_DT = DateTime.Now;
                        db.XMONITOR_FILEWAIT.Add(monitorFileWait);
                    }

                    // 7-3. XMONITOR_FLOWTIME
                    db.XMONITOR_FLOWTIME.RemoveRange(db.XMONITOR_FLOWTIME.Where(s => s.DATACAT == FlowUpdate.FlowDetail.DATACAT));
                    if (FlowUpdate.MailDetail.FLOWTIME_checked)
                    {
                        XMONITOR_FLOWTIME monitorFlowtime = FlowUpdate.MailDetail.XMONITOR_FLOWTIME;
                        monitorFlowtime.LST_MAINT_DT = DateTime.Now;
                        db.XMONITOR_FLOWTIME.Add(monitorFlowtime);
                    }
                }

                db.WWKSPC_XMAILDETAIL.RemoveRange(db.WWKSPC_XMAILDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XMONITOR_FILEWAIT.RemoveRange(db.WWKSPC_XMONITOR_FILEWAIT.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
                db.WWKSPC_XMONITOR_FLOWTIME.RemoveRange(db.WWKSPC_XMONITOR_FLOWTIME.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));


                try
                {
                    await db.SaveChangesAsync();

                    if (isScheduleUpdated)
                    {
                        SqlParameter[] SqlParam = new SqlParameter[1];
                        SqlParam[0] = new SqlParameter("@DATACAT", FlowUpdate.FlowDetail.DATACAT);
                        db.Database.ExecuteSqlCommand("WSP_UPD_FlowNextTime @DATACAT", SqlParam);
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(FlowUpdate);
            }
        }
        
        private bool XENCRYPTIONExists(string SEQ)
        {
            return db.XENCRYPTION.Count(XENCRYPTION => (XENCRYPTION.SEQ == SEQ)) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
