﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_Update_MailDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XJOBDETAIL
        public async Task<IHttpActionResult> Put([FromODataUri]string DATACAT, Flow_Update_MailDetail_List List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {

                foreach (XMAILDETAIL_List_Data_PrimaryKey deletePrimaryKey in List.DeleteMailDetail)
                {
                    db.XMAILDETAIL.RemoveRange(db.XMAILDETAIL.Where(o => o.DATACAT == deletePrimaryKey.DATACAT && o.MAILADR == deletePrimaryKey.MAILADR));
                    await db.SaveChangesAsync();
                }

                foreach (XMAILDETAIL_List_Data detail in List.InsertMailDetail)
                {
                    #region [ insert mailDetails ]
                    try
                    {
                        if (detail.notifyRUNOK_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(DATACAT, "RUNOK", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, DateTime.Now));
                        }
                        if (detail.notifyABORT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(DATACAT, "ABORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, DateTime.Now));
                        }
                        if (detail.notifyCHECK_FILE_REPORT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(DATACAT, "CHECK FILE REPORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, DateTime.Now));
                        }
                        if (detail.notifyFLOW_REPORT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "FLOW REPORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, DateTime.Now));
                        }
                        if (detail.notifyMONITOR_FILE_WAIT_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(DATACAT, "MONITOR FILE WAIT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, DateTime.Now));
                        }
                        if (detail.notifyMONITOR_FLOW_TIME_fg)
                        {
                            db.XMAILDETAIL.Add(new XMAILDETAIL(DATACAT, "MONITOR FLOW TIME", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, DateTime.Now));
                        }

                        await db.SaveChangesAsync();
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                    #endregion
                }

                db.XMONITOR_FILEWAIT.RemoveRange(db.XMONITOR_FILEWAIT.Where(s => s.DATACAT == DATACAT));
                await db.SaveChangesAsync();
                if (List.FILEWAIT_Checked)
                {
                    try
                    {
                        #region [ insert XMONITOR_FILEWAIT ]
                        XMONITOR_FILEWAIT monitorFileWait = List.XMONITOR_FILEWAIT;
                        db.XMONITOR_FILEWAIT.Add(monitorFileWait);

                        await db.SaveChangesAsync();
                        #endregion
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }

                db.XMONITOR_FLOWTIME.RemoveRange(db.XMONITOR_FLOWTIME.Where(s => s.DATACAT == DATACAT));
                await db.SaveChangesAsync();
                if (List.FLOWTIME_Checked)
                {
                    try
                    {
                        #region [ insert XMONITOR_FLOWTIME ]
                        XMONITOR_FLOWTIME monitorFlowtime = List.XMONITOR_FLOWTIME;
                        db.XMONITOR_FLOWTIME.Add(monitorFlowtime);

                        await db.SaveChangesAsync();

                        #endregion
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }
                dbTransaction.Commit();

            }

            return Created(List);
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
