﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XFILESTATUSController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XFILESTATUS> Get()
        {
            return db.XFILESTATUS;
        }

        public async Task<IHttpActionResult> Put([FromODataUri] string DATACAT, [FromODataUri] int FILE_SEQ, [FromODataUri] string ZIP_PW_value, XFILESTATUS XFILESTATUS)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (DATACAT != XFILESTATUS.DATACAT || FILE_SEQ != XFILESTATUS.FILE_SEQ)
            {
                return BadRequest();
            }

            if (!string.IsNullOrEmpty(ZIP_PW_value))
            {
                // 查詢修改前資料
                var encryptionList = db.XENCRYPTION.Where(o => o.SEQ == XFILESTATUS.ZIP_PW);

                // 若前端傳的 ZIP_PW 有異動，則新增密碼
                if (encryptionList.Count() == 0)
                {
                    XENCRYPTION encryption = new XENCRYPTION();
                    encryption.SEQ = XFILESTATUS.ZIP_PW;
                    encryption.VALUE = ZIP_PW_value;
                    encryption.LST_MAINT_USR = XFILESTATUS.LST_MAINT_USR;
                    encryption.LST_MAINT_DT = DateTime.Now;
                    db.XENCRYPTION.Add(encryption);
                }
            }

            db.Entry(XFILESTATUS).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!XFILESTATUSExists(DATACAT, FILE_SEQ))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(XFILESTATUS);
        }

        private bool XFILESTATUSExists(string DATACAT, int FILE_SEQ)
        {
            return db.XFILESTATUS.Count(XFILESTATUS => XFILESTATUS.DATACAT == DATACAT && XFILESTATUS.FILE_SEQ == FILE_SEQ) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
