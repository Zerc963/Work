﻿using MetaEdge.ISMD.Entity.Models;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XFLOWSTATUSHController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XFLOWSTATUSH> GetXFLOWSTATUSH()
        {
            return db.XFLOWSTATUSH;
        }        
    }
}
