﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System;
using System.Net;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XMONITOR_FLOWTIMEController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XMONITOR_FLOWTIME> Get()
        {
            return db.WWKSPC_XMONITOR_FLOWTIME;
        }

        // POST odata/WWKSPC_XMONITOR_FLOWTIME
        public async Task<IHttpActionResult> Post(WWKSPC_XMONITOR_FLOWTIME WWKSPC_XMONITOR_FLOWTIME)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WWKSPC_XMONITOR_FLOWTIME.RemoveRange(db.WWKSPC_XMONITOR_FLOWTIME.Where(o => o.DATACAT == WWKSPC_XMONITOR_FLOWTIME.DATACAT && o.LST_MAINT_USR == WWKSPC_XMONITOR_FLOWTIME.LST_MAINT_USR));
            db.WWKSPC_XMONITOR_FLOWTIME.Add(WWKSPC_XMONITOR_FLOWTIME);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XMONITOR_FLOWTIME);
        }

        public async Task<IHttpActionResult> Delete([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            IQueryable<WWKSPC_XMONITOR_FLOWTIME> deleteItem = db.WWKSPC_XMONITOR_FLOWTIME.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
            db.WWKSPC_XMONITOR_FLOWTIME.RemoveRange(deleteItem);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}
