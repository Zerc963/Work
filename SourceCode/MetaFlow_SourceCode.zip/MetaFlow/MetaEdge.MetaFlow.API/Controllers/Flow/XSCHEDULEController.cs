﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XSCHEDULEController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XSCHEDULE> Get()
        {
            return db.XSCHEDULE;
        }

        // POST odata/XSCHEDULE
        public async Task<IHttpActionResult> Post(XSCHEDULE XSCHEDULE)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.XSCHEDULE.Add(XSCHEDULE);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (XSCHEDULEExists(XSCHEDULE.DATACAT, XSCHEDULE.PROCESS_TYPE, XSCHEDULE.START_TIME))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            var new_XSCHEDULE = db.XSCHEDULE.Where<XSCHEDULE>(o => o.DATACAT == XSCHEDULE.DATACAT && o.PROCESS_TYPE == XSCHEDULE.PROCESS_TYPE && o.START_TIME == XSCHEDULE.START_TIME).First();
            return Created(new_XSCHEDULE);
        }

        private bool XSCHEDULEExists(string DATACAT, string PROCESS_TYPE, TimeSpan START_TIME)
        {
            return db.XSCHEDULE.Count(XSCHEDULE => XSCHEDULE.DATACAT == DATACAT && XSCHEDULE.PROCESS_TYPE == PROCESS_TYPE && XSCHEDULE.START_TIME == START_TIME) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
