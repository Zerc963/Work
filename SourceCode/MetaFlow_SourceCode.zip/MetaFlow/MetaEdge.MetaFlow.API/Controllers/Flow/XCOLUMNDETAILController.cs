﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XCOLUMNDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XCOLUMNDETAIL> Get()
        {
            return db.XCOLUMNDETAIL;
        }

        // POST odata/XCOLUMNDETAIL
        public async Task<IHttpActionResult> Post(XCOLUMNDETAIL XCOLUMNDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.XCOLUMNDETAIL.Add(XCOLUMNDETAIL);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (XCOLUMNDETAILExists(XCOLUMNDETAIL.DB_NM, XCOLUMNDETAIL.SCHEMA_NM, XCOLUMNDETAIL.TABLE_NM, XCOLUMNDETAIL.COLUMN_NM))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            var new_XCOLUMNDETAIL = db.XCOLUMNDETAIL.Where<XCOLUMNDETAIL>(o => o.DB_NM == XCOLUMNDETAIL.DB_NM && o.SCHEMA_NM == XCOLUMNDETAIL.SCHEMA_NM && o.TABLE_NM == XCOLUMNDETAIL.TABLE_NM && o.COLUMN_NM == XCOLUMNDETAIL.COLUMN_NM).First();
            return Created(new_XCOLUMNDETAIL);
        }

        // PUT odata/auth_Category(5)
        public async Task<IHttpActionResult> Put([FromODataUri]string DB_NM, [FromODataUri]string SCHEMA_NM, [FromODataUri]string TABLE_NM, [FromODataUri]string COLUMN_NM, XCOLUMNDETAIL XCOLUMNDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            //db.Entry(XCOLUMNDETAIL).State = EntityState.Modified;

            db.XCOLUMNDETAIL.RemoveRange(db.XCOLUMNDETAIL.Where(o => o.DB_NM == DB_NM && o.SCHEMA_NM == SCHEMA_NM && o.TABLE_NM == TABLE_NM && o.COLUMN_NM == COLUMN_NM));
            db.XCOLUMNDETAIL.Add(XCOLUMNDETAIL);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Updated(XCOLUMNDETAIL);
        }

        private bool XCOLUMNDETAILExists(string DB_NM, string SCHEMA_NM, string TABLE_NM, string COLUMN_NM)
        {
            return db.XCOLUMNDETAIL.Count(XCOLUMNDETAIL => XCOLUMNDETAIL.DB_NM == DB_NM && XCOLUMNDETAIL.SCHEMA_NM == SCHEMA_NM && XCOLUMNDETAIL.TABLE_NM == TABLE_NM && XCOLUMNDETAIL.COLUMN_NM == COLUMN_NM) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
