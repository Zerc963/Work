﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Collections.Generic;
using System.Web;
using System.Data.SqlClient;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XFLOWDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XFLOWDETAIL> Get()
        {
            return db.WWKSPC_XFLOWDETAIL;
        }

        [Queryable]
        public IQueryable<WWKSPC_XFLOWDETAIL> Get([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            if (string.IsNullOrEmpty(DATACAT))
            {
                // 新增的暫存流程，不會存在於 XFLOWDETAIL
                var resultSet = (from s1 in db.WWKSPC_XFLOWDETAIL

                                 where s1.LST_MAINT_USR == LST_MAINT_USR
                                    && !(from s2 in db.XFLOWDETAIL
                                         select s2.DATACAT)
                                        .Contains(s1.DATACAT)

                                 select new
                                 {
                                     DATACAT = s1.DATACAT
                                 });

                if (resultSet.Count() > 0)
                {
                    string d = resultSet.First().DATACAT;
                    return db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == d && o.LST_MAINT_USR == LST_MAINT_USR);
                }
                else
                {
                    List<WWKSPC_XFLOWDETAIL> list = new List<WWKSPC_XFLOWDETAIL>();
                    return list.AsQueryable();
                }
            }
            else
            {
                // 有傳 DATACAT 參數，表示是要載入特定的暫存流程 (編輯暫存)
                return db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
            }
        }

        // POST odata/WWKSPC_XFLOWDETAIL
        public async Task<IHttpActionResult> Post(WWKSPC_XFLOWDETAIL WWKSPC_XFLOWDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            string DATACAT_OLD = string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["DATACAT_OLD"]) ? "" : HttpContext.Current.Request.QueryString["DATACAT_OLD"];

            // 輸入新的DATACAT，沒有載入暫存資料，清空之前的暫存
            if (DATACAT_OLD == "undefined")
            {
                var resultSet = (from s1 in db.WWKSPC_XFLOWDETAIL

                                 where s1.LST_MAINT_USR == WWKSPC_XFLOWDETAIL.LST_MAINT_USR
                                    && !(from s2 in db.XFLOWDETAIL
                                         select s2.DATACAT)
                                        .Contains(s1.DATACAT)

                                 select new
                                 {
                                     DATACAT = s1.DATACAT
                                 }).ToList();

                foreach (var result in resultSet)
                {
                    DeleteAllData(result.DATACAT, WWKSPC_XFLOWDETAIL.LST_MAINT_USR);
                }

                db.WWKSPC_XFLOWDETAIL.Add(WWKSPC_XFLOWDETAIL);

                try
                {
                    await db.SaveChangesAsync();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                var resultSet = (from s1 in db.WWKSPC_XFLOWDETAIL

                                 where s1.LST_MAINT_USR == WWKSPC_XFLOWDETAIL.LST_MAINT_USR
                                    && !(from s2 in db.XFLOWDETAIL
                                         select s2.DATACAT)
                                        .Contains(s1.DATACAT)

                                 select new
                                 {
                                     DATACAT = s1.DATACAT
                                 }).ToList();

                foreach (var result in resultSet)
                {
                    if (result.DATACAT != DATACAT_OLD)
                    {
                        DeleteAllData(result.DATACAT, WWKSPC_XFLOWDETAIL.LST_MAINT_USR);
                    }
                    else
                    {
                        db.WWKSPC_XFLOWDETAIL.RemoveRange(db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == WWKSPC_XFLOWDETAIL.LST_MAINT_USR));
                    }
                }

                db.WWKSPC_XFLOWDETAIL.Add(WWKSPC_XFLOWDETAIL);

                try
                {
                    await db.SaveChangesAsync();

                    if (WWKSPC_XFLOWDETAIL.DATACAT != DATACAT_OLD)
                    {
                        SqlParameter[] SqlParam = new SqlParameter[3];
                        SqlParam[0] = new SqlParameter("@DATACAT", WWKSPC_XFLOWDETAIL.DATACAT);
                        SqlParam[1] = new SqlParameter("@DATACAT_OLD", DATACAT_OLD);
                        SqlParam[2] = new SqlParameter("@LST_MAINT_USR", WWKSPC_XFLOWDETAIL.LST_MAINT_USR);
                        db.Database.ExecuteSqlCommand("WSP_UPD_WWKSPC_XFlowTable @DATACAT,@DATACAT_OLD,@LST_MAINT_USR", SqlParam);
                    }
                }
                catch (DbUpdateException)
                {
                    if (WWKSPC_XFLOWDETAILExists(WWKSPC_XFLOWDETAIL.DATACAT, WWKSPC_XFLOWDETAIL.LST_MAINT_USR))
                    {
                        return Conflict();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            return Created(WWKSPC_XFLOWDETAIL);
        }

        private void DeleteAllData(string DATACAT_OLD, string LST_MAINT_USR)
        {
            db.WWKSPC_XSCHEDULE.RemoveRange(db.WWKSPC_XSCHEDULE.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));
            db.WWKSPC_XLOCALDETAIL.RemoveRange(db.WWKSPC_XLOCALDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));
            db.WWKSPC_XREMOTEDETAIL.RemoveRange(db.WWKSPC_XREMOTEDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));
            db.WWKSPC_XWAITDETAIL.RemoveRange(db.WWKSPC_XWAITDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));

            var tmpFileList2 = db.WWKSPC_XFILEDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR).ToList();
            foreach (WWKSPC_XFILEDETAIL file in tmpFileList2)
            {
                db.WWKSPC_XENCRYPTION.RemoveRange(db.WWKSPC_XENCRYPTION.Where(o => o.SEQ == file.ZIP_PW && o.LST_MAINT_USR == LST_MAINT_USR));
            }
            db.WWKSPC_XFILEDETAIL.RemoveRange(tmpFileList2);
            db.WWKSPC_XFLATFILEDETAIL.RemoveRange(db.WWKSPC_XFLATFILEDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));

            db.WWKSPC_XJOBDETAIL.RemoveRange(db.WWKSPC_XJOBDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));

            db.WWKSPC_XMAILDETAIL.RemoveRange(db.WWKSPC_XMAILDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));
            db.WWKSPC_XMONITOR_FILEWAIT.RemoveRange(db.WWKSPC_XMONITOR_FILEWAIT.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));
            db.WWKSPC_XMONITOR_FLOWTIME.RemoveRange(db.WWKSPC_XMONITOR_FLOWTIME.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));

            db.WWKSPC_XFLOWDETAIL.RemoveRange(db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == DATACAT_OLD && o.LST_MAINT_USR == LST_MAINT_USR));
        }

        // PUT odata/auth_Category(5)
        public async Task<IHttpActionResult> Put([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR, WWKSPC_XFLOWDETAIL WWKSPC_XFLOWDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (LST_MAINT_USR != WWKSPC_XFLOWDETAIL.LST_MAINT_USR)
            {
                return BadRequest();
            }

            db.WWKSPC_XFLOWDETAIL.RemoveRange(db.WWKSPC_XFLOWDETAIL.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR));
            db.WWKSPC_XFLOWDETAIL.Add(WWKSPC_XFLOWDETAIL);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!WWKSPC_XFLOWDETAILExists(DATACAT, LST_MAINT_USR))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(WWKSPC_XFLOWDETAIL);
        }

        private bool WWKSPC_XFLOWDETAILExists(string DATACAT, string LST_MAINT_USR)
        {
            return db.WWKSPC_XFLOWDETAIL.Count(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
