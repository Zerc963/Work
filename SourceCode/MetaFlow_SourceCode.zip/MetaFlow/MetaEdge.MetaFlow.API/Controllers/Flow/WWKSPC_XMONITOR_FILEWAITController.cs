﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System.Data.Entity.Infrastructure;
using System;
using System.Net;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class WWKSPC_XMONITOR_FILEWAITController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<WWKSPC_XMONITOR_FILEWAIT> Get()
        {
            return db.WWKSPC_XMONITOR_FILEWAIT;
        }

        // POST odata/WWKSPC_XMONITOR_FILEWAIT
        public async Task<IHttpActionResult> Post(WWKSPC_XMONITOR_FILEWAIT WWKSPC_XMONITOR_FILEWAIT)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WWKSPC_XMONITOR_FILEWAIT.RemoveRange(db.WWKSPC_XMONITOR_FILEWAIT.Where(o => o.DATACAT == WWKSPC_XMONITOR_FILEWAIT.DATACAT && o.LST_MAINT_USR == WWKSPC_XMONITOR_FILEWAIT.LST_MAINT_USR));
            db.WWKSPC_XMONITOR_FILEWAIT.Add(WWKSPC_XMONITOR_FILEWAIT);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(WWKSPC_XMONITOR_FILEWAIT);
        }

        public async Task<IHttpActionResult> Delete([FromODataUri] string DATACAT, [FromODataUri] string LST_MAINT_USR)
        {
            IQueryable<WWKSPC_XMONITOR_FILEWAIT> deleteItem = db.WWKSPC_XMONITOR_FILEWAIT.Where(o => o.DATACAT == DATACAT && o.LST_MAINT_USR == LST_MAINT_USR);
            db.WWKSPC_XMONITOR_FILEWAIT.RemoveRange(deleteItem);
            await db.SaveChangesAsync();

            return StatusCode(HttpStatusCode.NoContent);
        }
    }
}
