﻿using MetaEdge.ISMD.Entity.Models;
using MetaEdge.MetaAuthWeb.Data.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XFLOWSTATUSHViewController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<XFLOWSTATUSHView> Get([FromODataUri]string DATACAT, [FromODataUri]string BATCH_NO, [FromODataUri]string CYCLE_DATE, [FromODataUri]string RUN_STATUS, [FromODataUri]string START_TIME, [FromODataUri]string END_TIME)
        {
            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            var result = db.Database.SqlQuery<XFLOWSTATUSH>("select * from XFLOWSTATUSH where DATACAT = @DATACAT and BATCH_NO is not NULL;", new SqlParameter("DATACAT", DATACAT)).ToList().ToList();
            //var result = db.XFLOWSTATUSH.Where<XFLOWSTATUSH>(o => o.DATACAT == DATACAT && o.BATCH_NO != null).ToList();

            if (!string.IsNullOrEmpty(BATCH_NO))
            {
                result = result.Where(o => o.BATCH_NO.ToString().Contains(BATCH_NO)).ToList();
            }

            if (!string.IsNullOrEmpty(CYCLE_DATE))
            {
                DateTime cycleDate;
                if (DateTime.TryParse(CYCLE_DATE, out cycleDate))
                {
                    result = result.Where(o => o.CYCLE_END == cycleDate.Date).ToList();
                }
            }

            if (RUN_STATUS != "ALL")
            {
                result = result.Where(o => o.RUN_STATUS.Trim() == RUN_STATUS.Trim()).ToList();
            }

            if (!string.IsNullOrEmpty(START_TIME))
            {
                DateTime startTime;
                if (DateTime.TryParse(START_TIME, out startTime))
                {
                    result = result.Where(o => o.START_TIME >= startTime).ToList();
                }
            }

            if (!string.IsNullOrEmpty(END_TIME))
            {
                DateTime endTime;
                if (DateTime.TryParse(END_TIME, out endTime))
                {
                    result = result.Where(o => o.END_TIME <= endTime).ToList();
                }
            }

            List<XFLOWSTATUSHView> list = new List<XFLOWSTATUSHView>();

            foreach (var fs in result)
            {
                XFLOWSTATUSHView flow = new XFLOWSTATUSHView();
                flow.DATACAT = fs.DATACAT;
                flow.BATCH_NO = fs.BATCH_NO;
                flow.CYCLE_DATE = fs.CYCLE_END;
                flow.RUN_STATUS = fs.RUN_STATUS;

                if (!string.IsNullOrEmpty(fs.RUN_STATUS))
                {
                    var RUN_STATUSNM = parameters.Where(o => o.TypeName == "RUN_STATUS" && o.ParameterValue == fs.RUN_STATUS.Trim()).ToList();
                    if (RUN_STATUSNM.Count() > 0)
                    {
                        flow.RUN_STATUSNM = RUN_STATUSNM.First().ParameterName;
                    }
                }
                flow.START_TIME = fs.START_TIME;
                flow.END_TIME = fs.END_TIME;

                list.Add(flow);
            }

            return list.AsQueryable();
        }        
        

        
    }
}
