﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XWAITSTATUSController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XWAITSTATUS> Get()
        {
            return db.XWAITSTATUS;
        }

        // POST odata/XWAITSTATUS
        public async Task<IHttpActionResult> Post(XWAITSTATUS XWAITSTATUS)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.XWAITSTATUS.Add(XWAITSTATUS);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (XWAITSTATUSExists(XWAITSTATUS.DATACAT, XWAITSTATUS.WAIT_SEQ))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            var new_XWAITSTATUS = db.XWAITSTATUS.Where<XWAITSTATUS>(o => o.DATACAT == XWAITSTATUS.DATACAT && o.WAIT_SEQ == XWAITSTATUS.WAIT_SEQ).First();
            return Created(new_XWAITSTATUS);
        }

        public async Task<IHttpActionResult> Put([FromODataUri] string DATACAT, [FromODataUri] int WAIT_SEQ, XWAITSTATUS XWAITSTATUS)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (DATACAT != XWAITSTATUS.DATACAT || WAIT_SEQ != XWAITSTATUS.WAIT_SEQ)
            {
                return BadRequest();
            }

            db.Entry(XWAITSTATUS).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!XWAITSTATUSExists(DATACAT, WAIT_SEQ))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(XWAITSTATUS);
        }

        private bool XWAITSTATUSExists(string DATACAT, int WAIT_SEQ)
        {
            return db.XWAITSTATUS.Count(XWAITSTATUS => XWAITSTATUS.DATACAT == DATACAT && XWAITSTATUS.WAIT_SEQ == WAIT_SEQ) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }        
    }
}
