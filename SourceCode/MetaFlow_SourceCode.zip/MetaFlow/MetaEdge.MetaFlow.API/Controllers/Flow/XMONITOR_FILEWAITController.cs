﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XMONITOR_FILEWAITController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XMONITOR_FILEWAIT> Get()
        {
            return db.XMONITOR_FILEWAIT;
        }
        
    }
}
