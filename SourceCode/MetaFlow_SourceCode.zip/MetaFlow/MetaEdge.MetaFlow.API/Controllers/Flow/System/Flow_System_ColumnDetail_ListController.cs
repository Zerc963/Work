﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_ColumnDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<Flow_System_ColumnDetail_List> Get()
        {
            var resultSet = (from s1 in db.XCOLUMNDETAIL

                             group s1 by new { s1.DB_NM, s1.SCHEMA_NM, s1.TABLE_NM } into s2

                             select new
                             {
                                 DB_NM = s2.Key.DB_NM
                                 ,
                                 SCHEMA_NM = s2.Key.SCHEMA_NM
                                 ,
                                 TABLE_NM = s2.Key.TABLE_NM
                             });

            List<Flow_System_ColumnDetail_List> list = new List<Flow_System_ColumnDetail_List>();

            foreach (var item in resultSet)
            {
                Flow_System_ColumnDetail_List column = new Flow_System_ColumnDetail_List();
                column.DB_NM = item.DB_NM;
                column.SCHEMA_NM = item.SCHEMA_NM;
                column.TABLE_NM = item.TABLE_NM;

                list.Add(column);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
