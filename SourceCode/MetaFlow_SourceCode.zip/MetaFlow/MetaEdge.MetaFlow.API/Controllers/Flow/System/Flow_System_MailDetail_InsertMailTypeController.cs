﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_MailDetail_InsertMailTypeController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XMAILDETAIL
        public async Task<IHttpActionResult> Post(Flow_System_MailDetail_InsertMailType detail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (XMAILDETAILExists(detail.DATACAT, detail.MAIL_TYPE, detail.MAILADR))
                    {
                        return Conflict();
                    }

                    db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, detail.MAIL_TYPE, detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(detail);
        }

        private bool XMAILDETAILExists(string DATACAT, string MAIL_TYPE, string MAILADR)
        {
            return db.XMAILDETAIL.Count(XMAILDETAIL => XMAILDETAIL.DATACAT == DATACAT && XMAILDETAIL.MAIL_TYPE == MAIL_TYPE && XMAILDETAIL.MAILADR == MAILADR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
