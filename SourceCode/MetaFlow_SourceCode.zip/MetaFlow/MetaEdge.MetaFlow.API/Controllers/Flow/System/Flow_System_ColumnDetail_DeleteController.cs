﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_ColumnDetail_DeleteController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XMAILDETAIL
        public async Task<IHttpActionResult> POST(Flow_System_ColumnDetail_Insert ColunmDetail_Delete)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    foreach (XCOLUMNDETAIL column in ColunmDetail_Delete.Detail)
                    {
                        db.XCOLUMNDETAIL.RemoveRange(db.XCOLUMNDETAIL.Where(o => o.DB_NM == column.DB_NM
                                                                              && o.SCHEMA_NM == column.SCHEMA_NM
                                                                              && o.TABLE_NM == column.TABLE_NM));
                    }

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
