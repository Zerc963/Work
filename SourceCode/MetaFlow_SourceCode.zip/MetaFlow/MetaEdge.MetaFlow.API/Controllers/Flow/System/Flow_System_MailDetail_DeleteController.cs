﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_MailDetail_DeleteController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XMAILDETAIL
        public async Task<IHttpActionResult> Post(Flow_System_MailDetail_Delete list)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    #region [ delete mailDetails ]
                    foreach (Flow_System_MailDetail_DeleteDetail detail in list.Detail)
                    {
                        if (string.IsNullOrEmpty(detail.MAIL_TYPE))
                        {
                            db.Database.ExecuteSqlCommand("delete from dbo.XMAILDETAIL where DATACAT=@DATACAT and MAILADR=@MAILADR;"
                                , new SqlParameter("DATACAT", detail.DATACAT)
                                , new SqlParameter("MAILADR", detail.MAILADR));
                        }
                        else
                        {
                            db.Database.ExecuteSqlCommand("delete from dbo.XMAILDETAIL where DATACAT=@DATACAT and MAIL_TYPE=@MAIL_TYPE and MAILADR=@MAILADR;"
                                , new SqlParameter("DATACAT", detail.DATACAT)
                                , new SqlParameter("MAIL_TYPE", detail.MAIL_TYPE)
                                , new SqlParameter("MAILADR", detail.MAILADR));
                        }
                    }
                    #endregion

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(list);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
