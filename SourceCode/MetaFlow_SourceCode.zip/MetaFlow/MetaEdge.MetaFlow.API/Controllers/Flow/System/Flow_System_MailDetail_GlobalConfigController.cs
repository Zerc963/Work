﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_MailDetail_GlobalConfigController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<Flow_System_MailDetail_GlobalConfig> Get()
        {
            var resultSet = (from s1 in db.XGLOBALCONFIG

                             where s1.GROUP1 == "Mail" && s1.GROUP2 == "Send Mail"

                             group s1 by new { s1.GROUP1, s1.GROUP2 } into s2

                             select new
                             {
                                 SmtpServer = s2.Min(o => o.NAME == "SmtpServer" ? o.VALUE : null)
                                 ,
                                 SmtpPort = s2.Min(o => o.NAME == "SmtpPort" ? o.VALUE : null)
                                 ,
                                 SmtpAccount = s2.Min(o => o.NAME == "SmtpAccount" ? o.VALUE : null)
                                 ,
                                 SmtpPd = s2.Min(o => o.NAME == "SmtpPassword" ? o.VALUE : null)
                                 ,
                                 SmtpEnableSsl = s2.Min(o => o.NAME == "SmtpEnableSsl" ? o.VALUE : null)
                                 ,
                                 MailFromName = s2.Min(o => o.NAME == "MailFromName" ? o.VALUE : null)
                                 ,
                                 MailFrom = s2.Min(o => o.NAME == "MailFrom" ? o.VALUE : null)
                                 ,
                                 MailSubjectPrefix = s2.Min(o => o.NAME == "MailSubjectPrefix" ? o.VALUE : null)
                                 ,
                                 LST_MAINT_USR = s2.Min(o => o.LST_MAINT_USR)
                                 ,
                                 LST_MAINT_DT = s2.Min(o => o.LST_MAINT_DT)
                             }).ToList();

            var resultSet2 = (from s1 in db.XGLOBALCONFIG

                              where s1.GROUP1 == "Notification" && s1.GROUP2 == "Mail" && s1.NAME == "Disable"

                              select new
                              {
                                  Enabled = s1.VALUE == "N"
                              }).ToList();

            List<Flow_System_MailDetail_GlobalConfig> list = new List<Flow_System_MailDetail_GlobalConfig>();

            foreach (var item in resultSet)
            {
                Flow_System_MailDetail_GlobalConfig config = new Flow_System_MailDetail_GlobalConfig();

                if (resultSet2.Count() > 0)
                {
                    config.Enabled = resultSet2.First().Enabled;
                }

                config.SmtpServer = item.SmtpServer;
                config.SmtpPort = item.SmtpPort;
                config.SmtpAccount = item.SmtpAccount;
                config.SmtpPd = item.SmtpPd;
                config.SmtpEnableSsl = item.SmtpEnableSsl;
                config.MailFromName = item.MailFromName;
                config.MailFrom = item.MailFrom;
                config.MailSubjectPrefix = item.MailSubjectPrefix;
                config.LST_MAINT_USR = item.LST_MAINT_USR;
                config.LST_MAINT_DT = item.LST_MAINT_DT;

                list.Add(config);
            }

            return list.AsQueryable();
        }

        public async Task<IHttpActionResult> Post(Flow_System_MailDetail_GlobalConfig XGLOBALCONFIG)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    string oldPd = string.Empty;
                    var result = db.XGLOBALCONFIG.Where(o => (o.GROUP1 == "Mail" && o.GROUP2 == "Send Mail" && o.NAME == "SmtpPassword"));
                    if (result.Count() > 0)
                    {
                        oldPd = result.First().VALUE;
                    }

                    // 刪除既有資料
                    db.XGLOBALCONFIG.RemoveRange(db.XGLOBALCONFIG.Where(o => (o.GROUP1 == "Mail" && o.GROUP2 == "Send Mail")
                                                                           || o.GROUP1 == "Notification" && o.GROUP2 == "Mail" && o.NAME == "Disable"));

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    // 新增 停用電子郵件通知 
                    db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                    {
                        GROUP1 = "Notification",
                        GROUP2 = "Mail",
                        NAME = "Disable",
                        VALUE = XGLOBALCONFIG.Enabled == true ? "N" : "Y",
                        DESC = "停用電子郵件通知",
                        LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                        LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                    });

                    // 新增 SMTP 伺服器
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.SmtpServer))
                    {
                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "SmtpServer",
                            VALUE = XGLOBALCONFIG.SmtpServer,
                            DESC = "SMTP 伺服器",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });
                    }

                    // 新增 SMTP 伺服器連接埠
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.SmtpPort))
                    {
                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "SmtpPort",
                            VALUE = XGLOBALCONFIG.SmtpPort,
                            DESC = "SMTP 伺服器連接埠",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });
                    }

                    // 新增 SMTP 伺服器帳號
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.SmtpAccount))
                    {
                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "SmtpAccount",
                            VALUE = XGLOBALCONFIG.SmtpAccount,
                            DESC = "SMTP 伺服器帳號",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });
                    }

                    // 新增 SMTP 伺服器密碼
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.SmtpPd))
                    {
                        string smtpPd = string.Empty;

                        if (string.IsNullOrEmpty(oldPd))
                        {
                            smtpPd = Guid.NewGuid().ToString().ToLower();
                        }
                        else
                        {
                            smtpPd = oldPd;
                        }

                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "SmtpPassword",
                            VALUE = smtpPd,
                            DESC = "SMTP 伺服器密碼",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });

                        if (string.IsNullOrEmpty(oldPd))
                        {
                            db.XENCRYPTION.Add(new XENCRYPTION
                            {
                                SEQ = smtpPd,
                                VALUE = XGLOBALCONFIG.SmtpPd,
                                LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                                LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                            });
                        }
                        else
                        {
                            var encryptionList = db.XENCRYPTION.SingleOrDefault(o => o.SEQ == oldPd);
                            encryptionList.VALUE = XGLOBALCONFIG.SmtpPd;
                            encryptionList.LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR;
                            encryptionList.LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(oldPd))
                        {
                            // 刪除既有資料
                            db.XENCRYPTION.RemoveRange(db.XENCRYPTION.Where(o => o.SEQ == oldPd));
                        }
                    }

                    // 新增 SSL 開啟
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.SmtpEnableSsl))
                    {
                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "SmtpEnableSsl",
                            VALUE = XGLOBALCONFIG.SmtpEnableSsl,
                            DESC = "SSL 開啟",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });
                    }

                    // 新增 寄件者顯示名稱
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.MailFromName))
                    {
                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "MailFromName",
                            VALUE = XGLOBALCONFIG.MailFromName,
                            DESC = "寄件者顯示名稱",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });
                    }

                    // 新增 寄件者 Email
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.MailFrom))
                    {
                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "MailFrom",
                            VALUE = XGLOBALCONFIG.MailFrom,
                            DESC = "寄件者 Email",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });
                    }

                    // 新增 信件主旨前置字
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.MailSubjectPrefix))
                    {
                        db.XGLOBALCONFIG.Add(new XGLOBALCONFIG
                        {
                            GROUP1 = "Mail",
                            GROUP2 = "Send Mail",
                            NAME = "MailSubjectPrefix",
                            VALUE = XGLOBALCONFIG.MailSubjectPrefix,
                            DESC = "信件主旨前置字",
                            LST_MAINT_USR = XGLOBALCONFIG.LST_MAINT_USR,
                            LST_MAINT_DT = XGLOBALCONFIG.LST_MAINT_DT
                        });
                    }

                    // 新增 測試電子郵件地址
                    if (!string.IsNullOrEmpty(XGLOBALCONFIG.TestMailAddress))
                    {
                        string cmd = @"USP_INS_XMaillist @MailAddress,@MailTitle,@MailBody,NULL";

                        SqlParameter[] SqlParam = new SqlParameter[3];
                        SqlParam[0] = new SqlParameter("@MailAddress", XGLOBALCONFIG.TestMailAddress);
                        SqlParam[1] = new SqlParameter("@MailTitle", "MetaFlow測試");

                        System.Text.StringBuilder sb = new System.Text.StringBuilder();

                        sb.AppendLine(@"<style type=""text/css"">
                                            body {
                                                font-family: Microsoft JhengHei, Arial, Verdana;
                                                font-size: 12px;
                                            }

                                            table {
                                                font-family: Microsoft JhengHei, Arial, Verdana;
                                                font-size: 12px;
                                            }

                                            table tr td {
                                                height: 16px;
                                                padding : 10px 10px 10px 10px;
                                            }

                                        </style>");

                        sb.Append("<body>MetaFlow測試");
                        sb.Append("<table cellpadding=\"0\" cellspacing=\"0\">");
                        sb.Append("<tbody>");
                        sb.Append("<tr>");
                        sb.Append("<td align=\"right\" style=\"width:100px; border: 1px solid #dddddd;\">測試人員");
                        sb.Append("</td>");
                        sb.Append("<td style=\"width:150px;border-top: 1px solid #dddddd;border-right: 1px solid #dddddd;border-bottom: 1px solid #dddddd;\">");
                        sb.Append(XGLOBALCONFIG.LST_MAINT_USR);
                        sb.Append("</td>");
                        sb.Append("</tr>");
                        sb.Append("<tr>");
                        sb.Append("<td align=\"right\" style=\"border-left: 1px solid #dddddd;border-right: 1px solid #dddddd;border-bottom: 1px solid #dddddd;\">測試時間");
                        sb.Append("</td>");
                        sb.Append("<td style=\"border-right: 1px solid #dddddd;border-bottom: 1px solid #dddddd;\">");
                        sb.Append(string.Format("{0:yyyy/MM/dd HH:mm:ss}", XGLOBALCONFIG.LST_MAINT_DT));
                        sb.Append("</td>");
                        sb.Append("</tr>");
                        sb.Append("</table>");

                        SqlParam[2] = new SqlParameter("@MailBody", sb.ToString());

                        db.Database.ExecuteSqlCommand(cmd, SqlParam);
                    }

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(XGLOBALCONFIG);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
