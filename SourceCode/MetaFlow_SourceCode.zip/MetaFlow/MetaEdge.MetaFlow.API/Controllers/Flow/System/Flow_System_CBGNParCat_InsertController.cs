﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using MetaEdge.Security.Data.Models;
using Newtonsoft.Json.Linq;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_CBGNParCat_InsertController : ODataController
    {
        private MetaFlow_UserDBContext dbUser = new MetaFlow_UserDBContext();

        // POST odata/XMAILDETAIL
        public async Task<IHttpActionResult> Post(CB_GN_ParCat_Insert parcat_Insert)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = dbUser.Database.BeginTransaction())
            {
                try
                {
                    JObject jo = JObject.Parse(Newtonsoft.Json.JsonConvert.SerializeObject(parcat_Insert));
                    jo.Remove("Detail");

                    CB_GN_ParCat CB_GN_ParCat = jo.ToObject<CB_GN_ParCat>();
                    dbUser.CB_GN_ParCat.Add(CB_GN_ParCat);

                    foreach (CB_GN_ParCat_DTL CB_GN_ParCat_DTL in parcat_Insert.Detail)
                    {
                        CB_GN_ParCat_DTL.LST_MAINT_USR = parcat_Insert.LST_MAINT_USR;
                        CB_GN_ParCat_DTL.LST_MAINT_DT = parcat_Insert.LST_MAINT_DT;
                        dbUser.CB_GN_ParCat_DTL.Add(CB_GN_ParCat_DTL);
                    }

                    try
                    {
                        await dbUser.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(parcat_Insert);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                dbUser.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
