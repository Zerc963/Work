﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.IO;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Configuration;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_ParameterImport_InsertController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/Flow_System_ParameterImport_Insert
        public async Task<IHttpActionResult> Post(Flow_System_ParameterImport_Insert importData)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                // convert string to stream
                byte[] byteArray = Convert.FromBase64String(importData.FileContent);
                Stream fStrem = new MemoryStream(byteArray);

                //開啟EXCEL檔
                SpreadsheetGear.IWorkbook IWbook = SpreadsheetGear.Factory.GetWorkbookSet().Workbooks.OpenFromStream(fStrem);
                SpreadsheetGear.IWorksheet IWsheet = IWbook.Worksheets[0];

                //重設Execl UsesRange值(從A2開始) 
                string ExcelUsedRange = "$A$2" + IWsheet.UsedRange.Address.Substring(IWsheet.UsedRange.Address.IndexOf(":"));
                DataTable dt = IWsheet.Cells[ExcelUsedRange].GetDataTable(SpreadsheetGear.Data.GetDataFlags.NoColumnHeaders);

                //例外處理
                //將Not Null、無資料的內容改成空白
                //==================================================================
                List<bool> columnNullableList = db.Database.SqlQuery<bool>("SELECT is_nullable FROM sys.columns WHERE object_id in (select object_id from sys.objects where name = @ImportType) order by column_id", new SqlParameter("ImportType", importData.ImportType)).ToList();

                int rowIndex = 0;
                foreach (DataRow dr in dt.Rows)
                {
                    rowIndex++;

                    try
                    {
                        for (int i = 0; i < dt.Columns.Count; i++)
                        {
                            if (string.IsNullOrEmpty(dr["Column" + (i + 1)].ToString()) && columnNullableList[i] == false)
                            {
                                dr["Column" + (i + 1)] = "";
                            }
                        }
                    }
                    catch (Exception)
                    {
                        throw new Exception("importError:" + rowIndex.ToString());
                    }
                }
                //==================================================================

                List<string> columnList = db.Database.SqlQuery<string>("SELECT name FROM sys.columns WHERE object_id in (select object_id from sys.objects where name = @ImportType) order by column_id", new SqlParameter("ImportType", importData.ImportType)).ToList();

                string connectionString = MetaEdge.Registry.ConnectionFactory.Get("ISMD");

                SqlConnection conn = new SqlConnection(connectionString + "Column Encryption Setting=enabled");
                conn.Open();

                using (SqlTransaction transaction = conn.BeginTransaction())
                {
                    //匯入時,是否清空資料表
                    if (importData.DeleteImport)
                    {
                        SqlCommand sqlCmd = new SqlCommand(string.Format("delete from dbo.{0};", importData.ImportType), conn, transaction);
                        importData.DeleteCount = sqlCmd.ExecuteNonQuery();
                    }

                    using (SqlBulkCopy sqlBC = new SqlBulkCopy(conn, SqlBulkCopyOptions.Default, transaction))
                    {
                        //設定一個批次量寫入多少筆資料
                        sqlBC.BatchSize = 1000;

                        //設定逾時的秒數
                        sqlBC.BulkCopyTimeout = 120;

                        //設定要寫入的資料表
                        sqlBC.DestinationTableName = "dbo." + importData.ImportType;

                        int index = 0;
                        foreach (string columnName in columnList)
                        {
                            index++;
                            sqlBC.ColumnMappings.Add("Column" + index, columnName);
                        }

                        //開始寫入
                        sqlBC.WriteToServer(dt);

                        try
                        {
                            transaction.Commit();
                            importData.InsertCount = dt.Rows.Count;
                        }
                        catch (Exception)
                        {
                            transaction.Rollback();
                            throw;
                        }
                    }
                }
                conn.Dispose();
            }
            catch (DbUpdateException)
            {
                throw;
            }
            catch (Exception ex)
            {
                if (ex.Message.IndexOf("importError:") == 0)
                {
                    throw new Exception(string.Format("第 {0} 行的資料匯入失敗.", ex.Message.Split(':')[1]));
                }
                else
                {
                    throw ex;
                }
            }

            return Created(importData);
        }
    }
}
