﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System;
using System.Data.Entity.Infrastructure;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_ServerDetail_InsertController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/Flow_System_ServerDetail_Insert
        public async Task<IHttpActionResult> Post(Flow_System_ServerDetail_Insert List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    XENCRYPTION Encryption = new XENCRYPTION();
                    Encryption.SEQ = List.PW_SEQ;
                    Encryption.VALUE = List.PW;
                    Encryption.LST_MAINT_DT = List.LST_MAINT_DT;
                    Encryption.LST_MAINT_USR = List.LST_MAINT_USR;
                    db.XENCRYPTION.Add(Encryption);
                    
                    XSERVERDETAIL ServerDetail = new XSERVERDETAIL();
                    ServerDetail.SERVERTYPE = List.SERVERTYPE;
                    ServerDetail.SERVERNM = List.SERVERNM;
                    ServerDetail.USERCODE = List.USERCODE;
                    ServerDetail.PW = List.PW_SEQ;
                    ServerDetail.PORT = List.PORT;
                    ServerDetail.LST_MAINT_USR = List.LST_MAINT_USR;
                    ServerDetail.LST_MAINT_DT = List.LST_MAINT_DT;
                    db.XSERVERDETAIL.Add(ServerDetail);

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        if (XSERVERDETAILExists(List.SERVERTYPE, List.SERVERNM, List.USERCODE))
                        {
                            dbTransaction.Rollback();
                            return Conflict();
                        }
                        if (XENCRYPTIONExists(List.PW_SEQ))
                        {
                            dbTransaction.Rollback();
                            return Conflict();
                        }
                        else
                        {
                            dbTransaction.Rollback();
                            throw;
                        }
                    }
                    catch (Exception ex)
                    {
                        dbTransaction.Rollback();
                        throw ex;
                    }
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                dbTransaction.Commit();
            }
            return Created(List);
        }
        
        private bool XSERVERDETAILExists(string SERVERTYPE, string SERVERNM, string USERCODE)
        {
            return db.XSERVERDETAIL.Count(XSERVERDETAIL => XSERVERDETAIL.SERVERTYPE == SERVERTYPE && XSERVERDETAIL.SERVERNM == SERVERNM && XSERVERDETAIL.USERCODE == USERCODE) > 0;
        }

        private bool XENCRYPTIONExists(string SEQ)
        {
            return db.XENCRYPTION.Count(XENCRYPTION => XENCRYPTION.SEQ == SEQ) > 0;
        }
    }
}
