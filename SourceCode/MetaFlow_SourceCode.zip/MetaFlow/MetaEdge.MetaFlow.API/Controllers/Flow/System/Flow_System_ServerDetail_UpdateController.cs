﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_ServerDetail_UpdateController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XSERVERDETAIL_Update
        public async Task<IHttpActionResult> Put([FromODataUri] string SERVERTYPE, [FromODataUri] string SERVERNM, [FromODataUri] string USERCODE, Flow_System_ServerDetail_Update List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (SERVERTYPE != List.SERVERTYPE || SERVERNM != List.SERVERNM || USERCODE != List.USERCODE)
            {
                return BadRequest();
            }
            else
            {
                var xserverdetailList = db.XSERVERDETAIL.SingleOrDefault(o => o.SERVERTYPE == SERVERTYPE && o.SERVERNM == SERVERNM && o.USERCODE == USERCODE);
                xserverdetailList.PORT = List.PORT;
                xserverdetailList.LST_MAINT_USR = List.LST_MAINT_USR;
                xserverdetailList.LST_MAINT_DT = List.LST_MAINT_DT;
            }

            if (!string.IsNullOrEmpty(List.PW_SEQ) && List.PWChangeFG)
            {
                // 查詢修改前資料
                var encryptionList = db.XENCRYPTION.SingleOrDefault(o => o.SEQ == List.PW_SEQ);
                encryptionList.VALUE = List.PW;
                encryptionList.LST_MAINT_USR = List.LST_MAINT_USR;
                encryptionList.LST_MAINT_DT = List.LST_MAINT_DT;
            }
            
            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (XSERVERDETAILExists(List.SERVERTYPE, List.SERVERNM, List.USERCODE))
                {
                    return Conflict();
                }
                if (XENCRYPTIONExists(List.PW_SEQ))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return Updated(List);
        }

        private bool XSERVERDETAILExists(string SERVERTYPE, string SERVERNM, string USERCODE)
        {
            return db.XSERVERDETAIL.Count(XSERVERDETAIL => XSERVERDETAIL.SERVERTYPE == SERVERTYPE && XSERVERDETAIL.SERVERNM == SERVERNM && XSERVERDETAIL.USERCODE == USERCODE) > 0;
        }

        private bool XENCRYPTIONExists(string SEQ)
        {
            return db.XENCRYPTION.Count(XENCRYPTION => XENCRYPTION.SEQ == SEQ) > 0;
        }
    }
}
