﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_JobItem_DeleteController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        public async Task<IHttpActionResult> Post(Flow_System_JobItem_Delete deleteList)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (WJOBITEM_PrimaryKey deletePrimaryKey in deleteList.DeleteDetail)
                {
                    db.WJOBITEM.RemoveRange(db.WJOBITEM.Where(o => o.JOB_LOCATION == deletePrimaryKey.JOB_LOCATION 
                                                                   && o.JOB_NAME == deletePrimaryKey.JOB_NAME 
                                                                   && o.JOB_OWNER == deletePrimaryKey.JOB_OWNER
                                                                   && o.JOB_TYPE == deletePrimaryKey.JOB_TYPE
                                                             ));
                }
                try
                {
                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(deleteList);
            }
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
