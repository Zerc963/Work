﻿using MetaEdge.ISMD.Entity.Models;
using System;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_JobItem_ListUpdateController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        public async Task<IHttpActionResult> Put([FromODataUri] string DISABLE_FG, Flow_System_JobItem_ListUpdate List)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                foreach (WJOBITEM_PrimaryKey itemPrimaryKey in List.Detail)
                {
                    WJOBITEM findItem = db.WJOBITEM.Find(itemPrimaryKey.JOB_NAME, itemPrimaryKey.JOB_TYPE, itemPrimaryKey.JOB_LOCATION, itemPrimaryKey.JOB_OWNER);
                    findItem.DISABLE_FG = DISABLE_FG;
                    //db.WJOBITEM.RemoveRange(db.WJOBITEM.Where(o => o.JOB_TYPE == deletePrimaryKey.JOB_TYPE && o.JOB_NAME == deletePrimaryKey.JOB_NAME && o.JOB_OWNER == deletePrimaryKey.JOB_OWNER && o.JOB_LOCATION == deletePrimaryKey.JOB_LOCATION));
                }
                try
                {
                    await db.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Created(List);
            }
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
