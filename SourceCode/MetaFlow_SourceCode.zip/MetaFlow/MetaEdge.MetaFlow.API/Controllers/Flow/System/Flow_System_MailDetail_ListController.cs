﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_MailDetail_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XMAILDETAIL_List_Data> Get([FromODataUri]string DATACAT)
        {
            var resultSet = (from s1 in db.XMAILDETAIL

                             where s1.DATACAT == DATACAT
                             group s1 by new { s1.DATACAT, s1.MAILADR, s1.MAIL_DESC } into s2

                             select new
                             {
                                 DATACAT = s2.Key.DATACAT
                                 ,
                                 MAILADR = s2.Key.MAILADR
                                 ,
                                 MAIL_DESC = s2.Key.MAIL_DESC
                                 ,
                                 notifyRUNOK_fg = (s2.Sum(o => o.MAIL_TYPE == "RUNOK" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyABORT_fg = (s2.Sum(o => o.MAIL_TYPE == "ABORT" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyCHECK_FILE_REPORT_fg = (s2.Sum(o => o.MAIL_TYPE == "CHECK FILE REPORT" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyFLOW_REPORT_fg = (s2.Sum(o => o.MAIL_TYPE == "FLOW REPORT" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyMONITOR_FILE_WAIT_fg = (s2.Sum(o => o.MAIL_TYPE == "MONITOR FILE WAIT" ? 1 : 0)) > 0 ? true : false
                                 ,
                                 notifyMONITOR_FLOW_TIME_fg = (s2.Sum(o => o.MAIL_TYPE == "MONITOR FLOW TIME" ? 1 : 0)) > 0 ? true : false
                                 //,
                                 //LST_MAINT_USR = s2.Min(o => o.LST_MAINT_USR)
                                 //,
                                 //LST_MAINT_DT = s2.Min(o => o.LST_MAINT_DT)
                             });

            List<XMAILDETAIL_List_Data> list = new List<XMAILDETAIL_List_Data>();

            foreach (var item in resultSet)
            {
                XMAILDETAIL_List_Data mail = new XMAILDETAIL_List_Data();
                mail.DATACAT = item.DATACAT;
                mail.MAILADR = item.MAILADR;
                mail.MAIL_DESC = item.MAIL_DESC;
                mail.notifyRUNOK_fg = item.notifyRUNOK_fg;
                mail.notifyABORT_fg = item.notifyABORT_fg;
                mail.notifyCHECK_FILE_REPORT_fg = item.notifyCHECK_FILE_REPORT_fg;
                mail.notifyFLOW_REPORT_fg = item.notifyFLOW_REPORT_fg;
                mail.notifyMONITOR_FILE_WAIT_fg = item.notifyMONITOR_FILE_WAIT_fg;
                mail.notifyMONITOR_FLOW_TIME_fg = item.notifyMONITOR_FLOW_TIME_fg;
                //mail.LST_MAINT_USR = item.LST_MAINT_USR;
                //mail.LST_MAINT_DT = item.LST_MAINT_DT;

                list.Add(mail);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
