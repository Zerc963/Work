﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_MailDetail_UpdateController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XMAILDETAIL
        public async Task<IHttpActionResult> Post(Flow_System_MailDetail_Update detail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (detail.MAILADR != detail.Old_MAILADR)
                    {
                        if (XMAILDETAILExists(detail.DATACAT, detail.MAILADR))
                        {
                            return Conflict();
                        }
                    }

                    #region [ delete mailDetails ]
                    db.Database.ExecuteSqlCommand("delete from dbo.XMAILDETAIL where DATACAT=@DATACAT and MAILADR=@MAILADR;"
                        , new SqlParameter("DATACAT", detail.DATACAT)
                        , new SqlParameter("MAILADR", detail.Old_MAILADR));
                    #endregion

                    if (detail.notifyRUNOK_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "RUNOK", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                    }

                    if (detail.notifyABORT_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "ABORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                    }

                    if (detail.notifyCHECK_FILE_REPORT_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "CHECK FILE REPORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                    }

                    if (detail.notifyFLOW_REPORT_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "FLOW REPORT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                    }

                    if (detail.notifyMONITOR_FILE_WAIT_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "MONITOR FILE WAIT", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                    }

                    if (detail.notifyMONITOR_FLOW_TIME_fg)
                    {
                        db.XMAILDETAIL.Add(new XMAILDETAIL(detail.DATACAT, "MONITOR FLOW TIME", detail.MAILADR, detail.MAIL_DESC, detail.LST_MAINT_USR, detail.LST_MAINT_DT));
                    }

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(detail);
        }

        private bool XMAILDETAILExists(string DATACAT, string MAILADR)
        {
            return db.XMAILDETAIL.Count(XMAILDETAIL => XMAILDETAIL.DATACAT == DATACAT && XMAILDETAIL.MAILADR == MAILADR) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
