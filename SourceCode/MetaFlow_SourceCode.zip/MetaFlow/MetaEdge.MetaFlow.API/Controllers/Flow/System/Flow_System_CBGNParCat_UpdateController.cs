﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using MetaEdge.Security.Data.Models;
using Newtonsoft.Json.Linq;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_CBGNParCat_UpdateController : ODataController
    {
        private MetaFlow_UserDBContext dbUser = new MetaFlow_UserDBContext();

        public async Task<IHttpActionResult> Put([FromODataUri] int Cat_SeqNo, CB_GN_ParCat_Update updateItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (Cat_SeqNo != updateItem.Cat_SeqNo)
            {
                return BadRequest();
            }

            using (var dbTransaction = dbUser.Database.BeginTransaction())
            {
                JObject jo = JObject.Parse(Newtonsoft.Json.JsonConvert.SerializeObject(updateItem));
                jo.Remove("DeleteKeys");
                jo.Remove("InsertDetail");

                CB_GN_ParCat CB_GN_ParCat = jo.ToObject<CB_GN_ParCat>();
                dbUser.Entry(CB_GN_ParCat).State = EntityState.Modified;

                #region[delete CB_GN_ParCat_DTLs]
                string[] id = updateItem.DeleteKeys.Split(';');
                foreach (string r in id)
                {
                    if (!string.IsNullOrEmpty(r))
                    {
                        int rid = 0;
                        if (int.TryParse(r, out rid))
                        {
                            CB_GN_ParCat_DTL parcatdtl = dbUser.CB_GN_ParCat_DTL.Where<CB_GN_ParCat_DTL>(o => o.Cat_Dtl_Cd_SeqNo == rid).First();
                            dbUser.CB_GN_ParCat_DTL.Remove(parcatdtl);
                        }
                    }
                }
                #endregion

                #region[add CB_GN_ParCat_DTLs]
                foreach (CB_GN_ParCat_DTL parcatdtl in updateItem.InsertDetail)
                {
                    dbUser.CB_GN_ParCat_DTL.Add(parcatdtl);
                    await dbUser.SaveChangesAsync();
                }
                #endregion

                try
                {
                    await dbUser.SaveChangesAsync();
                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }

                return Updated(updateItem);
            }
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                dbUser.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
