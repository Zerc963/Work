﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_ColumnDetail_InsertController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/XMAILDETAIL
        public async Task<IHttpActionResult> Post(Flow_System_ColumnDetail_Insert ColunmDetail_Insert)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            using (var dbTransaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (ColunmDetail_Insert.Detail.Count > 0)
                    {
                        string databaseName = ColunmDetail_Insert.Detail[0].DB_NM;
                        string schemaName = ColunmDetail_Insert.Detail[0].SCHEMA_NM;
                        string tableName = ColunmDetail_Insert.Detail[0].TABLE_NM;

                        db.XCOLUMNDETAIL.RemoveRange(db.XCOLUMNDETAIL.Where(o => o.DB_NM == databaseName
                                                                    && o.SCHEMA_NM == schemaName
                                                                    && o.TABLE_NM == tableName));
                    }

                    foreach (XCOLUMNDETAIL column in ColunmDetail_Insert.Detail)
                    {
                        db.XCOLUMNDETAIL.Add(column);
                    }

                    try
                    {
                        await db.SaveChangesAsync();
                    }
                    catch (DbUpdateException)
                    {
                        throw;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                    dbTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbTransaction.Rollback();
                    throw ex;
                }
            }

            return Created(ColunmDetail_Insert);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
