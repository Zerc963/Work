﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Threading.Tasks;
using System;
using System.Data.Entity.Infrastructure;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_ServerDetail_DeleteController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        // POST odata/Flow_System_ServerDetail_Insert
        public async Task<IHttpActionResult> Post(Flow_System_ServerDetail_Delete DeleteDetailList)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            foreach (Flow_System_ServerDetail_DeleteDetail DelDetail in DeleteDetailList.DeleteDetail)
            {
                /* 查詢該筆資料ID是否已存在 */
                var ServerDetailResult = db.XSERVERDETAIL.SingleOrDefault(b => b.SERVERTYPE == DelDetail.SERVERTYPE && b.SERVERNM == DelDetail.SERVERNM && b.USERCODE == DelDetail.USERCODE);

                /* 若存在就舊資料刪除 */
                if (ServerDetailResult != null)
                    db.XSERVERDETAIL.Remove(ServerDetailResult);

                /* 查詢該SERVER的密碼是否存在 */
                var EncryptionResult = db.XENCRYPTION.SingleOrDefault(b => b.SEQ == ServerDetailResult.PW);

                /* 若存在將舊資料刪除 */
                if (EncryptionResult != null)
                    db.XENCRYPTION.Remove(EncryptionResult);
            }

            await db.SaveChangesAsync();
            return Created(DeleteDetailList);
        }
        
    }
}
