﻿using MetaEdge.Data;
using MetaEdge.ISMD.Entity.Models;
using MetaEdge.MetaAuthWeb.Data.Models;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_JobItem_ListController : ODataController
    {
        private ISMDContext db = new ISMDContext();
        private MetaAuthWebContext dbMetaAuthWeb = new MetaAuthWebContext();

        [Queryable]
        public IQueryable<Flow_System_JobItem_List> Get()
        {
            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            var resultSet = db.WJOBITEM;

            List<Flow_System_JobItem_List> list = new List<Flow_System_JobItem_List>();

            foreach (var item in resultSet)
            {
                Flow_System_JobItem_List job = new Flow_System_JobItem_List();

                var JOB_TYPE_Nm = parameters.Where(o => o.TypeName == "JOB_TYPE" && o.ParameterValue == item.JOB_TYPE.Trim()).ToList();
                if (JOB_TYPE_Nm.Count() > 0)
                {
                    job.JOB_TYPE_Nm = JOB_TYPE_Nm.First().ParameterName;
                }

                job.JOB_NAME = item.JOB_NAME;
                job.JOB_TYPE = item.JOB_TYPE;
                job.JOB_TYPE_Nm = item.TOOL_FG == "Y" ? "公用程式" : job.JOB_TYPE_Nm;
                job.JOB_LOCATION = item.JOB_LOCATION;
                job.JOB_OWNER = item.JOB_OWNER;
                job.TOOL_FG = item.TOOL_FG;
                job.MANUAL_FG = item.MANUAL_FG;
                job.DISABLE_FG = item.DISABLE_FG;
                job.DISABLE_FG_Nm = (item.DISABLE_FG == "N") ? "顯示" : "隱藏";
                job.JOB_DESC = item.JOB_DESC;

                list.Add(job);
            }

            return list.AsQueryable();
        }

        [Queryable]
        public IQueryable<Flow_System_JobItem_List> Get([FromODataUri]string DISABLE_FG)
        {
            var parameters = dbMetaAuthWeb.sys_Parameters.ToList();

            var resultSet = db.WJOBITEM.Where(o => DISABLE_FG == "ALL" || o.DISABLE_FG == DISABLE_FG);

            List<Flow_System_JobItem_List> list = new List<Flow_System_JobItem_List>();

            foreach (var item in resultSet)
            {
                Flow_System_JobItem_List job = new Flow_System_JobItem_List();

                var JOB_TYPE_Nm = parameters.Where(o => o.TypeName == "JOB_TYPE" && o.ParameterValue == item.JOB_TYPE.Trim()).ToList();
                if (JOB_TYPE_Nm.Count() > 0)
                {
                    job.JOB_TYPE_Nm = JOB_TYPE_Nm.First().ParameterName;
                }

                job.JOB_NAME = item.JOB_NAME;
                job.JOB_TYPE = item.JOB_TYPE;
                job.JOB_TYPE_Nm = item.TOOL_FG == "Y" ? "公用程式" : job.JOB_TYPE_Nm;
                job.JOB_LOCATION = item.JOB_LOCATION;
                job.JOB_OWNER = item.JOB_OWNER;
                job.TOOL_FG = item.TOOL_FG;
                job.MANUAL_FG = item.MANUAL_FG;
                job.DISABLE_FG = item.DISABLE_FG;
                job.DISABLE_FG_Nm = (item.DISABLE_FG == "N") ? "顯示" : "隱藏";
                job.JOB_DESC = item.JOB_DESC;

                list.Add(job);
            }

            return list.AsQueryable();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
