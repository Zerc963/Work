﻿using MetaEdge.ISMD.Entity.Models;
using Newtonsoft.Json.Linq;
using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class Flow_System_JobItem_UpdateController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        public async Task<IHttpActionResult> Post(Flow_System_JobItem_Update updateItem)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.WJOBITEM.RemoveRange(db.WJOBITEM.Where(o => o.JOB_NAME == updateItem.OldPrimaryKeys.JOB_NAME
                                                           && o.JOB_TYPE == updateItem.OldPrimaryKeys.JOB_TYPE
                                                           && o.JOB_LOCATION == updateItem.OldPrimaryKeys.JOB_LOCATION
                                                           && o.JOB_OWNER == updateItem.OldPrimaryKeys.JOB_OWNER));

            JObject jo = JObject.Parse(Newtonsoft.Json.JsonConvert.SerializeObject(updateItem));
            jo.Remove("OldPrimaryKeys");
            WJOBITEM WJOBITEM = jo.ToObject<WJOBITEM>();
            db.WJOBITEM.Add(WJOBITEM);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (WJOBITEMExists(WJOBITEM.JOB_NAME, WJOBITEM.JOB_TYPE, WJOBITEM.JOB_LOCATION, WJOBITEM.JOB_OWNER))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Created(updateItem);
        }

        private bool WJOBITEMExists(string JOB_NAME, string JOB_TYPE, string JOB_LOCATION, string JOB_OWNER)
        {
            return db.WJOBITEM.Count(o => o.JOB_NAME == JOB_NAME && o.JOB_TYPE == JOB_TYPE && o.JOB_LOCATION == JOB_LOCATION && o.JOB_OWNER == JOB_OWNER) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
