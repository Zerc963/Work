﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.ModelBinding;
using System.Web.Http.OData;
using MetaEdge.ISMD.Entity.Models;
using System.Data.Entity;

namespace MetaEdge.MetaFlow.API.Controllers
{
    public class XFLOWDETAILController : ODataController
    {
        private ISMDContext db = new ISMDContext();

        [Queryable]
        public IQueryable<XFLOWDETAIL> Get()
        {
            return db.XFLOWDETAIL;
        }

        // POST odata/XFLOWDETAIL
        public async Task<IHttpActionResult> Post(XFLOWDETAIL XFLOWDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.XFLOWDETAIL.Add(XFLOWDETAIL);

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (XFLOWDETAILExists(XFLOWDETAIL.DATACAT))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            var new_XFLOWDETAIL = db.XFLOWDETAIL.Where<XFLOWDETAIL>(o => o.DATACAT == XFLOWDETAIL.DATACAT).First();
            return Created(new_XFLOWDETAIL);
        }

        // PUT odata/auth_Category(5)
        public async Task<IHttpActionResult> Put([FromODataUri] string DATACAT, XFLOWDETAIL XFLOWDETAIL)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (DATACAT != XFLOWDETAIL.DATACAT)
            {
                return BadRequest();
            }

            XFLOWDETAIL.LST_MAINT_DT = DateTime.Now;
            db.Entry(XFLOWDETAIL).State = EntityState.Modified;

            try
            {
                await db.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!XFLOWDETAILExists(DATACAT))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return Updated(XFLOWDETAIL);
        }

        private bool XFLOWDETAILExists(string DATACAT)
        {
            return db.XFLOWDETAIL.Count(XFLOWDETAIL => XFLOWDETAIL.DATACAT == DATACAT) > 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
