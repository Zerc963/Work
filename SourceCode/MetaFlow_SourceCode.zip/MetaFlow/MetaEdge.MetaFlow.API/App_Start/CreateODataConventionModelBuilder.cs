﻿using MetaEdge.ISMD.Entity.Models;
using System.Web.Http.OData.Builder;
using System.Collections.Generic;


namespace MetaEdge.MetaFlow.API
{
    public partial class WebApiConfig
    {
        private static ODataConventionModelBuilder CreateODataConventionModelBuilder()
        {
            ODataConventionModelBuilder builder = new ODataConventionModelBuilder();

            defineISMD(ref builder);

            return builder;
        }

        //private static void defineUserDB(ref ODataConventionModelBuilder builder)
        //{
        //    #region [MetaFlow_UserDB]
        //    builder.EntitySet<AP_SYS_AUDIT_LOG>("AP_SYS_AUDIT_LOG");
        //    builder.EntitySet<auth_Functions>("auth_Functions");
        //    builder.EntitySet<auth_FunctionsInPages>("auth_FunctionsInPages");
        //    builder.EntitySet<auth_Pages>("securityModule"); // securityModule
        //    builder.EntitySet<auth_Pages>("securityPath");
        //    builder.EntitySet<securityCommand>("securityCommand");
        //    builder.EntitySet<auth_Pages>("getActionName");
        //    builder.EntitySet<log_Logon>("log_Logon");
        //    builder.EntitySet<log_Operation>("log_Operation");
        //    builder.EntitySet<log_ScriptError>("log_ScriptError");
        //    builder.EntitySet<SSORequest>("SSORequest");
        //    builder.EntitySet<SSOResponse>("SSOResponse");

        //    builder.EntitySet<usp_Qry_getSequence>("usp_Qry_getSequence");
        //    builder.EntitySet<auth_Functions>("auth_FunctionsView");

        //    // Category
        //    // ============================================================
        //    builder.EntitySet<auth_Category>("auth_Category");
        //    // ============================================================

        //    // Pages
        //    // ============================================================
        //    builder.EntitySet<auth_Pages>("auth_Pages");
        //    builder.EntitySet<auth_PagesInRoles>("auth_PagesInRoles");
        //    builder.EntitySet<auth_PagesInRolesView>("auth_PagesInRolesView");
        //    // ============================================================

        //    // Groups
        //    // ============================================================
        //    builder.EntitySet<auth_Groups>("auth_Groups");
        //    builder.EntitySet<auth_GroupsInRoles>("auth_GroupsInRoles");
        //    builder.EntitySet<auth_GroupsInRolesView>("auth_GroupsInRolesView");
        //    builder.EntitySet<auth_GroupsInRolesView>("auth_GroupsNotInRolesView");
        //    // ============================================================

        //    // Roles
        //    // ============================================================
        //    builder.EntitySet<auth_Roles>("auth_Roles");
        //    // ============================================================

        //    // Users
        //    // ============================================================
        //    builder.EntitySet<auth_Users>("auth_Users");
        //    builder.EntitySet<auth_Users>("auth_Users2");
        //    builder.EntitySet<auth_UsersInGroups>("auth_UsersInGroups");
        //    builder.EntitySet<auth_UsersInGroupsView>("auth_UsersInGroupsView");
        //    builder.EntitySet<auth_UsersInGroupsView>("auth_UsersNotInGroupsView");
        //    builder.EntitySet<auth_UsersInRoles>("auth_UsersInRoles");
        //    builder.EntitySet<auth_UsersInRolesView>("auth_UsersInRolesView");
        //    builder.EntitySet<auth_UsersInRolesView>("auth_UsersNotInRolesView");
        //    // ============================================================

        //    // Approve
        //    // ============================================================
        //    builder.EntitySet<sec_ApproveListH>("sec_ApproveListH");
        //    builder.EntitySet<sec_ApprovePoolH>("sec_ApprovePoolH");
        //    builder.EntitySet<sec_ApproveSetting>("sec_ApproveSetting");
        //    builder.EntitySet<sec_ApproveList>("sec_ApproveList");
        //    builder.EntitySet<sec_ApprovePool>("sec_ApprovePool");
        //    builder.EntitySet<sec_ApproveMapping>("sec_ApproveMapping");
        //    builder.EntitySet<usp_Web_ApproveList>("usp_Web_ApproveList");

        //    builder.EntitySet<sec_ApproveStep>("sec_ApproveStep");
        //    builder.EntitySet<sec_ApproveStepOwner>("sec_ApproveStepOwner");
        //    builder.EntitySet<sec_ApproveStepProcess>("sec_ApproveStepProcess");
        //    builder.EntitySet<sec_ApproveStepProcessH>("sec_ApproveStepProcessH");
        //    builder.EntitySet<sec_ApproveListWithStep>("sec_ApproveListWithStep");
        //    builder.EntitySet<sec_ApproveStepProcessView>("sec_ApproveStepProcessView");
        //    // ============================================================

        //    // AffiliateInCategory
        //    // ============================================================
        //    builder.EntitySet<auth_AffiliateInCategory>("auth_AffiliateInCategory");
        //    builder.EntitySet<auth_AffiliateInCategoryView>("auth_AffiliateInCategoryView");
        //    builder.EntitySet<auth_AffiliateInCategoryMnt>("auth_AffiliateInCategoryMnt");
        //    // ============================================================

        //    // RolesInCategory
        //    // ============================================================
        //    builder.EntitySet<auth_RolesInCategory>("auth_RolesInCategory");
        //    builder.EntitySet<auth_RolesInCategoryView>("auth_RolesInCategoryView");
        //    builder.EntitySet<auth_RolesInCategoryMnt>("auth_RolesInCategoryMnt");
        //    // ============================================================

        //    // UsersInRolesAssign
        //    // ============================================================
        //    builder.EntitySet<auth_Roles>("auth_UsersInRolesAssignQry");
        //    builder.EntitySet<auth_UsersInRolesApproveData>("auth_UsersInRolesAssignMnt");
        //    builder.EntitySet<auth_UsersInRolesApproveView>("auth_UsersInRolesApproveView");
        //    // ============================================================

        //    // UsersInRolesApprove
        //    // ============================================================
        //    builder.EntitySet<auth_Roles>("auth_UsersInRolesApproveQry");
        //    builder.EntitySet<auth_UsersInRolesApprove>("auth_UsersInRolesApprove");
        //    builder.EntitySet<auth_UsersInRolesApproveData>("auth_UsersInRolesApproveMnt");
        //    // ============================================================

        //    // securityAssign
        //    // ============================================================
        //    builder.EntitySet<securityAssign>("securityAssign");
        //    builder.EntitySet<securityAssignTransaction>("securityAssignTransaction");
        //    // ============================================================

        //    builder.EntitySet<auth_UsersInGroups>("auth_UsersInGroups");


        //    builder.EntitySet<auth_PageFunctionsInRoles>("auth_PageFunctionsInRoles");
        //    builder.EntitySet<auth_Affiliate>("auth_Affiliate");
        //    builder.EntitySet<auth_PagesInRoles>("auth_PagesInRoles");
        //    builder.EntitySet<auth_PagesInRolesView>("auth_PagesInRolesView");
        //    // ============================================================

        //    // Approvelog test
        //    // ============================================================
        //    builder.EntitySet<FS_WL_Info_ApproveLog_test>("FS_WL_Info_ApproveLog_test");
        //    builder.EntitySet<FS_TotalRating_ApproveLog_test>("FS_TotalRating_ApproveLog_test");
        //    // ============================================================

        //    builder.EntitySet<sec_Watermark>("sec_Watermark");
        //    builder.EntitySet<sec_ShortcutsBlock>("sec_ShortcutsBlock");
        //    builder.EntitySet<CB_GN_ParCat_DTL>("CB_GN_ParCat_DTL");
        //    builder.EntitySet<CB_GN_ParCat>("CB_GN_ParCat");

        //    // Flow_System_CBGNParCat
        //    // =============================
        //    builder.EntitySet<CB_GN_ParCat_Insert>("Flow_System_CBGNParCat_Insert");
        //    builder.EntitySet<CB_GN_ParCat_Update>("Flow_System_CBGNParCat_Update");
        //    // =============================

        //    #endregion
        //}

        private static void defineISMD(ref ODataConventionModelBuilder builder)
        {
            #region [ISMD]

            builder.EntitySet<Flow_Test>("Flow_Test");


            // Table
            // =============================
            builder.EntitySet<WWKSPC_XFLOWDETAIL>("WWKSPC_XFLOWDETAIL");
            builder.EntitySet<WWKSPC_XJOBDETAIL>("WWKSPC_XJOBDETAIL");
            builder.EntitySet<WWKSPC_XLOCALDETAIL>("WWKSPC_XLOCALDETAIL");
            builder.EntitySet<WWKSPC_XMONITOR_FILEWAIT>("WWKSPC_XMONITOR_FILEWAIT");
            builder.EntitySet<WWKSPC_XMONITOR_FLOWTIME>("WWKSPC_XMONITOR_FLOWTIME");
            builder.EntitySet<WWKSPC_XREMOTEDETAIL>("WWKSPC_XREMOTEDETAIL");
            builder.EntitySet<WWKSPC_XSCHEDULE>("WWKSPC_XSCHEDULE");
            builder.EntitySet<WWKSPC_XWAITDETAIL>("WWKSPC_XWAITDETAIL");

            builder.EntitySet<sysssislog>("sysssislog");
            builder.EntitySet<XBATCHFLOW>("XBATCHFLOW");
            builder.EntitySet<XCOLUMNDETAIL>("XCOLUMNDETAIL");
            builder.EntitySet<XENCRYPTION>("XENCRYPTION");
            builder.EntitySet<XFILEDETAIL>("XFILEDETAIL");
            builder.EntitySet<XFILESTATUS>("XFILESTATUS");
            builder.EntitySet<XFLATFILEDETAIL>("XFLATFILEDETAIL");
            builder.EntitySet<XFLOWAGENT>("XFLOWAGENT");
            builder.EntitySet<XFLOWSTATUS>("XFLOWSTATUS");
            builder.EntitySet<XFLOWSTATUSH>("XFLOWSTATUSH");
            builder.EntitySet<XPROCESSFLOW>("XPROCESSFLOW");
            builder.EntitySet<XFLOWDETAIL>("XFLOWDETAIL");
            builder.EntitySet<XLOCALDETAIL>("XLOCALDETAIL");
            builder.EntitySet<XREMOTEDETAIL>("XREMOTEDETAIL");
            builder.EntitySet<XSCHEDULE>("XSCHEDULE");
            builder.EntitySet<XSERVERDETAIL>("XSERVERDETAIL");
            builder.EntitySet<WJOBITEM>("WJOBITEM");
            builder.EntitySet<XWAITSTATUS>("XWAITSTATUS");
            builder.EntitySet<XJOBDETAIL>("XJOBDETAIL");
            builder.EntitySet<XJOBFILE>("XJOBFILE");
            builder.EntitySet<XLOCALDETAIL>("XLOCALDETAIL");
            builder.EntitySet<XREMOTEDETAIL>("XREMOTEDETAIL");
            builder.EntitySet<XWAITDETAIL>("XWAITDETAIL");
            builder.EntitySet<XFILEDETAIL>("XFILEDETAIL");
            builder.EntitySet<XMAILDETAIL>("XMAILDETAIL");
            builder.EntitySet<XMONITOR_FILEWAIT>("XMONITOR_FILEWAIT");
            builder.EntitySet<XMONITOR_FLOWTIME>("XMONITOR_FLOWTIME");
            // =============================

            // View
            // =============================
            builder.EntitySet<WV_XBATCHFLOW>("WV_XBATCHFLOW");
            builder.EntitySet<WV_XFILESTATUS>("WV_XFILESTATUS");
            builder.EntitySet<WV_XFILESTATUS>("WV_XFILESTATUSH");
            builder.EntitySet<WV_XWAITSTATUS>("WV_XWAITSTATUS");
            builder.EntitySet<WV_XWAITSTATUS>("WV_XWAITSTATUSH");
            builder.EntitySet<WV_WJOBITEM>("WV_WJOBITEM");
            // =============================

            // Flow_Main_Flow_Dashboard
            // =============================
            builder.EntitySet<WSP_QRY_FlowProgress>("WSP_QRY_FlowProgress");
            builder.EntitySet<WSP_QRY_FlowStatus>("WSP_QRY_FlowStatus");
            builder.EntitySet<Flow_Dashboard_Qry_StatisticsChart>("Flow_Dashboard_Qry_RunTimeChart");
            builder.EntitySet<Flow_Dashboard_Qry_StatisticsChart>("Flow_Dashboard_Qry_FileStatusChart");
            builder.EntitySet<Flow_Dashboard_Qry_StatisticsChart>("Flow_Dashboard_Qry_WaitStatusChart");
            builder.EntitySet<Flow_Dashboard_Qry_StatisticsChart>("Flow_Dashboard_Qry_BatchFlowChart");
            builder.EntitySet<Flow_Dashboard_Qry_StatisticsChart>("Flow_Dashboard_Qry_NextRunTimeChart");
            builder.EntitySet<WV_XBATCHFLOWView>("Flow_Dashboard_Qry_RunningBatchFlow");
            builder.EntitySet<WV_XBATCHFLOWView>("Flow_Dashboard_Qry_FailedBatchFlow");
            builder.EntitySet<WV_XFILESTATUS>("Flow_Dashboard_Qry_FileStatus");
            builder.EntitySet<WV_XWAITSTATUS>("Flow_Dashboard_Qry_WaitStatus");
            builder.EntitySet<WV_XBATCHFLOWView>("WV_XBATCHFLOWView");
            builder.EntitySet<WV_XFILESTATUSView>("WV_XFILESTATUSView");
            builder.EntitySet<WV_XWAITSTATUSView>("WV_XWAITSTATUSView");
            // =============================

            // Flow_Main_Flow_List
            // =============================
            builder.EntitySet<WV_XFLOWDETAILView>("WV_XFLOWDETAILView");
            builder.EntitySet<WV_XFLOWSTATUSView>("WV_XFLOWSTATUSView");
            builder.EntitySet<ETLFlowTree>("Flow_Main_Flow_FlowTree");
            builder.EntitySet<WSP_INS_XFlowagent>("WSP_INS_XFlowagent");
            builder.EntitySet<WSP_DEL_XFlowTable>("WSP_DEL_XFlowTable");
            // =============================

            // Flow_Main_Flow_Insert
            // =============================
            builder.EntitySet<Flow_Insert>("Flow_Insert");
            builder.EntitySet<Flow_Insert_Schedule_List>("Flow_Insert_Schedule_List");
            builder.EntitySet<Flow_Insert_LocalDetail_List>("Flow_Insert_LocalDetail_List");
            builder.EntitySet<Flow_Insert_WaitDetail_List>("Flow_Insert_WaitDetail_List");
            builder.EntitySet<Flow_Insert_FileDetail_List>("Flow_Insert_FileDetail_List");
            builder.EntitySet<Flow_Insert_JobDetail_List>("Flow_Insert_JobDetail_List");
            builder.EntitySet<DropDownEntity>("Flow_Insert_JobDetail_DropDown_FlatFile");
            builder.EntitySet<DropDownEntity>("Flow_Insert_JobDetail_DropDown_Table");
            builder.EntitySet<Flow_Insert_MailDetail_List>("Flow_Insert_MailDetail_List");

            builder.EntitySet<Flow_Insert_WwkspcSchedule_Delete>("Flow_Insert_WwkspcSchedule_Delete");
            builder.EntitySet<Flow_Insert_WwkspcLocalDetail_Delete>("Flow_Insert_WwkspcLocalDetail_Delete");
            builder.EntitySet<Flow_Insert_WwkspcRemoteDetail_Delete>("Flow_Insert_WwkspcRemoteDetail_Delete");
            builder.EntitySet<Flow_Insert_WwkspcWaitDetail_DeleteInsert>("Flow_Insert_WwkspcWaitDetail_DeleteInsert");
            builder.EntitySet<Flow_Insert_WwkspcFileDetail_List_Data>("Flow_Insert_WwkspcFileDetail_List_Data");
            builder.EntitySet<Flow_Insert_WwkspcFileDetail_List_Data>("Flow_Insert_WwkspcFileDetail_List");
            builder.EntitySet<Flow_Insert_WwkspcFileDetail_DeleteInsert>("Flow_Insert_WwkspcFileDetail_DeleteInsert");
            builder.EntitySet<Flow_Insert_WwkspcJobDetail_DeleteInsert>("Flow_Insert_WwkspcJobDetail_DeleteInsert");
            builder.EntitySet<Flow_Insert_WwkspcMailDetail_List>("Flow_Insert_WwkspcMailDetail_List");
            builder.EntitySet<Flow_Insert_WwkspcMailDetail_Update>("Flow_Insert_WwkspcMailDetail_Update");
            builder.EntitySet<Flow_Insert_WwkspcMailDetail_Delete>("Flow_Insert_WwkspcMailDetail_Delete");
            builder.EntitySet<Flow_Insert_WwkspcMailDetail_InsertMailType>("Flow_Insert_WwkspcMailDetail_InsertMailType");
            // =============================

            // Flow_Main_Flow_ExecInfo
            // =============================
            builder.EntitySet<XFLOWSTATUSHView>("XFLOWSTATUSHView");
            builder.EntitySet<WSP_QRY_FlowStatus>("WSP_QRY_FlowStatusH");
            builder.EntitySet<WV_XBATCHFLOWView>("WV_XBATCHFLOWHView");
            builder.EntitySet<WV_XFILESTATUSView>("WV_XFILESTATUSHView");
            builder.EntitySet<WV_XWAITSTATUSView>("WV_XWAITSTATUSHView");
            builder.EntitySet<ETLFlowTree>("Flow_Main_Flow_FlowTreeH");
            // =============================

            // Flow_Main_Flow_Update
            // =============================
            builder.EntitySet<Flow_Update_JobDetail_List>("Flow_Update_JobDetail_List");
            builder.EntitySet<Flow_Update_LocalRemoteDetail_List>("Flow_Update_LocalRemoteDetail_List");
            builder.EntitySet<Flow_Update_Schedule_List>("Flow_Update_Schedule_List");
            builder.EntitySet<Flow_Update_WaitDetail_List>("Flow_Update_WaitDetail_List");
            builder.EntitySet<Flow_Update_FileDetail_List_Data>("Flow_Update_FileDetail_List_Data");
            builder.EntitySet<Flow_Update_FileDetail_List>("Flow_Update_FileDetail_List");
            builder.EntitySet<Flow_Update_MailDetail_List>("Flow_Update_MailDetail_List");
            builder.EntitySet<Flow_Update>("Flow_Update");
            builder.EntitySet<Flow_Insert>("Flow_Update_InitialLoad");
            // =============================

            // Flow_System_MailDetail_List
            // =============================
            builder.EntitySet<XMAILDETAIL_List_Data>("Flow_System_MailDetail_List");
            builder.EntitySet<Flow_System_MailDetail_InsertMailType>("Flow_System_MailDetail_InsertMailType");
            builder.EntitySet<Flow_System_MailDetail_Insert>("Flow_System_MailDetail_Insert");
            builder.EntitySet<Flow_System_MailDetail_Update>("Flow_System_MailDetail_Update");
            builder.EntitySet<Flow_System_MailDetail_Delete>("Flow_System_MailDetail_Delete");
            builder.EntitySet<Flow_System_MailDetail_GlobalConfig>("Flow_System_MailDetail_GlobalConfig");
            // =============================

            // Flow_System_ServerDetail
            // =============================
            builder.EntitySet<Flow_System_ServerDetail_Insert>("Flow_System_ServerDetail_Insert");
            builder.EntitySet<Flow_System_ServerDetail_Update>("Flow_System_ServerDetail_Update");
            builder.EntitySet<Flow_System_ServerDetail_Delete>("Flow_System_ServerDetail_Delete");
            // =============================

            // Flow_System_JobItem
            // =============================
            builder.EntitySet<Flow_System_JobItem_List>("Flow_System_JobItem_List");
            builder.EntitySet<Flow_System_JobItem_Delete>("Flow_System_JobItem_Delete");
            builder.EntitySet<Flow_System_JobItem_ListUpdate>("Flow_System_JobItem_ListUpdate");
            builder.EntitySet<Flow_System_JobItem_Update>("Flow_System_JobItem_Update");
            // =============================

            // Flow_System_ParameterImport
            // =============================
            builder.EntitySet<Flow_System_ParameterImport_Insert>("Flow_System_ParameterImport_Insert");
            // =============================

            // Flow_System_ColumnDetail
            // =============================
            builder.EntitySet<Flow_System_ColumnDetail_List>("Flow_System_ColumnDetail_List");
            builder.EntitySet<Flow_System_ColumnDetail_Insert>("Flow_System_ColumnDetail_Insert");
            builder.EntitySet<Flow_System_ColumnDetail_Insert>("Flow_System_ColumnDetail_Delete");
            // =============================


            #endregion
        }
    }
}


