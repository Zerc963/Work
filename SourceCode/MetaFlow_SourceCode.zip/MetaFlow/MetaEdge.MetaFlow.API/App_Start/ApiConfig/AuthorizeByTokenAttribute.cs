﻿using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using System.Linq;
using MetaEdge.Web;

namespace MetaEdge.MetaFlow.API
{
    public partial class WebApiConfig
    {
        public class AuthorizeByTokenAttribute : AuthorizeAttribute
        {
            public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                base.OnAuthorization(actionContext);

                // 取得client端資訊
                //var userHostAddress = ((System.Web.HttpContextWrapper)actionContext.Request.Properties["MS_HttpContext"]).Request.UserHostAddress;
                //var userIdentity = ((System.Web.HttpContextWrapper)actionContext.Request.Properties["MS_HttpContext"]).Request.LogonUserIdentity;

                string webInfo = actionContext.Request.Headers.GetValues("WEB-INFO").ToList()[0];

                if (!string.IsNullOrEmpty(webInfo) && webInfo.Substring(0, 1) != "{")
                {
                    byte[] webInfoBytes = System.Convert.FromBase64String(webInfo);
                    string encryptWebInfo = System.Text.Encoding.GetEncoding("utf-8").GetString(webInfoBytes);
                    webInfo = MetaEdge.Security.AESDecryptor.Decrypt(encryptWebInfo);
                }

                ApiClientInfo clientInfo = JsonConvert.DeserializeObject<ApiClientInfo>(webInfo);
                HttpContext.Current.Items["UserId"] = clientInfo.UserId;
                HttpContext.Current.Items["UserCode"] = clientInfo.UserCode;
                HttpContext.Current.Items["AffiliateId"] = clientInfo.AffiliateId;
            }

            //public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext context)
            //{
            //    System.Security.Principal.IPrincipal principal = context.ControllerContext.Request.GetUserPrincipal();
            //    if (principal == null || !principal.IsInRole("Administrators"))
            //    {
            //        context.Response = new System.Net.Http.HttpResponseMessage(System.Net.HttpStatusCode.Unauthorized);
            //    }

            //}

            protected override bool IsAuthorized(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                //throw new Exception("This is Error!!!");
                // 取得client端資訊
                var userHostAddress = ((System.Web.HttpContextWrapper)actionContext.Request.Properties["MS_HttpContext"]).Request.UserHostAddress;
                var userIdentity = ((System.Web.HttpContextWrapper)actionContext.Request.Properties["MS_HttpContext"]).Request.LogonUserIdentity;
                return true;
            }
        }

    }
}