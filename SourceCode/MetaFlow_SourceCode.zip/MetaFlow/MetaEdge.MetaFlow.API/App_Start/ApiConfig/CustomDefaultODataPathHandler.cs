﻿using System.Web.Http.OData.Routing;

namespace MetaEdge.MetaFlow.API
{
    public partial class WebApiConfig
    {
        public class CustomDefaultODataPathHandler : DefaultODataPathHandler
        {
            public override ODataPath Parse(Microsoft.Data.Edm.IEdmModel model, string odataPath)
            {
                return base.Parse(model, odataPath);
            }
        }
    }
}