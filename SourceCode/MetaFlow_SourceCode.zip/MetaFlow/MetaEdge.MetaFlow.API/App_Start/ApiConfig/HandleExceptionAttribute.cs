﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;
using Microsoft.Data.OData;
using System.Data.Entity.Validation;
using System.Linq;
using System.Reflection;

namespace MetaEdge.MetaFlow.API
{
    public class HandleExceptionAttribute : ExceptionFilterAttribute
    {
        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            string exceptionMsg = string.Empty;
            HttpStatusCode exceptionStatus = HttpStatusCode.Unused;

            Exception ex = actionExecutedContext.Exception;

            if (actionExecutedContext.Exception.InnerException != null)
            {
                ex = actionExecutedContext.Exception.InnerException;

                if (actionExecutedContext.Exception.InnerException.InnerException != null)
                {
                    ex = actionExecutedContext.Exception.InnerException.InnerException;
                }
            }

            #region exception handle
            if (ex is SqlException)
            {
                #region 將SqlException的訊息抓出
                string te = JsonConvert.SerializeObject(ex);
                JToken exj = JObject.Parse(te).SelectToken("Errors").Value<JArray>()[0];

                exceptionMsg = exj.ToString();
                exceptionStatus = HttpStatusCode.BadRequest;

                MetaEdge.Utility.ExceptionUtility.LogException(ex, "SqlException");
                #endregion
            }
            else if (ex is ODataException)
            {
                #region 將ODataException傳出
                JObject exj = new JObject();

                exj.Add("ExceptionType", ex.GetType().FullName);
                exj.Add("Message", ex.Message);
                exceptionMsg = exj.ToString();

                MetaEdge.Utility.ExceptionUtility.LogException(ex, "ODataException");
                #endregion
            }
            else if (ex is DbEntityValidationException)
            {
                DbEntityValidationException deve = ex as DbEntityValidationException;
                var entityError = deve.EntityValidationErrors.SelectMany(x => x.ValidationErrors).Select(x => x.ErrorMessage);
                var getFullMessage = string.Join("; ", entityError);
                var exceptionMessage = string.Concat(deve.Message, "errors are: ", getFullMessage);

                JObject exj = new JObject();

                exj.Add("ExceptionType", deve.GetType().FullName);
                exj.Add("Message", exceptionMessage);
                exceptionMsg = exj.ToString();

                MetaEdge.Utility.ExceptionUtility.LogException(new Exception(exceptionMessage, deve), "DbEntityValidationException");
            }
            else
            {
                #region 將exception基底型別及原因回傳
                JObject exj = new JObject();
                exj.Add("Message", HttpUtility.UrlEncode(ex.Message));
                exj.Add("ExceptionType", ex.GetType().FullName);

                exceptionMsg = exj.ToString();
                exceptionStatus = HttpStatusCode.InternalServerError;

                MetaEdge.Utility.ExceptionUtility.LogException(ex, "Exception");
                #endregion
            }
            #endregion

            //var response = new HttpResponseMessage
            //{
            //    StatusCode = exceptionStatus,

            //    ReasonPhrase = Convert.ToBase64String(System.Text.Encoding.Default.GetBytes(exceptionMsg.Replace("\r\n", ""))),

            //};

            //actionExecutedContext.Response.ReasonPhrase = 
            //actionExecutedContext.Request.CreateErrorResponse(exceptionStatus, actionExecutedContext.Exception.GetBaseException().Message);

            var response = actionExecutedContext.Request.CreateResponse(exceptionStatus, exceptionMsg.Replace("\r\n", ""));            
            PropertyInfo propertyInfo = actionExecutedContext.ActionContext.GetType().GetProperty("Response");
            propertyInfo.SetValue(actionExecutedContext.ActionContext, response);
        }
    }

}