﻿using System.Data.Entity;

namespace MetaEdge.MetaFlow.API
{
    #region[DBConfiguration]
    public class MyDbConfiguration : DbConfiguration
    {
        public MyDbConfiguration()
        {
            SetDatabaseLogFormatter(
                (context, writeAction) => new OneLineFormatter(context, writeAction));
        }
    }
    #endregion
}