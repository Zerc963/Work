﻿using MetaEdge.Web;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;

namespace MetaEdge.MetaFlow.API
{
    public partial class WebApiConfig
    {
        public class ApiResultAttribute : System.Web.Http.Filters.ActionFilterAttribute
        {
            public override void OnActionExecuted(System.Web.Http.Filters.HttpActionExecutedContext actionExecutedContext)
            {
                base.OnActionExecuted(actionExecutedContext);

                string webInfo = actionExecutedContext.ActionContext.Request.Headers.GetValues("WEB-INFO").ToList()[0];

                if (!string.IsNullOrEmpty(webInfo) && webInfo.Substring(0, 1) != "{")
                {
                    byte[] webInfoBytes = System.Convert.FromBase64String(webInfo);
                    string encryptWebInfo = System.Text.Encoding.GetEncoding("utf-8").GetString(webInfoBytes);
                    webInfo = MetaEdge.Security.AESDecryptor.Decrypt(encryptWebInfo);
                }

                ApiClientInfo apiClientInfo = JsonConvert.DeserializeObject<ApiClientInfo>(webInfo);
                string logType = apiClientInfo.LogType; // actionExecutedContext.ActionContext.Request.Headers.GetValues("FATCA-LogType").ToList()[0];

                OperationLog(actionExecutedContext, apiClientInfo, "OnActionExecuted");

                if (actionExecutedContext.Exception == null)
                {
                    if (actionExecutedContext.ActionContext.Response.Content == null)
                    {
                        ApiResultEntity result = new ApiResultEntity();

                        //取得由 API 返回的狀態碼
                        result.Status = actionExecutedContext.ActionContext.Response.StatusCode;

                        //取得由 API 返回的資料
                        StringBuilder sb = new StringBuilder();
                        sb.Append("{");
                        sb.Append(Environment.NewLine);
                        sb.Append("\"value\": []");
                        sb.Append(Environment.NewLine);
                        sb.Append("}");

                        result.Data = sb.ToString();

                        //result.Data = @"{""value"": []\r\n}";

                        //
                        //{
                        //    "odata.metadata": "http://localhost/RTSAPI/odata/$metadata#FS_CU_ShareHolder",
                        //    "value": []
                        //}

                        //重新封裝回傳格式
                        //actionExecutedContext.Response = actionExecutedContext.Request.CreateResponse(result.Status, result);
                        // HttpResponseMessage response =  new HttpResponseMessage(result.Status);
                        // response.Content
                        //HttpMessageContent content = new HttpMessageContent(response);



                        //HttpResponseMessage response =
                        //    new HttpResponseMessage(HttpStatusCode.NoContent)
                        //    {
                        //        Content = new ObjectContent<JObject>(JObject.Parse(result.Data.ToString()), new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                        //        //Content = new ObjectContent<JObject>((item.Data), new System.Net.Http.Formatting.JsonMediaTypeFormatter(), new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("multipart/mixed"))
                        //    };

                        //actionExecutedContext.ActionContext.Response = response;


                        HttpResponseMessage response =
                            new HttpResponseMessage(result.Status)
                            {
                                Content = new ObjectContent<JObject>(JObject.Parse(result.Data.ToString()), new System.Net.Http.Formatting.JsonMediaTypeFormatter())
                                //Content = new ObjectContent<JObject>((item.Data), new System.Net.Http.Formatting.JsonMediaTypeFormatter(), new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("multipart/mixed"))
                            };

                        PropertyInfo propertyInfo = actionExecutedContext.ActionContext.GetType().GetProperty("Response");
                        propertyInfo.SetValue(actionExecutedContext.ActionContext, response);

                    }

                    #region handle odata語法出錯的項目
                    if (!actionExecutedContext.Response.IsSuccessStatusCode)
                    {

                        //將response的Content轉為可以序列化的物件
                        //從中取出odata Error的訊息
                        System.Net.Http.ObjectContent content = ((((System.Net.Http.ObjectContent)(actionExecutedContext.Response.Content))));

                        string errorSerialize = Newtonsoft.Json.JsonConvert.SerializeObject(content.Value);
                        JObject errorObject = JObject.Parse(errorSerialize);
                        string exceptionTyp = (string)errorObject.SelectToken("ExceptionType");
                        string exceptionMsg = (string)errorObject.SelectToken("ExceptionMessage");

                        //exceptionTyp,exceptionMsg皆不為null時
                        if (!string.IsNullOrEmpty(exceptionTyp) && !string.IsNullOrEmpty(exceptionTyp))
                        {
                            //透過reflection去將Exception類別產生
                            Assembly _assembly = Assembly.Load("Microsoft.Data.OData");
                            Type objectInstance = _assembly.GetType(exceptionTyp);
                            Object[] constructParms = new object[] { exceptionMsg };  //建構式參數
                            Object reflectInsance = System.Activator.CreateInstance(objectInstance, constructParms);

                            if (reflectInsance is Microsoft.Data.OData.ODataException)
                            {
                                throw reflectInsance as Microsoft.Data.OData.ODataException;
                            }
                        }
                        else
                        {
                            //throw new Exception(errorObject.ToString());
                            throw new Exception(actionExecutedContext.ActionContext.Response.StatusCode.ToString());
                        }
                    }
                    #endregion
                }
            }

            public override void OnActionExecuting(System.Web.Http.Controllers.HttpActionContext actionContext)
            {
                string _method = actionContext.Request.Method.ToString().ToUpper();
                string _json = Newtonsoft.Json.JsonConvert.SerializeObject(actionContext.ActionArguments);
                string _url = actionContext.Request.RequestUri.AbsoluteUri;

                MetaEdge.TextLog.ApiFactory.WriteLog(_json, _method, _url);
            }

            public class ApiResultEntity
            {
                public System.Net.HttpStatusCode Status { get; set; }

                public object Data { get; set; }

                public string ErrorMessage { get; set; }
            }

            public class NullResponseContent
            {
                public string Value { get; set; }
            }
        }

    }
}