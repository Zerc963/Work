﻿using MetaEdge.Web;

namespace MetaEdge.MetaFlow.API
{
    public partial class WebApiConfig
    {
        private static void OperationLog(System.Web.Http.Controllers.HttpActionContext actionContext, ApiClientInfo apiClientInfo, string eventName)
        {
            MetaEdge.Data.LogHelper.OperationLog(actionContext, apiClientInfo, eventName);
        }

        private static void OperationLog(System.Web.Http.Filters.HttpActionExecutedContext actionExecutedContext, ApiClientInfo apiClientInfo, string eventName)
        {
            MetaEdge.Data.LogHelper.OperationLog(actionExecutedContext, apiClientInfo, eventName);
        }
    }
}