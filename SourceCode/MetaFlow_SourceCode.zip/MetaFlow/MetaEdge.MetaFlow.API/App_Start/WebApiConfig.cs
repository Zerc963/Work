﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.OData.Batch;
using System.Web.Http.OData.Builder;
using System.Web.Http.OData.Routing.Conventions;
using MetaEdge.MetaFlow.API.ODataConventions;

namespace MetaEdge.MetaFlow.API
{
    public partial class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.EnableCors();

            //config.EnableCors(new EnableCorsAttribute("http://FATCAWEB", "*", "*"));
            config.EnableQuerySupport();

            // 新增OData Route Map
            ODataConventionModelBuilder builder = CreateODataConventionModelBuilder();

            // 新增複合主鍵的轉換處理
            var conventions = ODataRoutingConventions.CreateDefault();
            conventions.Insert(0, new CompositeKeyRoutingConvention());

            config.Routes.MapODataRoute(
                routeName: "ODataRoute",
                routePrefix: "odata",
                model: builder.GetEdmModel(),
                pathHandler: new CustomDefaultODataPathHandler(),
                routingConventions: conventions,
                batchHandler: new DefaultODataBatchHandler(GlobalConfiguration.DefaultServer));


            // 驗證使用者
            config.Filters.Add(new AuthorizeByTokenAttribute());

            config.Filters.Add(new ApiResultAttribute());

            // 處理錯誤訊息
            config.Filters.Add(new HandleExceptionAttribute());

            config.MessageHandlers.Add(new MetaEdge.MetaFlow.API.MethodOverrideHandler());
            //config.IncludeErrorDetailPolicy = IncludeErrorDetailPolicy.Always;
        }
    }
}
