using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_WwkspcMailDetail_Update
    {
        public string Old_MAILADR { get; set; }

        public string DATACAT { get; set; }
        public string MAILADR { get; set; }
        public string MAIL_DESC { get; set; }

        public bool notifyRUNOK_fg { get; set; }
        public bool notifyABORT_fg { get; set; }
        public bool notifyMONITOR_FILE_WAIT_fg { get; set; }
        public bool notifyMONITOR_FLOW_TIME_fg { get; set; }

        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
