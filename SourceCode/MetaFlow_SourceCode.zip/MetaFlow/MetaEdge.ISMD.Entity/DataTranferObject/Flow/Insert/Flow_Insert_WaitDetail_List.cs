using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_WaitDetail_List
    {
        public XWAITDETAIL[] Detail { get; set; }
    }
}
