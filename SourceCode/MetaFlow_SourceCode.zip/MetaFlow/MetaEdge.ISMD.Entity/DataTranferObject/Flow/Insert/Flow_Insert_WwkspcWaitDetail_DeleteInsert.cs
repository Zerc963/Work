using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_WwkspcWaitDetail_DeleteInsert
    {
        public WWKSPC_XWAITDETAIL[] DeleteDetail { get; set; }
        public WWKSPC_XWAITDETAIL[] InsertDetail { get; set; }
    }
}
