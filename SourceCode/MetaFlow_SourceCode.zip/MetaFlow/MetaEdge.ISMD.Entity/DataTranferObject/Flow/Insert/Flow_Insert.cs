using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert
    {
        public XFLOWDETAIL FlowDetail { get; set; }
        public XSCHEDULE[] Schedule { get; set; }
        public XLOCALDETAIL[] LocalDetail { get; set; }
        public XREMOTEDETAIL[] RemoteDetail { get; set; }
        public XWAITDETAIL[] WaitDetail { get; set; }
        public Flow_Insert_FileDetail_List_Data[] FileDetail { get; set; }
        public XJOBDETAIL[] JobDetail { get; set; }
        public Flow_Insert_MailDetail_List MailDetail { get; set; }
    }
}
