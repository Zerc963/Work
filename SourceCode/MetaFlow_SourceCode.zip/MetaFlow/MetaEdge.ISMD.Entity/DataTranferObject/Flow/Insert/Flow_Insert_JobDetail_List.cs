using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_JobDetail_List
    {
        public XJOBDETAIL[] Detail { get; set; }
    }
}
