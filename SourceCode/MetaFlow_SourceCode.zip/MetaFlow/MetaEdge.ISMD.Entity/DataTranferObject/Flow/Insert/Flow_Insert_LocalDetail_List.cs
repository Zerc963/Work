using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_LocalDetail_List
    {
        public XLOCALDETAIL[] LocalDetail { get; set; }
        public XREMOTEDETAIL[] RemoteDetail { get; set; }
    }
}
