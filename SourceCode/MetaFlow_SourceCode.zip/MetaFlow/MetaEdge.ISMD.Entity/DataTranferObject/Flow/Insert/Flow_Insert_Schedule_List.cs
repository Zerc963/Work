using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_Schedule_List
    {
        public XSCHEDULE[] Detail { get; set; }
    }
}
