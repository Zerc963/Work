using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_WwkspcLocalDetail_Delete
    {
        public WWKSPC_XLOCALDETAIL[] Detail { get; set; }
    }
}
