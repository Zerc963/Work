using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_WwkspcRemoteDetail_Delete
    {
        public WWKSPC_XREMOTEDETAIL[] Detail { get; set; }
    }
}
