using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_WwkspcSchedule_Delete
    {
        public WWKSPC_XSCHEDULE[] Detail { get; set; }
    }
}
