using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Insert_WwkspcJobDetail_DeleteInsert
    {
        public WWKSPC_XJOBDETAIL[] DeleteDetail { get; set; }
        public WWKSPC_XJOBDETAIL[] InsertDetail { get; set; }
    }
}
