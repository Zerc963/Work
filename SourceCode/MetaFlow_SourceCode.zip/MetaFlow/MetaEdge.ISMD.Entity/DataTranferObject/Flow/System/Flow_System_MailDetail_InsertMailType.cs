using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_MailDetail_InsertMailType
    {
        public string DATACAT { get; set; }
        public string MAILADR { get; set; }
        public string MAIL_DESC { get; set; }
        public string MAIL_TYPE { get; set; }

        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
