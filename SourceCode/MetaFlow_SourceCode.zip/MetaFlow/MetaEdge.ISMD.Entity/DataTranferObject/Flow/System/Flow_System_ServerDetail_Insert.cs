using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_ServerDetail_Insert
    {
        public string SERVERTYPE { get; set; }
        public string SERVERNM { get; set; }
        public string USERCODE { get; set; }
        public string PW { get; set; }
        public string PORT { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
        public string PW_SEQ { get; set; }
    }

    public partial class Flow_System_ServerDetail_Delete
    {
        public Flow_System_ServerDetail_DeleteDetail[] DeleteDetail { get; set; }
    }

    public partial class Flow_System_ServerDetail_DeleteDetail
    {
        public string SERVERTYPE { get; set; }
        public string SERVERNM { get; set; }
        public string USERCODE { get; set; }
    }
}
