using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_MailDetail_Delete
    {
        public Flow_System_MailDetail_DeleteDetail[] Detail { get; set; }
    }

    public partial class Flow_System_MailDetail_DeleteDetail
    {
        public string DATACAT { get; set; }
        public string MAIL_TYPE { get; set; }
        public string MAILADR { get; set; }
    }
}
