using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_JobItem_Delete
    {
        public WJOBITEM_PrimaryKey[] DeleteDetail { get; set; }
    }

    public partial class WJOBITEM_PrimaryKey
    {
        public string JOB_NAME { get; set; }
        public string JOB_TYPE { get; set; }
        public string JOB_LOCATION { get; set; }
        public string JOB_OWNER { get; set; }
    }
}