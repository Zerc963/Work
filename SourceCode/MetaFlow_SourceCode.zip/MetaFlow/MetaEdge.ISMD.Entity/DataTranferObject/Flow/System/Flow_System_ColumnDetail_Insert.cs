using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_ColumnDetail_Insert
    {
        public List<XCOLUMNDETAIL> Detail { get; set; }
    }

}
