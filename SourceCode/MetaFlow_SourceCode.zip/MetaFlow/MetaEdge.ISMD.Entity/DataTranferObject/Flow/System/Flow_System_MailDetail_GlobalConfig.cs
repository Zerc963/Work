using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_MailDetail_GlobalConfig 
    {
        public bool Enabled { get; set; }
        public string SmtpServer { get; set; }
        public string SmtpPort { get; set; }
        public string SmtpAccount { get; set; }
        public string SmtpPd { get; set; }
        public string SmtpEnableSsl { get; set; }
        public string MailFromName { get; set; }
        public string MailFrom { get; set; }
        public string MailSubjectPrefix { get; set; }
        public string TestMailAddress { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
