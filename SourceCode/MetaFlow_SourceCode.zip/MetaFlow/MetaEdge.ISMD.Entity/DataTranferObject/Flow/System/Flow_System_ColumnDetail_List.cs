using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_ColumnDetail_List
    {
        public string DB_NM { get; set; }
        public string SCHEMA_NM { get; set; }
        public string TABLE_NM { get; set; }
    }
}
