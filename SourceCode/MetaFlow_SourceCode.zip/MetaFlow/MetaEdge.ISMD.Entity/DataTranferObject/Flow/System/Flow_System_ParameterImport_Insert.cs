using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_System_ParameterImport_Insert
    {
        public string ImportType { get; set; }
        public bool DeleteImport { get; set; }
        public string FileName { get; set; }
        public int FileSize { get; set; }
        public string FileContent { get; set; }
        public string FileType { get; set; }
        public int InsertCount { get; set; }
        public int DeleteCount { get; set; }
    }
}
