using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Test
    {
        public Flow_Test()
        {
            FlowDetail = new Flow_Test_XFLOWDETAIL();
            Schedule = new List<Flow_Test_XSCHEDULE>();
            LocalDetail = new List<Flow_Test_XLOCALDETAIL>();
            RemoteDetail = new List<Flow_Test_XREMOTEDETAIL>();
            WaitDetail = new List<Flow_Test_XWAITDETAIL>();
            FileDetail = new List<Flow_Test_XFILEDETAIL>();
            FlatFileDetail = new List<Flow_Test_XFLATFILEDETAIL>();
            JobDetail = new List<Flow_Test_XJOBDETAIL>();
            MailDetail = new List<Flow_Test_XMAILDETAIL>();
            MonitorFileWait = new List<Flow_Test_XMONITOR_FILEWAIT>();
            MonitorFlowTime = new List<Flow_Test_XMONITOR_FLOWTIME>();
        }

        public Flow_Test_XFLOWDETAIL FlowDetail { get; set; }
        public List<Flow_Test_XSCHEDULE> Schedule { get; set; }
        public List<Flow_Test_XLOCALDETAIL> LocalDetail { get; set; }
        public List<Flow_Test_XREMOTEDETAIL> RemoteDetail { get; set; }
        public List<Flow_Test_XWAITDETAIL> WaitDetail { get; set; }
        public List<Flow_Test_XFILEDETAIL> FileDetail { get; set; }
        public List<Flow_Test_XFLATFILEDETAIL> FlatFileDetail { get; set; }
        public List<Flow_Test_XJOBDETAIL> JobDetail { get; set; }
        public List<Flow_Test_XMAILDETAIL> MailDetail { get; set; }
        public List<Flow_Test_XMONITOR_FILEWAIT> MonitorFileWait { get; set; }
        public List<Flow_Test_XMONITOR_FLOWTIME> MonitorFlowTime { get; set; }
    }

    public partial class Flow_Test_XFLOWDETAIL
    {
        public string DATACAT { get; set; }
        public string FLOW_TYPE { get; set; }
        public string DATACATNM { get; set; }
        public string DT_TYPE { get; set; }
        public Nullable<byte> DT_CHG_HR { get; set; }
        public string CYC_RERUN_FG { get; set; }
        public string CURR_CYC_FG { get; set; }
        public Nullable<byte> RETRY_TIMES { get; set; }
        public Nullable<int> ABORT_RESTART_INTERVAL { get; set; }
        public Nullable<int> ABORT_NOTIFY_SKIP_TIMES { get; set; }
        public string AGENT_MODE { get; set; }
        public string LOCAL_MODE { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XSCHEDULE
    {
        public string DATACAT { get; set; }
        public string PROCESS_TYPE { get; set; }
        public System.TimeSpan START_TIME { get; set; }
        public Nullable<System.TimeSpan> END_TIME { get; set; }
        public Nullable<short> INTERVAL { get; set; }
        public Nullable<System.DateTime> EFFECTIVE_TIME { get; set; }
        public Nullable<System.DateTime> EXPIRATION_TIME { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XLOCALDETAIL
    {
        public string DATACAT { get; set; }
        public string LSEQ { get; set; }
        public string LOCAL_PATH { get; set; }
        public string WORK_PATH { get; set; }
        public string BACKUP_PATH { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XREMOTEDETAIL
    {
        public string DATACAT { get; set; }
        public string RSEQ { get; set; }
        public string SERVERTYPE { get; set; }
        public string SERVERNM { get; set; }
        public string USERCODE { get; set; }
        public string REMOTE_PATH { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XWAITDETAIL
    {
        public string DATACAT { get; set; }
        public string PROCESS_TYPE { get; set; }
        public int WAIT_SEQ { get; set; }
        public string WAIT_TYPE { get; set; }
        public string RSEQ { get; set; }
        public string LSEQ { get; set; }
        public string WAIT_NAME { get; set; }
        public string CHK_FG { get; set; }
        public string CHK_FILEDATE_FG { get; set; }
        public Nullable<int> TOLERANCE { get; set; }
        public string WAIT_SKIP_FLAG { get; set; }
        public string NOT_EXIST_SKIP_FG { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XFILEDETAIL
    {
        public string DATACAT { get; set; }
        public string PROCESS_TYPE { get; set; }
        public int FILE_SEQ { get; set; }
        public string RSEQ { get; set; }
        public string LSEQ { get; set; }
        public string FILENAME { get; set; }
        public string SRCNAME { get; set; }
        public string SRCCNAME { get; set; }
        public string PARENT_FILENAME { get; set; }
        public string SKIP_FLAG { get; set; }
        public string NOT_EXIST_SKIP_FG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public string CRT_FG { get; set; }
        public string CHK_FG { get; set; }
        public string UNZIP_FG { get; set; }
        public string ZIP_PW { get; set; }
        public string FILE_AMT_NM { get; set; }
        public Nullable<decimal> TOLERANCE { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XFLATFILEDETAIL
    {
        public string DATACAT { get; set; }
        public int FILE_SEQ { get; set; }
        public string FILE_GROUP { get; set; }
        public string CODEPAGE { get; set; }
        public string RAGGED_FIX { get; set; }
        public Nullable<int> RECORDLEN { get; set; }
        public Nullable<int> RAGGEDLEN { get; set; }
        public string DELIMITER { get; set; }
        public string TERMINATOR { get; set; }
        public Nullable<int> FIRSTROW { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XJOBDETAIL
    {
        public string DATACAT { get; set; }
        public string PROCESS_TYPE { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
        public string JOB_NAME { get; set; }
        public string PARAM { get; set; }
        public string SKIP_FLAG { get; set; }
        public string FORK_FLAG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public string SRC_TB { get; set; }
        public string TGT_TB { get; set; }
        public string JOB_TYPE { get; set; }
        public string JOB_DESC { get; set; }
        public string JOB_LOCATION { get; set; }
        public string JOB_OWNER { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XMAILDETAIL
    {
        public string DATACAT { get; set; }
        public string MAIL_TYPE { get; set; }
        public string MAILADR { get; set; }
        public string MAIL_DESC { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XMONITOR_FILEWAIT
    {
        public string DATACAT { get; set; }
        public string START_TIME { get; set; }
        public string END_TIME { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }

    public partial class Flow_Test_XMONITOR_FLOWTIME
    {
        public string DATACAT { get; set; }
        public int MAX_DURATION_TIME { get; set; }
        public Nullable<System.DateTime> START_TIME { get; set; }
        public Nullable<System.DateTime> EXPECT_END_TIME { get; set; }
        public Nullable<System.DateTime> CHK_TIME { get; set; }
        public string CHK_STATUS { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}