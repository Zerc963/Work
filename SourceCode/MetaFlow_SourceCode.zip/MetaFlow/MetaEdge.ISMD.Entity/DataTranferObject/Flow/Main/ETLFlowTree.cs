using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class ETLFlowTree
    {
        public string name { get; set; }
        public int waitseq { get; set; }
        public string runstatus { get; set; }
        public List<FileHandleTree> children { get; set; }        
    }

    public partial class FileHandleTree
    {
        public string name { get; set; }
        public int fileseq { get; set; }
        public string runstatus { get; set; }
        public List<FlowTree> children { get; set; }
    }

    public partial class FlowTree
    {
        public string name { get; set; }
        public string runstatus { get; set; }
        public string DATACAT { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
        public string JOB_DESC { get; set; }
        public string FORK_FLAG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public List<StageTree> children { get; set; }
    }

    public partial class StageTree
    {
        public string name { get; set; }
        public string runstatus { get; set; }
        public string DATACAT { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
        public string JOB_DESC { get; set; }
        public string FORK_FLAG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public List<JobTree> children { get; set; }
    }

    public partial class JobTree
    {
        public string name { get; set;}
        public string runstatus { get; set; }
        public string DATACAT { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
        public string SKIP_FLAG { get; set; }
        public string FORK_FLAG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public string JOB_TYPENM { get; set; }
        public string JOB_DESC { get; set; }

    }
}