using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Update_WaitDetail_List
    {
        public XWAITDETAIL[] InsertDetail { get; set; }
        public XWAITDETAIL_PrimaryKey[] DeleteDetail { get; set; }
    }

    public partial class XWAITDETAIL_PrimaryKey
    {
        public string DATACAT { get; set; }
        public int WAIT_SEQ { get; set; }

    }
}
