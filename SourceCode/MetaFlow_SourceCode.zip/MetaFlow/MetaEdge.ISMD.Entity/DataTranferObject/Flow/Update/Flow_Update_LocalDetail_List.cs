using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Update_LocalRemoteDetail_List
    {
        public XLOCALDETAIL[] InsertLocalDetail { get; set; }
        public XLOCALDETAIL_PrimaryKey[] DeleteLocalDetail { get; set; }
        public XREMOTEDETAIL[] InsertRemoteDetail { get; set; }
        public XREMOTEDETAIL_PrimaryKey[] DeleteRemoteDetail { get; set; }
    }

    public partial class XLOCALDETAIL_PrimaryKey
    {
        public string DATACAT { get; set; }
        public string LSEQ { get; set; }
    }

    public partial class XREMOTEDETAIL_PrimaryKey
    {
        public string DATACAT { get; set; }
        public string RSEQ { get; set; }
    }
}
