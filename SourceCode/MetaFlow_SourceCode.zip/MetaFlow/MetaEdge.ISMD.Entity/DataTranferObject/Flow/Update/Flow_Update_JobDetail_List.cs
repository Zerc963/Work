using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Update_JobDetail_List
    {
        public XJOBDETAIL[] InsertDetail { get; set; }
        public XJOBDETAIL_PrimaryKey[] DeleteDetail { get; set; }
    }

    public partial class XJOBDETAIL_PrimaryKey
    {
        public string DATACAT { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
    }
}
