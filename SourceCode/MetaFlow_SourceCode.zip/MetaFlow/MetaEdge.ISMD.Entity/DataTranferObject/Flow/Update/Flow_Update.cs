using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Update
    {
        public XFLOWDETAIL FlowDetail { get; set; }
        public bool ScheduleIsLoaded { get; set; }
        public XSCHEDULE[] Schedule { get; set; }
        public bool LocalDetailIsLoaded { get; set; }
        public XLOCALDETAIL[] LocalDetail { get; set; }
        public bool RemoteDetailIsLoaded { get; set; }
        public XREMOTEDETAIL[] RemoteDetail { get; set; }
        public bool WaitDetailIsLoaded { get; set; }
        public XWAITDETAIL[] WaitDetail { get; set; }
        public bool FileDetailIsLoaded { get; set; }
        public Flow_Insert_FileDetail_List_Data[] FileDetail { get; set; }
        public bool JobDetailIsLoaded { get; set; }
        public XJOBDETAIL[] JobDetail { get; set; }
        public Flow_Insert_MailDetail_List MailDetail { get; set; }
    }
}
