using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Update_FileDetail_List
    {
        public Flow_Update_FileDetail_List_Data[] InsertDetail { get; set; }
        public XFILEDETAIL_PrimaryKey[] DeleteDetail { get; set; }
    }

    public partial class Flow_Update_FileDetail_List_Data 
    {
        public string DATACAT { get; set; }
        public string PROCESS_TYPE { get; set; }
        public int FILE_SEQ { get; set; }
        public string RSEQ { get; set; }
        public string LSEQ { get; set; }
        public string FILENAME { get; set; }
        public string SRCNAME { get; set; }
        public string SRCCNAME { get; set; }
        public string PARENT_FILENAME { get; set; }
        public string SKIP_FLAG { get; set; }
        public string NOT_EXIST_SKIP_FG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public string CRT_FG { get; set; }
        public string CHK_FG { get; set; }
        public string UNZIP_FG { get; set; }
        public string ZIP_PW { get; set; }
        public string FILE_AMT_NM { get; set; }
        public Nullable<decimal> TOLERANCE { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }

        public string FILE_GROUP { get; set; }
        public string CODEPAGE { get; set; }
        public string RAGGED_FIX { get; set; }
        public Nullable<int> RECORDLEN { get; set; }
        public Nullable<int> RAGGEDLEN { get; set; }
        public string DELIMITER { get; set; }
        public string TERMINATOR { get; set; }
        public Nullable<int> FIRSTROW { get; set; }
    }

    public partial class XFILEDETAIL_PrimaryKey
    {
        public string DATACAT { get; set; }
        public int FILE_SEQ { get; set; }
    }
}
