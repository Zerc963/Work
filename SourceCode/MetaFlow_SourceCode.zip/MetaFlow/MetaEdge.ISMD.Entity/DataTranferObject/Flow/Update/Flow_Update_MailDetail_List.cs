using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Update_MailDetail_List
    {
        public XMAILDETAIL_List_Data[] InsertMailDetail { get; set; }
        public XMAILDETAIL_List_Data_PrimaryKey[] DeleteMailDetail { get; set; }

        public bool FILEWAIT_Checked { get; set; }
        public bool FLOWTIME_Checked { get; set; }
        public XMONITOR_FILEWAIT XMONITOR_FILEWAIT { get; set; }
        public XMONITOR_FLOWTIME XMONITOR_FLOWTIME { get; set; }
    }

    public partial class XMAILDETAIL_List_Data_PrimaryKey
    {
        public string DATACAT { get; set; }
        public string MAILADR { get; set; }
    }
}
