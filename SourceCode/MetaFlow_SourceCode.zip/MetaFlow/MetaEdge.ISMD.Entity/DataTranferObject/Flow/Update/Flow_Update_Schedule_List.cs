using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Update_Schedule_List
    {
        public XSCHEDULE[] InsertDetail { get; set; }
        public XSCHEDULE_PrimaryKey[] DeleteDetail { get; set; }
    }

    public partial class XSCHEDULE_PrimaryKey
    {
        public string DATACAT { get; set; }
        public string PROCESS_TYPE { get; set; }
        public System.TimeSpan START_TIME { get; set; }
    }
}
