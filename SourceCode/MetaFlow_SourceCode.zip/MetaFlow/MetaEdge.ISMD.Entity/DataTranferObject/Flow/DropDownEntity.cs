using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class DropDownEntity
    {
        public string OptionText { get; set; }
        public string OptionValue { get; set; }
    }
}
