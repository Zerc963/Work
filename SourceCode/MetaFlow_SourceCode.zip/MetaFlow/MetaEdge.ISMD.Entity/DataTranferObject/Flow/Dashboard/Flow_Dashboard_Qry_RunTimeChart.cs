using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Dashboard_Qry_RunTimeChart
    {
        public string DATACAT { get; set; }
        public string RUN_TIME_TOTAL { get; set; }
        public string RUN_TIME { get; set; }
        public string LIGHTGROUP { get; set; }
    }
}
