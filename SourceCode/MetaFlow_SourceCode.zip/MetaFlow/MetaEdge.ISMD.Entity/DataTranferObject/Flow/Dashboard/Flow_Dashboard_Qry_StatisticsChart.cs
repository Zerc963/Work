using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class Flow_Dashboard_Qry_StatisticsChart
    {
        public string Name { get; set; }
        public string Value { get; set; }
        public string ToolTip { get; set; }
        public string Color { get; set; }
    }
}
