using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WSP_INS_XFlowagent
    {
        public WSP_INS_XFlowagentDetail[] Detail { get; set; }
    }

    public partial class WSP_INS_XFlowagentDetail
    {
        public string DATACAT { get; set; }
        public string CYCLEDATE { get; set; }
        public string START_MODE { get; set; }
        public string CREATE_USER { get; set; }
    }
}
