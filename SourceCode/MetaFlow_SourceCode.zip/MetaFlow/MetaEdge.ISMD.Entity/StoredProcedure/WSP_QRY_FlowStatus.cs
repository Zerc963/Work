using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WSP_QRY_FlowStatus
    {
        public string DATACAT { get; set; }
        public string DATACATNM { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public string CYCLEDATE { get; set; }
        public string START_TIME { get; set; }
        public string END_TIME { get; set; }
        public string START_MODE { get; set; }
        public string FLOW_STATUS { get; set; }
        public string NEXT_TIME { get; set; }
        public string RUN_TIME { get; set; }
        public decimal PROGRESS { get; set; }
        public string LIGHTBAR { get; set; }
        public string RUN_DESC { get; set; }
    }
}
