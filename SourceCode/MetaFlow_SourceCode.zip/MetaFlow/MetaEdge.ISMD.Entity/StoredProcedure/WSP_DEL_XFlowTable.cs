using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WSP_DEL_XFlowTable
    {
        public List<string> DATACAT { get; set; }
    }
}