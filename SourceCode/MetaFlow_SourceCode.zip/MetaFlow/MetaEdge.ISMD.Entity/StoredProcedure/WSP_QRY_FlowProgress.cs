using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WSP_QRY_FlowProgress
    {
        public string DATACAT { get; set; }
        public decimal PROGRESS { get; set; }
        public string LIGHTGROUP { get; set; }
    }
}
