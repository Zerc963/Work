using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XFLOWSTATUSHView
    {
        public string DATACAT { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public Nullable<System.DateTime> CYCLE_DATE { get; set; }
        public string RUN_STATUS { get; set; }
        public string RUN_STATUSNM { get; set; }
        public Nullable<System.DateTime> START_TIME { get; set; }
        public Nullable<System.DateTime> END_TIME { get; set; }
    }
}
