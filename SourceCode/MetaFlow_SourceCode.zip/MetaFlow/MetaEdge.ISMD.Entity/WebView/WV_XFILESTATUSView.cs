using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WV_XFILESTATUSView
    {
        public string DATACAT { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public Nullable<System.DateTime> CYCLE_START { get; set; }
        public Nullable<System.DateTime> CYCLE_END { get; set; }
        public string PROCESS_TYPE { get; set; }
        public string PROCESS_TYPENM { get; set; }
        public int FILE_SEQ { get; set; }
        public string RSEQ { get; set; }
        public string LSEQ { get; set; }
        public string FILENAME { get; set; }
        public string SRCNAME { get; set; }
        public string SRCCNAME { get; set; }
        public string PARENT_FILENAME { get; set; }
        public string SKIP_FLAG { get; set; }
        public string SKIP_FLAGNM { get; set; }
        public string NOT_EXIST_SKIP_FG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public string FILE_STATUS { get; set; }
        public string FILE_STATUSNM { get; set; }
        public Nullable<System.DateTime> FILE_START_TIME { get; set; }
        public Nullable<System.DateTime> FILE_END_TIME { get; set; }
        public string FILE_DESC { get; set; }
        public string CURR_SRCNAME { get; set; }
        public Nullable<long> FILESIZE { get; set; }
        public Nullable<System.DateTime> FILEDATE { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
        public string FILE_RUN_TIME { get; set; }
        public string CHGSRCNAME_FG { get; set; }
        public string CHGSRCNAME { get; set; }
        public string TOLERANCE_FG { get; set; }
        public string FILE_AMT_NM { get; set; }
        public decimal TOLERANCE { get; set; }
        public string CHK_FG { get; set; }
        public string UNZIP_FG { get; set; }
        public string CRT_FG { get; set; }
        public string ZIP_PW { get; set; }
        public int STATUS_LEVEL { get; set; }
    }
}
