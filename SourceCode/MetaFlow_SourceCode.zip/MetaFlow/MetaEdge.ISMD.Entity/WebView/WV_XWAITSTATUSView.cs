using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WV_XWAITSTATUSView
    {
        public string DATACAT { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public Nullable<System.DateTime> CYCLE_START { get; set; }
        public Nullable<System.DateTime> CYCLE_END { get; set; }
        public string PROCESS_TYPE { get; set; }
        public string PROCESS_TYPENM { get; set; }
        public int WAIT_SEQ { get; set; }
        public string WAIT_TYPE { get; set; }
        public string WAIT_TYPENM { get; set; }
        public string RSEQ { get; set; }
        public string LSEQ { get; set; }
        public string WAIT_NAME { get; set; }
        public string CHK_FG { get; set; }
        public string CHK_FILEDATE_FG { get; set; }
        public Nullable<int> TOLERANCE { get; set; }
        public string WAIT_SKIP_FLAG { get; set; }
        public string WAIT_SKIP_FLAGNM { get; set; }
        public string NOT_EXIST_SKIP_FG { get; set; }
        public string WAIT_STATUS { get; set; }
        public string WAIT_STATUSNM { get; set; }
        public Nullable<System.DateTime> WAIT_START_TIME { get; set; }
        public Nullable<System.DateTime> WAIT_END_TIME { get; set; }
        public string WAIT_DESC { get; set; }
        public Nullable<System.DateTime> FILEDATE { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
