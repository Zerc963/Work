using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class CB_DT
    {
        public System.DateTime DATADT { get; set; }
        public string Contry2Cd { get; set; }
        public string DT_CHAR { get; set; }
        public Nullable<int> WEEK_DY { get; set; }
        public Nullable<int> WEEK_NO { get; set; }
        public Nullable<int> YR { get; set; }
        public Nullable<int> MN { get; set; }
        public Nullable<int> DY_IN_MN { get; set; }
        public Nullable<int> DY_IN_YR { get; set; }
        public Nullable<int> SEASON { get; set; }
        public string SEMI_YR_NM { get; set; }
        public string HOLIDY_FG { get; set; }
        public Nullable<int> HOLIDY_DY { get; set; }
        public Nullable<System.DateTime> CYC_BEG { get; set; }
        public Nullable<System.DateTime> CYC_END { get; set; }
        public Nullable<int> DY_IN_BBOM { get; set; }
        public string BBOW_FG { get; set; }
        public string BEOW_FG { get; set; }
        public string BBOM_FG { get; set; }
        public string BEOM_FG { get; set; }
        public string BBOQ_FG { get; set; }
        public string BEOQ_FG { get; set; }
        public string BBOS_FG { get; set; }
        public string BEOS_FG { get; set; }
        public string BBOY_FG { get; set; }
        public string BEOY_FG { get; set; }
        public string EOM_FG { get; set; }
        public Nullable<System.DateTime> TBSDT { get; set; }
        public Nullable<System.DateTime> LBSDT { get; set; }
        public Nullable<System.DateTime> NBSDT { get; set; }
        public Nullable<System.DateTime> NNBSDT { get; set; }
        public Nullable<int> LBSDY { get; set; }
        public Nullable<int> NBSDY { get; set; }
        public Nullable<int> NNBZDY { get; set; }
        public Nullable<int> DYCNTEOM { get; set; }
        public Nullable<int> NDYCNTTM { get; set; }
        public Nullable<System.DateTime> L2MNBDT { get; set; }
        public Nullable<System.DateTime> L2MNEDT { get; set; }
        public Nullable<int> L2MNEDYS { get; set; }
        public Nullable<System.DateTime> LMNBDT { get; set; }
        public Nullable<System.DateTime> LMNEDT { get; set; }
        public Nullable<int> LMNDYS { get; set; }
        public Nullable<System.DateTime> TMNBDT { get; set; }
        public Nullable<System.DateTime> TMNEDT { get; set; }
        public Nullable<int> TMNDYS { get; set; }
        public Nullable<System.DateTime> FNBSDT { get; set; }
        public Nullable<System.DateTime> TQBDT { get; set; }
        public Nullable<System.DateTime> TQEDT { get; set; }
        public Nullable<int> TQDYS { get; set; }
        public Nullable<System.DateTime> L1QBDT { get; set; }
        public Nullable<System.DateTime> L1QEDT { get; set; }
        public Nullable<int> L1QDYS { get; set; }
        public Nullable<System.DateTime> L2QBDT { get; set; }
        public Nullable<System.DateTime> L2QEDT { get; set; }
        public Nullable<int> L2QDYS { get; set; }
        public Nullable<System.DateTime> L3QBDT { get; set; }
        public Nullable<System.DateTime> L3QEDT { get; set; }
        public Nullable<int> L3QDYS { get; set; }
        public Nullable<System.DateTime> L4QBDT { get; set; }
        public Nullable<System.DateTime> L4QEDT { get; set; }
        public Nullable<int> L4QDYS { get; set; }
        public Nullable<System.DateTime> L5QBDT { get; set; }
        public Nullable<System.DateTime> L5QEDT { get; set; }
        public Nullable<int> L5QDYS { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
