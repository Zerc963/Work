using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class CB_CHECK
    {
        public string DATACAT { get; set; }
        public Nullable<System.DateTime> CYCLEDATE { get; set; }
        public int SEQ { get; set; }
        public string SRCDATE { get; set; }
        public string SRCNAME { get; set; }
        public Nullable<decimal> SRC_CNT { get; set; }
        public string SRC_AMT_NM { get; set; }
        public Nullable<decimal> SRC_AMT { get; set; }
        public string ORGDATASRC { get; set; }
        public Nullable<System.DateTime> CREATE_DT { get; set; }
    }
}
