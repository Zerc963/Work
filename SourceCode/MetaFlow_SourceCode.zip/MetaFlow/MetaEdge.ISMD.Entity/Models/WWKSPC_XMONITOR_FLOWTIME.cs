using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WWKSPC_XMONITOR_FLOWTIME
    {
        public string DATACAT { get; set; }
        public int MAX_DURATION_TIME { get; set; }
        public Nullable<System.DateTime> START_TIME { get; set; }
        public Nullable<System.DateTime> EXPECT_END_TIME { get; set; }
        public Nullable<System.DateTime> CHK_TIME { get; set; }
        public string CHK_STATUS { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
