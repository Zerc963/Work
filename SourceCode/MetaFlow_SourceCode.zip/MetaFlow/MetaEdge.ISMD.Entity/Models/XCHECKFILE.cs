using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XCHECKFILE
    {
        public string DATACAT { get; set; }
        public System.DateTime CYCLEDATE { get; set; }
        public string SRCDATE { get; set; }
        public string FILENAME { get; set; }
        public string SRCNAME { get; set; }
        public Nullable<decimal> SRC_CNT { get; set; }
        public string FILE_AMT_NM { get; set; }
        public string SRC_AMT_NM { get; set; }
        public Nullable<decimal> SRC_AMT { get; set; }
        public Nullable<decimal> INS_CNT { get; set; }
        public Nullable<decimal> INS_AMT { get; set; }
        public Nullable<decimal> TOLERANCE { get; set; }
        public string CHECK_STATUS { get; set; }
        public string ORGDATASRC { get; set; }
    }
}
