using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WWKSPC_XSCHEDULE
    {
        public string DATACAT { get; set; }
        public string PROCESS_TYPE { get; set; }
        public System.TimeSpan START_TIME { get; set; }
        public Nullable<System.TimeSpan> END_TIME { get; set; }
        public Nullable<short> INTERVAL { get; set; }
        public Nullable<System.DateTime> EFFECTIVE_TIME { get; set; }
        public Nullable<System.DateTime> EXPIRATION_TIME { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
