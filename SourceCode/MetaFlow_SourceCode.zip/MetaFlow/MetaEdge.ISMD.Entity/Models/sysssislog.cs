using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class sysssislog
    {
        public int id { get; set; }
        public string @event { get; set; }
        public string computer { get; set; }
        public string @operator { get; set; }
        public string source { get; set; }
        public System.Guid sourceid { get; set; }
        public System.Guid executionid { get; set; }
        public System.DateTime starttime { get; set; }
        public System.DateTime endtime { get; set; }
        public int datacode { get; set; }
        public byte[] databytes { get; set; }
        public string message { get; set; }
    }
}
