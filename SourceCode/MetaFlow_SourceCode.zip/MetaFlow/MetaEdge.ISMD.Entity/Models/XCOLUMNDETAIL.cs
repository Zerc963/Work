using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XCOLUMNDETAIL
    {
        public string DB_NM { get; set; }
        public string SCHEMA_NM { get; set; }
        public string TABLE_NM { get; set; }
        public int COLUMN_SEQ { get; set; }
        public string COLUMN_NM { get; set; }
        public int COLUMN_LEN { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
