using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XMAILLIST
    {
        public decimal ID { get; set; }
        public string ContactAddress { get; set; }
        public string NotificationTitle { get; set; }
        public string Body { get; set; }
        public Nullable<long> MailID { get; set; }
        public string Attachment { get; set; }
        public string ExecDesc { get; set; }
    }
}
