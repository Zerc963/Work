using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XLOCALDETAIL
    {
        public string DATACAT { get; set; }
        public string LSEQ { get; set; }
        public string LOCAL_PATH { get; set; }
        public string WORK_PATH { get; set; }
        public string BACKUP_PATH { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
