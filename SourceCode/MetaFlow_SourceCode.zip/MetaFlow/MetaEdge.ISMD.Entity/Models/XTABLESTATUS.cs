using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XTABLESTATUS
    {
        public string DBNAME { get; set; }
        public string TABLENAME { get; set; }
        public Nullable<System.DateTime> CYCLEDATE { get; set; }
        public Nullable<System.DateTime> LSTMODIFYDT { get; set; }
    }
}
