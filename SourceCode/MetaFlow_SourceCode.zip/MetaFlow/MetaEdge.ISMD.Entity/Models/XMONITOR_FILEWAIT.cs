using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XMONITOR_FILEWAIT
    {
        public string DATACAT { get; set; }
        public string START_TIME { get; set; }
        public string END_TIME { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
