using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WWKSPC_XREMOTEDETAIL
    {
        public string DATACAT { get; set; }
        public string RSEQ { get; set; }
        public string SERVERTYPE { get; set; }
        public string SERVERNM { get; set; }
        public string USERCODE { get; set; }
        public string REMOTE_PATH { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
