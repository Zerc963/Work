using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WWKSPC_XFLATFILEDETAIL
    {
        public string DATACAT { get; set; }
        public int FILE_SEQ { get; set; }
        public string FILE_GROUP { get; set; }
        public string CODEPAGE { get; set; }
        public string RAGGED_FIX { get; set; }
        public Nullable<int> RECORDLEN { get; set; }
        public Nullable<int> RAGGEDLEN { get; set; }
        public string DELIMITER { get; set; }
        public string TERMINATOR { get; set; }
        public Nullable<int> FIRSTROW { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
