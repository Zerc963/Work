using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WV_XBATCHFLOW
    {
        public string DATACAT { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public Nullable<System.DateTime> CYCLE_START { get; set; }
        public Nullable<System.DateTime> CYCLE_END { get; set; }
        public string PROCESS_TYPE { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
        public string JOB_NAME { get; set; }
        public string START_MODE { get; set; }
        public Nullable<System.DateTime> JOB_START_TIME { get; set; }
        public Nullable<System.DateTime> JOB_END_TIME { get; set; }
        public string RUN_STATUS { get; set; }
        public Nullable<decimal> INS_CNT { get; set; }
        public Nullable<decimal> UPD_CNT { get; set; }
        public Nullable<decimal> DEL_CNT { get; set; }
        public string SRC_TB { get; set; }
        public string TGT_TB { get; set; }
        public string PARAM { get; set; }
        public string SKIP_FLAG { get; set; }
        public string FORK_FLAG { get; set; }
        public string ABORTCONTINUE_FLAG { get; set; }
        public string JOB_TYPE { get; set; }
        public string JOB_DESC { get; set; }
        public string JOB_LOCATION { get; set; }
        public string JOB_OWNER { get; set; }
        public string EXEC_DESC { get; set; }
        public string EXECUTION_ID { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
        public string JOB_RUN_TIME { get; set; }
        public Nullable<int> JOB_SECOND { get; set; }
        public string JOB_LEVEL { get; set; }
        public Nullable<Int64> RUN_SEQ { get; set; }
        public string JOB_STAGE_REF { get; set; }
    }
}
