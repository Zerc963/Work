using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WWKSPC_XMAILDETAIL
    {
        public string DATACAT { get; set; }
        public string MAIL_TYPE { get; set; }
        public string MAILADR { get; set; }
        public string MAIL_DESC { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }

        public WWKSPC_XMAILDETAIL() { 
        }

        public WWKSPC_XMAILDETAIL(string DATACAT, string MAIL_TYPE, string MAILADR, string MAIL_DESC, string LST_MAINT_USR, Nullable<System.DateTime> LST_MAINT_DT)
        {
            this.DATACAT = DATACAT;
            this.MAIL_TYPE = MAIL_TYPE;
            this.MAILADR = MAILADR;
            this.MAIL_DESC = MAIL_DESC;
            this.LST_MAINT_USR = LST_MAINT_USR;
            this.LST_MAINT_DT = LST_MAINT_DT;
        }
    }
}
