using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WJOBITEM
    {
        public string JOB_NAME { get; set; }
        public string JOB_TYPE { get; set; }
        public string JOB_LOCATION { get; set; }
        public string JOB_OWNER { get; set; }
        public string TOOL_FG { get; set; }
        public string MANUAL_FG { get; set; }
        public string DISABLE_FG { get; set; }
        public string JOB_DESC { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
