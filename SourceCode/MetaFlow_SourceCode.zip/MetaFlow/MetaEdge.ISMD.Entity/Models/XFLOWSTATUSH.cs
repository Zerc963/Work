using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XFLOWSTATUSH
    {
        public string DATACAT { get; set; }
        public Nullable<long> BATCH_NO { get; set; }
        public Nullable<System.DateTime> CYCLE_START { get; set; }
        public Nullable<System.DateTime> CYCLE_END { get; set; }
        public string START_MODE { get; set; }
        public string RUN_STATUS { get; set; }
        public Nullable<System.DateTime> START_TIME { get; set; }
        public Nullable<System.DateTime> RESTART_TIME { get; set; }
        public Nullable<System.DateTime> END_TIME { get; set; }
        public string RUN_DESC { get; set; }
        public string EXECUTION_ID { get; set; }
        public Nullable<System.DateTime> NEXT_TIME { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
