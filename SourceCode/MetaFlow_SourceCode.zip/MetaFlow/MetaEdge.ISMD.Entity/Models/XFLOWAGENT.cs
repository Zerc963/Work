using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XFLOWAGENT
    {
        public string DATACAT { get; set; }
        public string CYCLEDATE { get; set; }
        public string START_MODE { get; set; }
        public string CREATE_USER { get; set; }
        public Nullable<System.DateTime> CREATE_DT { get; set; }
    }
}
