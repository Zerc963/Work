using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XPROCESSFLOW
    {
        public string DATACAT { get; set; }
        public int PROCESS_ID { get; set; }
        public System.DateTime START_TIME { get; set; }
        public string CLEAN_FG { get; set; }
        public string EXECUTION_ID { get; set; }
    }
}
