using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XTABLETRACK
    {
        public string DATACAT { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
        public Nullable<System.DateTime> CYCLEDATE { get; set; }
        public string TGT_DB { get; set; }
        public string TGT_TB { get; set; }
        public Nullable<System.DateTime> LSTMODIFYDT { get; set; }
    }
}
