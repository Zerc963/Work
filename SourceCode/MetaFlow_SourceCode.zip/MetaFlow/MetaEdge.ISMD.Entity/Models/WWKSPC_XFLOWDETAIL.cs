using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class WWKSPC_XFLOWDETAIL
    {
        public string DATACAT { get; set; }
        public string FLOW_TYPE { get; set; }
        public string DATACATNM { get; set; }
        public string DT_TYPE { get; set; }
        public Nullable<byte> DT_CHG_HR { get; set; }
        public string CYC_RERUN_FG { get; set; }
        public string CURR_CYC_FG { get; set; }
        public Nullable<byte> RETRY_TIMES { get; set; }
        public Nullable<int> ABORT_RESTART_INTERVAL { get; set; }
        public Nullable<int> ABORT_NOTIFY_SKIP_TIMES { get; set; }
        public string AGENT_MODE { get; set; }
        public string LOCAL_MODE { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
