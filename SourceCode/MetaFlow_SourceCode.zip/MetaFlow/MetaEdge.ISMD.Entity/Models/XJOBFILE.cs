using System;
using System.Collections.Generic;

namespace MetaEdge.ISMD.Entity.Models
{
    public partial class XJOBFILE
    {
        public string JOB_DATACAT { get; set; }
        public string JOB_STAGE { get; set; }
        public int JOB_FLOW { get; set; }
        public int JOB_SEQ { get; set; }
        public string FILE_DATACAT { get; set; }
        public int FILE_SEQ { get; set; }
        public string NOT_EXIST_SKIP_FG { get; set; }
        public string LST_MAINT_USR { get; set; }
        public Nullable<System.DateTime> LST_MAINT_DT { get; set; }
    }
}
