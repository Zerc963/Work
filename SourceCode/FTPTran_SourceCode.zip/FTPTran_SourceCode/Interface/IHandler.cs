﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    internal interface IHandler
    {
        IHandler SetNext(IHandler handler);

        void Handle(Step Step);
    }
}
