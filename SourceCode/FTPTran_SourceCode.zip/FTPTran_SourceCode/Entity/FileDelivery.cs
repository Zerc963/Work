﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 第一階段GET DATA傳回來的物件
    /// </summary>
    internal class FileDelivery
    {
        internal FileDelivery(string PROCESS_TYPE, string BOOT, string ACTIVE_START_DATE, string ACTIVE_END_DATE, string SOURCEIDR, string FileName, string FILE_TYPE, string WAIT_DATACAT, string SERVERNAME)
        {
            this.PROCESS_TYPE = PROCESS_TYPE;
            this.BOOT = BOOT;
            this.ACTIVE_START_DATE = ACTIVE_START_DATE;
            this.ACTIVE_END_DATE = ACTIVE_END_DATE;
            this.SOURCEDIR = SOURCEIDR;
            this.FileName = FileName;
            this.FILE_TYPE = FILE_TYPE;
            this.WAIT_DATACAT = WAIT_DATACAT;
            this.SERVERNAME = SERVERNAME;
        }

        internal string PROCESS_TYPE { get; set; }
        internal string BOOT { get; set; }
        internal string ACTIVE_START_DATE { get; set; }
        internal string ACTIVE_END_DATE { get; set; }
        internal string SOURCEDIR { get; set; }
        internal string FileName { get; set; }
        internal string FILE_TYPE { get; set; }
        internal string WAIT_DATACAT { get; set; }
        internal string SERVERNAME { get; set; }
    }
}
