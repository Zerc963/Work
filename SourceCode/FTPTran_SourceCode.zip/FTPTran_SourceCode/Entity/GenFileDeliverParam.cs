﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 第三階段參數
    /// </summary>
    internal class GenFileDeliverParam
    {
        internal string SERVERNAME { get; set; }
        internal string FILENAME { get; set; }
        internal string CycleDate { get; set; }
        internal GenFileParam GenFileParam { get; set; }
        internal SqlConnection CONN { get; set; }
        internal string HOSTNAME { get; set; }
        internal string FILESDT { get; set; }
        internal string FILEEDT { get; set; }
        internal SRVFG SRVFG { get; set; }
        internal string SERVERIP { get; set; }
    }
}
