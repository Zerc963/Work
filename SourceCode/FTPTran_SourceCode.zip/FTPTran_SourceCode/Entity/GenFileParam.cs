﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 第三階段Get FileList傳回來的物件
    /// </summary>
    internal class GenFileParam
    {
        internal GenFileParam(string FILENAME, string DB_NAME, string TABLE_NAME, string PROCESS_TYPE, string REFRESH_TYPE, string SEPARATOR, string SOURCEDIR, string ACTIVE_START_DATE, string WAIT_DATACAT, string FILE_TYPE, string RUN_STATUS, string SRVNM, string DATE_COLNM)
        {
            this.FILENAME = FILENAME;
            this.DB_NAME = DB_NAME;
            this.TABLE_NAME = TABLE_NAME;
            this.PROCESS_TYPE = PROCESS_TYPE;
            this.REFRESH_TYPE = REFRESH_TYPE;
            this.SEPARATOR = SEPARATOR;
            this.SOURCEDIR = SOURCEDIR;
            this.ACTIVE_START_DATE = ACTIVE_START_DATE;
            this.WAIT_DATACAT = WAIT_DATACAT;
            this.FILE_TYPE = FILE_TYPE;
            this.RUN_STATUS = RUN_STATUS;
            this.SRVNM = SRVNM;
            this.DATE_COLNM = DATE_COLNM;
        }

        public string FILENAME { get; set; }
        public string DB_NAME { get; set; }
        public string TABLE_NAME { get; set; }
        public string PROCESS_TYPE { get; set; }
        public string REFRESH_TYPE { get; set; }
        public string SEPARATOR { get; set; }
        public string SOURCEDIR { get; set; }
        public string ACTIVE_START_DATE { get; set; }
        public string WAIT_DATACAT { get; set; }
        public string FILE_TYPE { get; set; }
        public string RUN_STATUS { get; set; }
        public string SRVNM { get; set; }
        public string DATE_COLNM { get; set; }
    }
}
