﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    internal static class FTPValue
    {
        internal static readonly string FILENAME = "FILENAME";
        internal static readonly string SERVERNAME = "SERVERNAME";
        internal static readonly string SOURCEDIR = "SOURCEDIR";
        internal static readonly string BOOT = "BOOT";
        internal static readonly string FILE_TYPE = "FILE_TYPE";
        internal static readonly string PROCESS_TYPE = "PROCESS_TYPE";
        internal static readonly string SERVERIP = "SERVERIP";
        internal static readonly string USERNAME = "USERNAME";
        internal static readonly string PW = "PW";
        internal static readonly string FTPFILEDIR = "FTPFILEDIR";
        internal static readonly string WAIT_DATACAT = "WAIT_DATACAT";
        internal static readonly string RUN_STATUS = "RUN_STATUS";
        internal static readonly string ACTIVE_START_DATE = "ACTIVE_START_DATE";
    }
}
