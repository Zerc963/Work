﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    public static class Utility
    {
        //static internal string DefaultPath = @"D:\FILETRANS\";
        static internal string DefaultPath = @"C:\FILETRANS\";

        static internal bool IsFTPProcessStart = false;
        
        static internal byte[] byteArr =  { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 };

        public static string[] GetFieldNames(SqlDataReader reader)
        {
            return Enumerable.Range(0, reader.FieldCount).Select(x => reader.GetName(x)).ToArray();
        }
    }
}
