﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    internal static class SPExecutor
    {
        internal static SqlCommand PreSpProcess(string spName, Dictionary<string, string> spParameter, SqlConnection db)
        {
            SqlCommand cmd = new SqlCommand(spName, db);
            cmd.CommandType = CommandType.StoredProcedure;
            foreach (var dicItem in spParameter)
            {
                cmd.Parameters.Add(dicItem.Key, SqlDbType.NVarChar, -1);
                cmd.Parameters[dicItem.Key].Value = dicItem.Value;
            }
            return cmd;
        }

        internal static Dictionary<string, string> ExecuteSPWithRtValue(string spName, Dictionary<string, string> spParameter, SqlConnection conn)
        {
            Dictionary<string, string> returnValue = new Dictionary<string, string>();
            var cmd = PreSpProcess(spName, spParameter, conn);
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);
                if (reader.HasRows)
                {
                    reader.Read();
                    for (int col = 0; col < reader.FieldCount; col++)
                    {
                        returnValue.Add(reader.GetName(col).ToString(), reader[col].ToString());
                    }
                }
                reader.Close();
                return returnValue;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return returnValue;
        }

        internal static string ExecuteSPWithStrValue(string spName, Dictionary<string, string> spParameter, SqlConnection conn)
        {
            string result = default(string);
            Dictionary<string, string> returnValue = new Dictionary<string, string>();
            var cmd = PreSpProcess(spName, spParameter, conn);
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();
                    result = reader[0] + "";
                    Console.WriteLine(reader[0]);
                }
                reader.Close();
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return result;
        }

        internal static Dictionary<string,string> ExecuteSPWithDictValue(string spName, Dictionary<string, string> spParameter, SqlConnection connection)
        {
            Dictionary<string, string> dict = new Dictionary<string,string>();
            Dictionary<string, string> returnValue = new Dictionary<string, string>();
            var cmd = PreSpProcess(spName, spParameter, connection);
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();
                    dict.Add((string)reader[0],(string)reader[1]);
                    dict.Add(dict.Count().ToString() + 1, reader[1].ToString().Replace(".D",".H"));
                }
                reader.Close();
                return dict;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return dict;
        }

        internal static Dictionary<string,string> ExecuteSPWithDT(string spName, Dictionary<string, string> spParameter, SqlConnection connection)
        {
            Dictionary<string, string> dict = new Dictionary<string,string>();
            Dictionary<string, string> returnValue = new Dictionary<string, string>();
            var cmd = PreSpProcess(spName, spParameter, connection);
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();

                    dict.Add("FILESDT", (string)reader["FILESDT"]);
                    dict.Add("FILEEDT", (string)reader["FILEEDT"]);
                }
                reader.Close();
                return dict;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return dict;
        }
        internal static GenFileParam ExecuteSPWithGenFileValue(string spName, Dictionary<string, string> spParameter, SqlConnection connection)
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();
            Dictionary<string, string> returnValue = new Dictionary<string, string>();
            GenFileParam genFLPam = default(GenFileParam);
            var cmd = PreSpProcess(spName, spParameter, connection);
            try
            {
                SqlDataReader reader = cmd.ExecuteReader(CommandBehavior.SingleRow);

                if (reader.HasRows)
                {
                    reader.Read();
                    string[] nameList = Utility.GetFieldNames(reader);
                    genFLPam = new GenFileParam((string)reader[Array.IndexOf(nameList, GenFileValue.FILENAME)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.DB_NAME)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.TABLE_NAME)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.PROCESS_TYPE)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.REFRESH_TYPE)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.SEPARATOR)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.SOURCEDIR)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.ACTIVE_START_DATE)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.WAIT_DATACAT)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.FILE_TYPE)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.RUN_STATUS)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.SRVNM)],
                                                     (string)reader[Array.IndexOf(nameList, GenFileValue.DATE_COLNM)]);
                }
                reader.Close();
                return genFLPam;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return null;
        }
    }
}
