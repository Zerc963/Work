﻿#define useDB
#if useDB
#elif useConfig
#endif

using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第三階段Update Status to GenFileing到Judge Server Name
    /// </summary>
    internal class DFileHandler : AbstractHandler
    {
        internal GenFileDeliverParam GenFileDeliverParam { get; set; }
        private string DFilePath { get; set; }
        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(DFileHandler));

        internal DFileHandler(GenFileDeliverParam GenFileDeliverParam)
        {
            this.GenFileDeliverParam = GenFileDeliverParam;
        }

        public override void Handle(Step step)
        {
            if (step == Step.Second)
            {
                XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));

                DoUpdateStatusToGenFilINGSP();
                TxtLog.Info("執行第三階段: Update Status GenFilling 成功");
                GenerateDFile();
                if (File.Exists(DFilePath))
                    TxtLog.Info("執行第三階段: GENERATE D FILE 成功。 DFilePath為 " + DFilePath);
                else
                    TxtLog.Error("執行第三階段: GENERATE D FILE 沒成功。 " + DFilePath + " 不存在");
                GenFileDeliverParam.SRVFG = (SRVFG)Convert.ToInt32(DoJudgeServerNameSP());
                TxtLog.Info("執行第三階段: Judge Server Name 成功");
                TxtLog.Info("執行第三階段: SRVFG = " + GenFileDeliverParam.SRVFG);
            }
            else
                base.Handle(step);
        }

        public static string Decrypt(string cipherText, byte[] byteArr)
        {
            string EncryptionKey = "MetaEdge";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new
                    Rfc2898DeriveBytes(EncryptionKey, byteArr);
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        /// <summary>
        /// Update Status to GenFileing
        /// </summary>
        private void DoUpdateStatusToGenFilINGSP()
        {
            TxtLog.Info("執行第三階段: Update Status GenFilling");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", GenFileDeliverParam.FILENAME);
            dict.Add("@SERVERNAME", GenFileDeliverParam.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_Status_To_GenFiling", dict, GenFileDeliverParam.CONN);
        }

        /// <summary>
        /// Judge Server Name
        /// </summary>
        /// <returns></returns>
        private string DoJudgeServerNameSP()
        {
            TxtLog.Info("執行第三階段: Judge Server Name");

            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", GenFileDeliverParam.FILENAME);
            dict.Add("@SERVERNAME", GenFileDeliverParam.SERVERNAME);
            dict.Add("@HOSTNAME", Environment.MachineName.ToUpper());
            return SPExecutor.ExecuteSPWithStrValue("USP_TRAN_Judge_Server_Name", dict, GenFileDeliverParam.CONN);
        }

        /// <summary>
        /// GENERATE D FILE
        /// </summary>
        private void GenerateDFile()
        {

            TxtLog.Info("執行第三階段: GENERATE D FILE");

            string SRV_UserName = (string)(new AppSettingsReader().GetValue("SRV_UserName", typeof(string)));
            string SRV_PW = Decrypt((string)(new AppSettingsReader().GetValue("SRV_PW", typeof(string))), Utility.byteArr);
            string PROCESS_TYPE = GenFileDeliverParam.GenFileParam.PROCESS_TYPE;
            string AllPath = default(string);

            if (PROCESS_TYPE.Trim() == "D" || PROCESS_TYPE.Trim() == "E")
            {
#if useDB
                AllPath = GenFileDeliverParam.GenFileParam.SOURCEDIR  + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "."  + GenFileDeliverParam.CycleDate.Trim() + ".D";
#elif useConfig
                AllPath = Utility.DefaultPath + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".D";
#endif
            }
            else
            {
#if useDB
                AllPath = GenFileDeliverParam.GenFileParam.SOURCEDIR + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".D";
#elif useConfig
                AllPath = Utility.DefaultPath  + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".D";
#endif
            }
            DFilePath = AllPath;
            Process p = new Process();
            string CmdParameters = string.Empty;
            string HostName = Environment.MachineName.ToUpper();
            if (GenFileDeliverParam.GenFileParam.SRVNM == HostName)
            {
                if (GenFileDeliverParam.GenFileParam.REFRESH_TYPE.Trim() == "C")
                {
                    CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + "= '" + GenFileDeliverParam.CycleDate.Trim() + "\' \" QUERYOUT " + AllPath + " -T -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim();
                    TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                }
                else
                {
                    CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + " = SUBSTRING(  '" + GenFileDeliverParam.FILESDT.Trim() + "', 1, 6) + '01' \" QUERYOUT \"" + AllPath + "\" -T -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim();
                    TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                }
            }
            else
            {
                if (GenFileDeliverParam.GenFileParam.REFRESH_TYPE.Trim() == "C")
                {
                    CmdParameters = "BCP " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " OUT \"\"" + AllPath + "\"\" -S " + GenFileDeliverParam.GenFileParam.SRVNM.Trim() + " -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim() + " -U" + SRV_UserName.Trim() + " -P" + SRV_PW.Trim();
                    TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                }
                else
                {
                    if (PROCESS_TYPE == "D" || PROCESS_TYPE == "E")
                    {
                        CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + " = \'" + GenFileDeliverParam.CycleDate.Trim() + "\' \" QUERYOUT \"" + AllPath + "\" -S" + GenFileDeliverParam.GenFileParam.SRVNM.Trim() + " -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim() + " -U" + SRV_UserName.Trim() + " -P" + SRV_PW.Trim();
                        TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                    }
                    else
                    {
                        CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + "= SUBSTRING('" + GenFileDeliverParam.FILESDT.Trim() + "', 1, 6) + '01' \" QUERYOUT \"" + AllPath + "\" -S" + GenFileDeliverParam.GenFileParam.SRVNM.Trim() + " -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim() + " -U" + SRV_UserName.Trim() + " -P" + SRV_PW.Trim();
                        TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                    }
                }
                TxtLog.Info("執行第三階段: CmdParameters = " + CmdParameters);
                TxtLog.Info("執行第三階段: AllPath = " + AllPath);
                p.StartInfo.FileName = "cmd.exe";
                p.StartInfo.Arguments = "/c " + CmdParameters;

                p.StartInfo.UseShellExecute = false;

                p.StartInfo.RedirectStandardError = true;

                p.StartInfo.CreateNoWindow = true;

                p.Start();

                p.WaitForExit();
            }
        }
    }
}
