﻿#define useDB
#if useDB
#elif useConfig
#endif

using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第三階段Update Status to GenFileing到Judge Server Name
    /// </summary>
    internal class DFileHandler : AbstractHandler
    {
        internal GenFileDeliverParam GenFileDeliverParam { get; set; }
        private string DFilePath { get; set; }
        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(DFileHandler));

        internal DFileHandler(GenFileDeliverParam GenFileDeliverParam)
        {
            this.GenFileDeliverParam = GenFileDeliverParam;
        }

        public override void Handle(Step step)
        {
            if (step == Step.Second)
            {
                XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));

                DoUpdateStatusToGenFilINGSP();
                TxtLog.Info("執行第三階段: Update Status GenFilling 成功");
                GenerateDFile();
                if (File.Exists(DFilePath))
                    TxtLog.Info("執行第三階段: GENERATE D FILE 成功。 DFilePath為 " + DFilePath);
                else
                    TxtLog.Error("執行第三階段: GENERATE D FILE 沒成功。 " + DFilePath + " 不存在");
                GenFileDeliverParam.SRVFG = (SRVFG)Convert.ToInt32(DoJudgeServerNameSP());
                TxtLog.Info("執行第三階段: Judge Server Name 成功");
                TxtLog.Info("執行第三階段: SRVFG = " + GenFileDeliverParam.SRVFG);
            }
            else
                base.Handle(step);
        }

        private byte[] HashByMD5(string source)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

            return md5.ComputeHash(Encoding.UTF8.GetBytes(source));
        }

        private string DecryptByDES(string encrypted, string key, string iv)
        {
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();

            // Rfc2898DeriveBytes 類別可以用來從基底金鑰與其他參數中產生衍生金鑰。
            // 使用 MD5 來 Hash 出 Rfc2898 需要的 Salt。
            Rfc2898DeriveBytes rfc2898 = new Rfc2898DeriveBytes(key, HashByMD5(key));

            // 8 bits = 1 byte，將 KeySize 及 BlockSize 個別除以 8，取得 Rfc2898 產生衍生金鑰的長度。
            des.Key = rfc2898.GetBytes(des.KeySize / 8);
            des.IV = rfc2898.GetBytes(des.BlockSize / 8);

            var dataByteArray = Convert.FromBase64String(encrypted);

            // 解密
            using (MemoryStream ms = new MemoryStream())
            using (CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write))
            {
                cs.Write(dataByteArray, 0, dataByteArray.Length);
                cs.FlushFinalBlock();

                return Encoding.UTF8.GetString(ms.ToArray());
            }

            // 或
            var decryped = des.CreateDecryptor().TransformFinalBlock(dataByteArray, 0, dataByteArray.Length);

            return Encoding.UTF8.GetString(decryped);
        }

        /// <summary>
        /// Update Status to GenFileing
        /// </summary>
        private void DoUpdateStatusToGenFilINGSP()
        {
            TxtLog.Info("執行第三階段: Update Status GenFilling");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", GenFileDeliverParam.FILENAME);
            dict.Add("@SERVERNAME", GenFileDeliverParam.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_Status_To_GenFiling", dict, GenFileDeliverParam.CONN);
        }

        /// <summary>
        /// Judge Server Name
        /// </summary>
        /// <returns></returns>
        private string DoJudgeServerNameSP()
        {
            TxtLog.Info("執行第三階段: Judge Server Name");

            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", GenFileDeliverParam.FILENAME);
            dict.Add("@SERVERNAME", GenFileDeliverParam.SERVERNAME);
            dict.Add("@HOSTNAME", Environment.MachineName.ToUpper());
            return SPExecutor.ExecuteSPWithStrValue("USP_TRAN_Judge_Server_Name", dict, GenFileDeliverParam.CONN);
        }

        /// <summary>
        /// GENERATE D FILE
        /// </summary>
        private void GenerateDFile()
        {

            TxtLog.Info("執行第三階段: GENERATE D FILE");
            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            fileMap.ExeConfigFilename = "../../App.config";
            Configuration configuration = System.Configuration.ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);

            string SRV_UserName = configuration.AppSettings.Settings["SRV_UserName"].Value;
            string SRV_PW = DecryptByDES(configuration.AppSettings.Settings["SRV_PW"].Value, "password", "iv");
            string PROCESS_TYPE = GenFileDeliverParam.GenFileParam.PROCESS_TYPE;
            string AllPath = default(string);

            if (PROCESS_TYPE.Trim() == "D" || PROCESS_TYPE.Trim() == "E")
            {
#if useDB
                AllPath = GenFileDeliverParam.GenFileParam.SOURCEDIR  + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "."  + GenFileDeliverParam.CycleDate.Trim() + ".D";
#elif useConfig
                AllPath = Utility.DefaultPath + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".D";
#endif
            }
            else
            {
#if useDB
                AllPath = GenFileDeliverParam.GenFileParam.SOURCEDIR + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".D";
#elif useConfig
                AllPath = Utility.DefaultPath  + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".D";
#endif
            }
            DFilePath = AllPath;
            Process p = new Process();
            string CmdParameters = string.Empty;
            string HostName = Environment.MachineName.ToUpper();
            if (GenFileDeliverParam.GenFileParam.SRVNM == HostName)
            {
                if (GenFileDeliverParam.GenFileParam.REFRESH_TYPE.Trim() == "C")
                {
                    CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + "= '" + GenFileDeliverParam.CycleDate.Trim() + "\' \" QUERYOUT " + AllPath + " -T -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim();
                    TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                }
                else
                {
                    CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + " = SUBSTRING(  '" + GenFileDeliverParam.FILESDT.Trim() + "', 1, 6) + '01' \" QUERYOUT \"" + AllPath + "\" -T -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim();
                    TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                }
            }
            else
            {
                if (GenFileDeliverParam.GenFileParam.REFRESH_TYPE.Trim() == "C")
                {
                    CmdParameters = "BCP " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " OUT \"\"" + AllPath + "\"\" -S " + GenFileDeliverParam.GenFileParam.SRVNM.Trim() + " -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim() + " -U" + SRV_UserName.Trim() + " -P" + SRV_PW.Trim();
                    TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                }
                else
                {
                    if (PROCESS_TYPE == "D" || PROCESS_TYPE == "E")
                    {
                        CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + " = \'" + GenFileDeliverParam.CycleDate.Trim() + "\' \" QUERYOUT \"" + AllPath + "\" -S" + GenFileDeliverParam.GenFileParam.SRVNM.Trim() + " -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim() + " -U" + SRV_UserName.Trim() + " -P" + SRV_PW.Trim();
                        TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                    }
                    else
                    {
                        CmdParameters = "BCP \"SELECT * FROM " + GenFileDeliverParam.GenFileParam.DB_NAME.Trim() + ".dbo." + GenFileDeliverParam.GenFileParam.TABLE_NAME.Trim() + " WHERE " + GenFileDeliverParam.GenFileParam.DATE_COLNM.Trim() + "= SUBSTRING('" + GenFileDeliverParam.FILESDT.Trim() + "', 1, 6) + '01' \" QUERYOUT \"" + AllPath + "\" -S" + GenFileDeliverParam.GenFileParam.SRVNM.Trim() + " -c -t" + GenFileDeliverParam.GenFileParam.SEPARATOR.Trim() + " -U" + SRV_UserName.Trim() + " -P" + SRV_PW.Trim();
                        TxtLog.Info("執行第三階段: BCP = " + CmdParameters);
                    }
                }
                TxtLog.Info("執行第三階段: CmdParameters = " + CmdParameters);
                TxtLog.Info("執行第三階段: AllPath = " + AllPath);
                p.StartInfo.FileName = "cmd.exe";
                p.StartInfo.Arguments = "/c " + CmdParameters;

                p.StartInfo.UseShellExecute = false;

                p.StartInfo.RedirectStandardError = true;

                p.StartInfo.CreateNoWindow = true;

                p.Start();

                p.WaitForExit();
            }
        }
    }
}
