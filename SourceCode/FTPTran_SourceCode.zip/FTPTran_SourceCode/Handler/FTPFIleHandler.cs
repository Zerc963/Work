﻿#define useDB
#if useDB
#elif useConfig
#endif


using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第二階段(FTP)Judge IF GenFile到Get FTPFile
    /// </summary>
    internal class FTPFIleHandler : AbstractHandler
    {
        internal FTPDBParameter FTPDBParameter { get; set; }

        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(FileHandler));

        internal FTPFIleHandler(FTPDBParameter FTPDBParameter)
        {
            this.FTPDBParameter = FTPDBParameter;
        }

        public override void Handle(Step step)
        {
            XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));

            if (step == Step.Second)
            {
                int isGenFile = DoJudgeGenFile();
                TxtLog.Info("執行第二階段: Judge IF GenFile 成功");
                TxtLog.Info("執行第二階段: @GENFG = " + isGenFile);

                if (isGenFile == (int)GenFile.True)
                {
                    string FileFg = JudgeFileExistFTP();

                    TxtLog.Info("執行第二階段: Judge File Exist 成功");
                    TxtLog.Info("執行第二階段: @FileFg = " + FileFg);

                    if (FileFg == FileFGEnum.N.ToString())
                    {
                        //執行第三步驟
                        TxtLog.Info("開始執行第三階段");
                        GenFileDeliverParam GenFileDeliverParam = new GenFileDeliverParam();
                        GenFileDeliverParam.FILENAME = FTPDBParameter.FTPParam.FILENAME;
                        GenFileDeliverParam.SERVERNAME = FTPDBParameter.FTPParam.SERVERNAME;
                        GenFileDeliverParam.CycleDate = FTPDBParameter.CycleDate;
                        GenFileDeliverParam.CONN = FTPDBParameter.conn;
                        GenFileDeliverParam.SERVERIP = FTPDBParameter.FTPParam.SERVERIP;
                        FinalSetFGHandler flSetHandler = new FinalSetFGHandler(GenFileDeliverParam);
                        DFileHandler dFilerHandler = new DFileHandler(GenFileDeliverParam);
                        HFileHandler hFileHandler = new HFileHandler(GenFileDeliverParam);
                        flSetHandler.SetNext(dFilerHandler).SetNext(hFileHandler);
                        DeliverExecutor.Execute(flSetHandler);
                        TxtLog.Info("等候十秒");
                        Thread.Sleep(10000);
                        FTPDBParameter.FTPFILENM = DoGetFTPFileSP();
                        new FTPFinalFileHandler(this.FTPDBParameter).Handle(Step.Third);
                    }
                    else if (FileFg == FileFGEnum.Y.ToString())
                    {
                        FTPDBParameter.FTPFILENM = DoGetFTPFileSP();
                        new FTPFinalFileHandler(this.FTPDBParameter).Handle(Step.Third);
                    }
                }
                else if (isGenFile == (int)GenFile.False)
                {
                    FTPDBParameter.FTPFILENM = DoGetFTPFileSP();
                    new FTPFinalFileHandler(this.FTPDBParameter).Handle(Step.Third);
                }
            }
        }

        /// <summary>
        /// 執行Judge IF GenFile
        /// </summary>
        /// <returns></returns>
        private int DoJudgeGenFile()
        {
            TxtLog.Info("執行第二階段: Judge IF GenFile");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", FTPDBParameter.FTPParam.FILENAME);
            return Convert.ToInt32(SPExecutor.ExecuteSPWithStrValue("USP_TRAN_Judge_Gen_File", dict, FTPDBParameter.conn));
        }

        /// <summary>
        /// 執行Get FTPFile sp
        /// </summary>
        /// <returns></returns>
        private Dictionary<string,string> DoGetFTPFileSP()
        {
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", FTPDBParameter.FTPParam.FILENAME);
            dict.Add("@CycleDate", FTPDBParameter.CycleDate);
            return SPExecutor.ExecuteSPWithDictValue("USP_TRAN_Get_FTP_File", dict, FTPDBParameter.conn);
        }

        /// <summary>
        /// 執行Judge File Exist
        /// </summary>
        /// <returns></returns>
        private string JudgeFileExistFTP()
        {
            TxtLog.Info("執行第二階段: Judge File Exist");
            string PROCESS_TYPE = FTPDBParameter.FTPParam.PROCESS_TYPE.Trim();
            string FilePath_D = default(string);
            string FileFg = default(string);
            if (FTPDBParameter.FTPParam.PROCESS_TYPE == "D" || FTPDBParameter.FTPParam.PROCESS_TYPE == "E")
            {
#if useDB
                    FilePath_D = FTPDBParameter.FTPParam.SOURCEDIR.Trim()  + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".D";
#elif useConfig
                FilePath_D = Utility.DefaultPath  + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".D";
#endif
            }
            else
            {
#if useDB
                     FilePath_D = FTPDBParameter.FTPParam.SOURCEDIR.Trim()   + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".D";
#elif useConfig
                FilePath_D = Utility.DefaultPath   + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".D";
#endif
            }

            if (File.Exists(FilePath_D))
            {
                string FilePath_H;
                if (FTPDBParameter.FTPParam.PROCESS_TYPE == "D" || FTPDBParameter.FTPParam.PROCESS_TYPE == "E")
                {
                #if useDB
                     FilePath_H = FTPDBParameter.FTPParam.SOURCEDIR.Trim()  + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".H";
                #elif useConfig
                    FilePath_H = Utility.DefaultPath  + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".H";
                #endif
                }
                else
                {
                #if useDB
                    FilePath_H = FTPDBParameter.FTPParam.SOURCEDIR.Trim()   + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".H";
                #elif useConfig
                    FilePath_H = Utility.DefaultPath   + FTPDBParameter.FTPParam.FILENAME.Trim() + "." + FTPDBParameter.CycleDate.Trim() + ".H";
                #endif
                }
                if (File.Exists(FilePath_D))
                    FileFg = "Y";
                else
                    FileFg = "N";
            }
            else
                FileFg = "N";
            return FileFg;
        }
    }
}
