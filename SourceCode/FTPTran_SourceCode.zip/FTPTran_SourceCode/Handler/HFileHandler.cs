﻿#define useDB
#if useDB
#elif useConfig
#endif

using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第三階段Judge Server Name之後的流程
    /// </summary>
    internal class HFileHandler : AbstractHandler
    {
        internal GenFileDeliverParam GenFileDeliverParam { get; set; }

        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(HFileHandler));

        internal HFileHandler(GenFileDeliverParam GenFileDeliverParam)
        {
            this.GenFileDeliverParam = GenFileDeliverParam;
        }

        public override void Handle(Step step)
        {
            int dataCNT = 0;
            string HFilePath = "";
            if (step == Step.Third)
            {
                XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));

                if (GenFileDeliverParam.SRVFG == SRVFG.ZERO)
                {
                    dataCNT = DoSelectDATACNTSP();
                    TxtLog.Info("執行第三階段: SELECT DATACNT 成功");
                }
                else if (GenFileDeliverParam.SRVFG == SRVFG.ONE)
                {
                    dataCNT = DoSelectCRMDBDATACNT();
                    TxtLog.Info("執行第三階段: SELECT CRMDB DATACNT 成功");
                }
                HFilePath = GenerateHFile(dataCNT);
                if(File.Exists(HFilePath)){
                    TxtLog.Info("執行第三階段: GENERATE H FILE 成功。 HFilePath為 " + HFilePath);
                }
                else
                    TxtLog.Error("執行第三階段: GENERATE H FILE 沒成功。 " + HFilePath + " 不存在");
            }
            else
                base.Handle(step);
        }

        /// <summary>
        /// 執行SELECT DATACNT
        /// </summary>
        /// <returns></returns>
        private int DoSelectDATACNTSP()
        {
            TxtLog.Info("執行第三階段: SELECT DATACNT");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@REFRESH_TYPE", GenFileDeliverParam.GenFileParam.REFRESH_TYPE);
            dict.Add("@DBNAME", GenFileDeliverParam.GenFileParam.DB_NAME);
            dict.Add("@PROCESS_TYPE", GenFileDeliverParam.GenFileParam.PROCESS_TYPE);
            dict.Add("@CYCLEDATE", GenFileDeliverParam.CycleDate);
            dict.Add("@TABLENAME", GenFileDeliverParam.GenFileParam.TABLE_NAME);
            dict.Add("@DATE_COLNM", GenFileDeliverParam.GenFileParam.DATE_COLNM);
            dict.Add("@FILESDT", GenFileDeliverParam.FILESDT);
            return Convert.ToInt32(SPExecutor.ExecuteSPWithStrValue("USP_TRAN_SELECT_DATACNT", dict, GenFileDeliverParam.CONN));
        }

        /// <summary>
        /// 執行SELECT CRMDB DATACNT
        /// </summary>
        /// <returns></returns>
        private int DoSelectCRMDBDATACNT()
        {
            TxtLog.Info("執行第三階段: SELECT CRMDB DATACNT");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@REFRESH_TYPE", GenFileDeliverParam.GenFileParam.REFRESH_TYPE);
            dict.Add("@DBNAME", GenFileDeliverParam.GenFileParam.DB_NAME);
            dict.Add("@PROCESS_TYPE", GenFileDeliverParam.GenFileParam.PROCESS_TYPE);
            dict.Add("@CYCLEDATE", GenFileDeliverParam.CycleDate);
            dict.Add("@TABLENAME", GenFileDeliverParam.GenFileParam.TABLE_NAME);
            dict.Add("@FILESDT", GenFileDeliverParam.FILESDT);
            dict.Add("@DATE_COLNM", GenFileDeliverParam.GenFileParam.DATE_COLNM);
            return Convert.ToInt32(SPExecutor.ExecuteSPWithStrValue("USP_TRAN_SELECT_CRMDB_DATACNT", dict, GenFileDeliverParam.CONN));
        }

        /// <summary>
        /// GENERATE H FILE
        /// </summary>
        /// <param name="dataCNT"></param>
        private string GenerateHFile(int dataCNT)
        {
            TxtLog.Info("執行第三階段: GENERATE H FILE");

            string DATACNT = ("0000000000" + dataCNT.ToString().Trim()).Substring(dataCNT.ToString().Trim().Length, 10);
            string PROCESS_TYPE = GenFileDeliverParam.GenFileParam.PROCESS_TYPE.Trim();
            string AllPath;
            if (PROCESS_TYPE == "D" || PROCESS_TYPE == "E"){
#if useDB
                 AllPath = GenFileDeliverParam.GenFileParam.SOURCEDIR.Trim()  + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".H";
#elif useConfig
                 AllPath = Utility.DefaultPath.Trim() + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".H";
#endif
            }
            else
            {
#if useDB
                 AllPath = GenFileDeliverParam.GenFileParam.SOURCEDIR.Trim() + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".H";
#elif useConfig
                AllPath = Utility.DefaultPath.Trim() + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + "." + GenFileDeliverParam.CycleDate.Trim() + ".H";
#endif
            }

            StreamWriter sw = new StreamWriter(AllPath,false,System.Text.Encoding.Default);
            sw.Write(GenFileDeliverParam.FILESDT.Trim() + GenFileDeliverParam.FILEEDT.Trim() + GenFileDeliverParam.GenFileParam.FILENAME.Trim() + ".D" + System.DateTime.Now.ToString("yyyyMMddHHmmss") + DATACNT);
            sw.Close();
            return AllPath;
        }
    }
}
