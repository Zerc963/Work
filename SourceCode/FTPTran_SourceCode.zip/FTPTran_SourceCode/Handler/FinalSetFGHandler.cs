﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 第三階段從Update Status to RUN GenFile到GET FILE DT步驟
    /// </summary>
    internal class FinalSetFGHandler : AbstractHandler
    {
        internal GenFileDeliverParam GenFileDeliverParam { get; set; }

        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(FinalSetFGHandler));

        internal FinalSetFGHandler(GenFileDeliverParam GenFileDeliverParam)
        {
            this.GenFileDeliverParam = GenFileDeliverParam;
        }

        public override void Handle(Step step)
        {
            if (step == Step.First)
            {
                XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));

                DoUpdateStatusToRunGenFileSP();
                TxtLog.Info("執行第三階段: Update Status to RUN GenFile 成功");
                GenFileDeliverParam.GenFileParam = DoGetFileList();
                TxtLog.Info("執行第三階段: Get FileList 成功");
                var dict = DoGetFileDT();
                TxtLog.Info("執行第三階段: GET FILE DT 成功");
                GenFileDeliverParam.FILEEDT = dict["FILEEDT"];
                GenFileDeliverParam.FILESDT = dict["FILESDT"];
            }
            else
                base.Handle(step);
        }

        /// <summary>
        /// 執行Get File DT
        /// </summary>
        /// <returns></returns>
        private Dictionary<string,string> DoGetFileDT()
        {
            TxtLog.Info("執行第三階段: Get File DT");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@PROCESS_TYPE", GenFileDeliverParam.GenFileParam.PROCESS_TYPE);
            dict.Add("@CYCLEDATE", GenFileDeliverParam.CycleDate);
            return SPExecutor.ExecuteSPWithDT("USP_TRAN_GET_FILE_DT", dict, GenFileDeliverParam.CONN);
        }

        /// <summary>
        /// 執行Update Status to RUN GenFile
        /// </summary>
        private void DoUpdateStatusToRunGenFileSP()
        {
            TxtLog.Info("執行第三階段: Update Status to RUN GenFile");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", GenFileDeliverParam.FILENAME);
            dict.Add("@SERVERNAME", GenFileDeliverParam.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_Status_To_Run_GenFile", dict, GenFileDeliverParam.CONN);
        }

        /// <summary>
        /// 執行Get FileList
        /// </summary>
        /// <returns></returns>
        private GenFileParam DoGetFileList()
        {
            TxtLog.Info("執行第三階段: Get FileList");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", GenFileDeliverParam.FILENAME.Trim());
            dict.Add("@SERVERNAME", GenFileDeliverParam.SERVERNAME.Trim());
            return SPExecutor.ExecuteSPWithGenFileValue("USP_TRAN_Get_FileList", dict, GenFileDeliverParam.CONN);
        }

    }
}
