﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第一階段SCAN XTRansStatus流程
    /// </summary>
    internal class ScanXTransStatusHandler : AbstractHandler
    {
        internal DBParameter DBParameter { get; set; }
        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(ScanXTransStatusHandler));

        internal ScanXTransStatusHandler(DBParameter DBParameter)
        {
            this.DBParameter = DBParameter;
        }

        public override void Handle(Step step)
        {
            if (step == Step.First)
            {

                XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));
                TxtLog.Info("執行第一階段: FILENAME = " + DBParameter.FileDeliver.FileName);
                TxtLog.Info("執行第一階段: Scan XTransStatus");

                Dictionary<string, string> dict = new Dictionary<string, string>();
                dict.Add("@PROCESS_TYPE", DBParameter.FileDeliver.PROCESS_TYPE);
                dict.Add("@BOOT", DBParameter.FileDeliver.BOOT);
                dict.Add("@ACTIVE_START_DATE", DBParameter.FileDeliver.ACTIVE_START_DATE);
                dict.Add("@ACTIVE_END_DATE", DBParameter.FileDeliver.ACTIVE_END_DATE);

                //執行SCAN XTRansStatus sp
                var readerResult = SPExecutor.ExecuteSPWithRtValue("dbo.USP_TRAN_Scan_XTransStatus", dict, DBParameter.conn);
                DBParameter.Boot = readerResult["BOOT"];
                DBParameter.FNBSDT = readerResult["FNBSDT"];
                TxtLog.Info("執行第一階段: Scan XTransStatus 成功");
            }
            else
                base.Handle(step);
        }
    }
}
