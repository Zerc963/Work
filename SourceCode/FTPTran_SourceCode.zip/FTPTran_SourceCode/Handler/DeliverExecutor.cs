﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    internal static class DeliverExecutor
    {
        internal static void Execute(AbstractHandler handler)
        {
            foreach (var process in new List<Step> { Step.First, Step.Second, Step.Third })
            {
                handler.Handle(process);
            }
        }
    }
}
