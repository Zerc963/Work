﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第一階段Judge BOOT之後的流程
    /// </summary>
    internal class BootHandler : AbstractHandler
    {
        internal DBParameter DBParameter { get; set; }
        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(BootHandler));

        internal BootHandler(DBParameter DBParameter)
        {
            this.DBParameter = DBParameter;
        }

        public override void Handle(Step step)
        {
            XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));
            if (step == Step.Third)
            {
                Utility.IsFTPProcessStart = false;
                TxtLog.Info("執行第一階段: BOOT值為 = " + DBParameter.Boot);
                if (DBParameter.Boot.Equals(JudgeBOOT.W.ToString()))
                {
                    TxtLog.Info("執行第一階段: UPDATE RUN STATUS TO WAITING FILE");
                    UpdateRunStatus();

                    TxtLog.Info("執行第一階段: UPDATE RUN STATUS TO WAITING FILE 成功");
                }
                else if(DBParameter.Boot.Equals(JudgeBOOT.Y.ToString()))
                {
                    TxtLog.Info("準備執行第二階段: FTP");
                    Utility.IsFTPProcessStart = true;
                }
                else if (DBParameter.Boot.Equals(JudgeBOOT.N.ToString()))
                {
                    TxtLog.Info("執行第一階段: JUDGE WAIT_DATACNT");
                    int result = JudgeWaitDatCat();
                    TxtLog.Info("執行第一階段: RunFlag = " + result);
                    TxtLog.Info("執行第一階段: JUDGE WAIT_DATACNT 成功");
                    if (result == (int)RunFlag.One)
                    {
                        TxtLog.Info("執行第一階段: UPDATE ACTIVE_START_DATE");
                        UpdateActiveStartDate();
                        TxtLog.Info("執行第一階段: UPDATE ACTIVE_START_DATE 成功");
                        Utility.IsFTPProcessStart = true;
                    }
                    else if(result == (int)RunFlag.Zero)
                    {

                        TxtLog.Warn("執行第一階段: UPDATE RUN STATUS TO WAITING FILE");
                        UpdateRunStatus();
                        TxtLog.Warn("執行第一階段: UPDATE RUN STATUS TO WAITING FILE 成功");
                        Utility.IsFTPProcessStart = false;
                    }
                }
            }
            else
                base.Handle(step);
        }

        /// <summary>
        /// 執行UPDATE RUN_STATUS TO WAITING FILE
        /// </summary>
        private void UpdateRunStatus()
        {
            Utility.IsFTPProcessStart = false;
            Dictionary<string, string> upRunDict = new Dictionary<string, string>();
            upRunDict.Add("@FileName", DBParameter.FileDeliver.FileName);
            upRunDict.Add("@ServerName", DBParameter.FileDeliver.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_RunStatus", upRunDict, DBParameter.conn);
        }

        /// <summary>
        /// 執行JUDGE WAIT_DATCAT
        /// </summary>
        /// <returns></returns>
        private int JudgeWaitDatCat()
        {
            Dictionary<string, string> upJunWD = new Dictionary<string, string>();
            upJunWD.Add("@PROCESS_TYPE", DBParameter.FileDeliver.PROCESS_TYPE);
            upJunWD.Add("@ACTIVE_START_DATE", DBParameter.FileDeliver.ACTIVE_START_DATE);
            upJunWD.Add("@WAIT_DATACAT", DBParameter.FileDeliver.WAIT_DATACAT);
            return Convert.ToInt32(SPExecutor.ExecuteSPWithStrValue("USP_TRAN_JUDGE_WAIT_DATACAT", upJunWD, DBParameter.conn));
        }

        /// <summary>
        /// 執行UPDATE  ACTIVE_START_DATE
        /// </summary>
        private void UpdateActiveStartDate()
        {
            Dictionary<string, string> upRunDict = new Dictionary<string, string>();
            upRunDict.Add("@PROCESS_TYPE", DBParameter.FileDeliver.PROCESS_TYPE);
            upRunDict.Add("@FileName", DBParameter.FileDeliver.FileName);
            upRunDict.Add("@ACTIVE_START_DATE", DBParameter.FileDeliver.ACTIVE_START_DATE);
            upRunDict.Add("@ServerName", DBParameter.FileDeliver.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_UPDATE_ACTIVE_START_DATE", upRunDict, DBParameter.conn);
        }
    }
}
