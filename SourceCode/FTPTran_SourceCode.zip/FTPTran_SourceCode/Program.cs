﻿#define normalStatus
#if alwaysRunFTP
#elif normalStatus
#endif

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Diagnostics;
using System.Configuration;
using log4net;
using log4net.Config;

namespace MetaEdge.BOTCRM.FileDelivery
{
    class Program
    {
        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(Program));

        /// <summary>
        /// 執行第一階段GET DATA
        /// </summary>
        /// <param name="connectString"></param>
        /// <returns></returns>
        private static List<FileDelivery> GetData(SqlConnection connection)
        {
            List<FileDelivery> fileDeliveryList = new List<FileDelivery>();
            string sql = string.Format("select * from [dbo].[GetFileDeliveryData]");
            TxtLog.Info("執行第一階段: GET DATA");
            TxtLog.Info("執行view: " + sql);
                SqlCommand command = new SqlCommand(sql, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string[] nameList = Utility.GetFieldNames(reader);
                        fileDeliveryList.Add(new FileDelivery((string)reader[Array.IndexOf(nameList, Delivery.PROCESS_TYPE)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.BOOT)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.ACTIVE_START_DATE)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.ACTIVE_END_DATE)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.SOURCEDIR)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.FILENAME)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.FILE_TYPE)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.WAIT_DATACAT)],
                                                              (string)reader[Array.IndexOf(nameList, Delivery.SERVERNAME)]));
                    }
                    reader.Close();
                    TxtLog.Info("執行view結束。共有" + fileDeliveryList.Count() + "筆資料");
                    TxtLog.Info("執行第一階段: GET DATA 成功結束");
                }
                catch (Exception ex)
                {
                    TxtLog.Debug(ex.Message);
                }
            return fileDeliveryList;
        }

        /// <summary>
        /// 執行Update Status to ABORT
        /// </summary>
        private static void UpdateStatusIfConditonABORT(SqlConnection conn)
        {
            TxtLog.Info("執行第一階段: UpdateStatusIfConditonABORT");

            string sql = "update [CRM_ISMD].[dbo].[XTRANSTATUS] set RUN_STATUS='', BOOT='Y' where RUN_STATUS='ABORT'";
            SqlCommand command = new SqlCommand(sql, conn);
            try
            {
                conn.Open();
                command.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex)
            {
                TxtLog.Error("執行第一階段 Error: " + ex);
            }
        }

        static void Main(string[] args)
        {

            XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));
            List<FileDelivery> fileDeliveryList = new List<FileDelivery>();
            List<FTPParam> ftpParamList = new List<FTPParam>();
            string connectString = CONN.GetConn();
            connectString += "MultipleActiveResultSets=True;";
            SqlConnection connection =
            new SqlConnection(connectString);
            UpdateStatusIfConditonABORT(connection);

            fileDeliveryList = GetData(connection);

            foreach (var item in fileDeliveryList)
            {
                Utility.IsFTPProcessStart = false;
                DBParameter dbPar = new DBParameter(item, connection);

                //第一階段拆成三個步驟，分別是scanXTransStatusHandler，fileHandler和bootHandler
                ScanXTransStatusHandler scanXTransStatusHandler = new ScanXTransStatusHandler(dbPar);
                FileHandler fileHandler = new FileHandler(dbPar);
                BootHandler bootHandler = new BootHandler(dbPar);

                scanXTransStatusHandler.SetNext(fileHandler).SetNext(bootHandler);
                DeliverExecutor.Execute(scanXTransStatusHandler);

                bool runFTPProcess;
#if alwaysRunFTP
                runFTPProcess = true;
#elif normalStatus
                runFTPProcess = Utility.IsFTPProcessStart;
#endif
                if (runFTPProcess)
                {
                        try
                        {
                            TxtLog.Info("第一階段結束，開始執行第二階段FTP");
                            FTPDBParameter ftpDB = new FTPDBParameter();
                            ftpDB.conn = connection;
                            FTPTakeHandler ftpHandler = new FTPTakeHandler(dbPar, ftpDB);
                            FTPFIleHandler ftpFileHandler = new FTPFIleHandler(ftpDB);
                            FTPFinalFileHandler ftpFinalFileHandler = new FTPFinalFileHandler(ftpDB);
                            //第二階段也拆成三個步驟，分別是ftpHandler，ftpFileHandler和ftpFinalFileHandler
                            ftpHandler.SetNext(ftpFileHandler).SetNext(ftpFinalFileHandler);
                            DeliverExecutor.Execute(ftpHandler);
                        }
                        catch (Exception ex)
                        {
                            TxtLog.Debug(ex.Message);
                        }
                }
            }
            connection.Close();
            TxtLog.Info("訂閱派送執行完畢");
            Console.WriteLine("訂閱派送執行完畢");
        }
    }
}
