﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    public static class CONN
    {
        public static string dbstrISMD = "ISMDDB";

        public static string GetConn()
        {
            return MetaEdge.Registry.ConnectionFactory.Get(dbstrISMD);
        }

    }
}
