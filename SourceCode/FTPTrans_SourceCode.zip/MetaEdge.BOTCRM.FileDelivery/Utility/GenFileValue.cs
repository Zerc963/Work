﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    internal static class GenFileValue
    {
        internal static readonly string FILENAME = "FILENAME";
        internal static readonly string DB_NAME = "DB_NAME";
        internal static readonly string TABLE_NAME = "TABLE_NAME";
        internal static readonly string PROCESS_TYPE = "PROCESS_TYPE";
        internal static readonly string REFRESH_TYPE = "REFRESH_TYPE";
        internal static readonly string SEPARATOR = "SEPARATOR";
        internal static readonly string SOURCEDIR = "SOURCEDIR";
        internal static readonly string ACTIVE_START_DATE = "ACTIVE_START_DATE";
        internal static readonly string WAIT_DATACAT = "WAIT_DATACAT";
        internal static readonly string FILE_TYPE = "FILE_TYPE";
        internal static readonly string RUN_STATUS = "RUN_STATUS";
        internal static readonly string SRVNM = "SRVNM";
        internal static readonly string DATE_COLNM = "DATE_COLNM";
    }
}
