﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 第一階段的參數
    /// </summary>
    internal class DBParameter
    {
        internal FileDelivery FileDeliver { get; set; }
        internal string Boot { get; set; }
        internal string FNBSDT { get; set; }
        internal SqlConnection conn { get; set; }

        internal DBParameter(FileDelivery fileDeliver, SqlConnection conn)
        {
            this.FileDeliver = fileDeliver;
            this.conn = conn;
        }
    }
}
