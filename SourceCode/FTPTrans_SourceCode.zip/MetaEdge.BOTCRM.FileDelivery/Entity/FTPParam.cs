﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 第二階段Take Param傳回來的參數
    /// </summary>
    internal class FTPParam
    {
        internal FTPParam(string FILENAME, string SERVERNAME, string SOURCEDIR, string BOOT, string FILE_TYPE, string PROCESS_TYPE, string SERVERIP, string USERNAME, string PW, string FTPFILEDIR, string WAIT_DATACAT, string RUN_STATUS, string ACTIVE_START_DATE)
        {
            this.FILENAME = FILENAME;
            this.SERVERNAME = SERVERNAME;
            this.SOURCEDIR = SOURCEDIR;
            this.BOOT = BOOT;
            this.FILE_TYPE = FILE_TYPE;
            this.PROCESS_TYPE = PROCESS_TYPE;
            this.SERVERIP = SERVERIP;
            this.USERNAME = USERNAME;
            this.PW = PW;
            this.FTPFILEDIR = FTPFILEDIR;
            this.WAIT_DATACAT = WAIT_DATACAT;
            this.RUN_STATUS = RUN_STATUS;
            this.ACTIVE_START_DATE = ACTIVE_START_DATE;
        }

        internal string FILENAME { get; set; }
        internal string SERVERNAME { get; set; }
        internal string SOURCEDIR { get; set; }
        internal string BOOT { get; set; }
        internal string FILE_TYPE { get; set; }
        internal string PROCESS_TYPE { get; set; }
        internal string SERVERIP { get; set; }
        internal string USERNAME { get; set; }
        internal string PW { get; set; }
        internal string FTPFILEDIR { get; set; }
        internal string WAIT_DATACAT { get; set; }
        internal string RUN_STATUS { get; set; }
        internal string ACTIVE_START_DATE { get; set; }
    }
}
