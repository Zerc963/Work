﻿#define useDB
#if useDB
#elif useConfig
#endif

using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 第二階段Get FTPFile之後Foreach Loop的動作
    /// </summary>
    internal class FTPFinalFileHandler : AbstractHandler
    {
        internal FTPDBParameter FTPDBParameter { get; set; }
        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(FTPFinalFileHandler));

        private delegate string Del(string fileName);
        private string connectionString;

        internal FTPFinalFileHandler(FTPDBParameter FTPDBParameter)
        {
            this.FTPDBParameter = FTPDBParameter;
        }

        public override void Handle(Step step)
        {
            bool isSendingFileSuccess = false;
            bool doesFileExist = true; 
            if (step == Step.Third)
            {
                XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));

                foreach (var item in FTPDBParameter.FTPFILENM)
                {
                    int errCount = default(int);
                    string errFg = default(string);
                    DoUpdateStatusToVerifySP();
                    TxtLog.Info("執行第二階段: Update Status to Verify 成功");
                    do
                    {
                        errFg = ExecuteFileVerify(VerifyFileExist,VerifyFileNotUse, item.Value);
                        TxtLog.Info("執行第二階段: ErrFg = " + errFg);

                        if (errFg == "Y")
                        {
                            ++errCount;
                            TxtLog.Error("執行第二階段: ErrCount = " + errCount);
                            TxtLog.Error("執行第二階段: ErrFg = " + errFg + ",等30秒");
                            if(errCount > 5)
                                TxtLog.Fatal("errCount大於5次");
                            Thread.Sleep(30000);
                            TxtLog.Info("執行第二階段: 30秒結束");
                        }
                    } while (errFg == "Y" && errCount <= 5);
                    if (errFg == "N")
                    {
                        DoUpdateStatusToSending();
                        TxtLog.Info("執行第二階段: Update Status To Sending 成功");
                        ResetFTPConnection(item.Value);
                        TxtLog.Info("執行第二階段: Reset Ftp Connction 成功");
                        isSendingFileSuccess = SendFiles(item.Value);
                        DeleteFile(item.Value);
                        TxtLog.Info("執行第二階段: File Delete 成功");
                    }
                    else
                    {
                        doesFileExist = false;
                    }
                }
                if (isSendingFileSuccess && doesFileExist)
                {
                    DOUpdateStatusToRunOk();
                    TxtLog.Info("執行第二階段: Update Status to RUNOK");
                }
                else
                {
                    DOUpdateStatusToABORT();
                    TxtLog.Error("執行第二階段: Update Status to ABORT");
                }
            }
            else
                base.Handle(step);
        }

        /// <summary>
        /// 執行Update Status to ABORT
        /// </summary>
        private void DOUpdateStatusToABORT()
        {
            TxtLog.Info("執行第二階段: Update Status to SendFail");

            string sql = "UPDATE [CRM_ISMD].[dbo].XTRANSTATUS SET RUN_STATUS='ABORT',EXEC_DESC='Command not completed successfully',JOB_END_TIME=GETDATE() WHERE FILENAME=@FILENAME AND SERVERNAME=@SERVERNAME";
            SqlCommand command = new SqlCommand(sql, FTPDBParameter.conn);
            command.Parameters.AddWithValue("@FILENAME", FTPDBParameter.FTPParam.FILENAME);
            command.Parameters.AddWithValue("@SERVERNAME", FTPDBParameter.FTPParam.SERVERNAME);
            try
            {
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                TxtLog.Error("執行第二階段 Error: " + ex);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void DOUpdateStatusToRunOk()
        {
            TxtLog.Info("執行第二階段: Update Status to RUNOK");

            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", FTPDBParameter.FTPParam.FILENAME);
            dict.Add("@SERVERNAME", FTPDBParameter.FTPParam.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_Staus_To_RUNOK", dict, FTPDBParameter.conn);
        }
        /// <summary>
        /// 執行Update Status to Verify
        /// </summary>
        private void DoUpdateStatusToVerifySP()
        {
            TxtLog.Info("執行第二階段: Update Status to Verify");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", FTPDBParameter.FTPParam.FILENAME);
            dict.Add("@SERVERNAME", FTPDBParameter.FTPParam.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_Status_To_Verify", dict, FTPDBParameter.conn);
        }

        /// <summary>
        /// 執行Update Status to Sending
        /// </summary>
        private void DoUpdateStatusToSending()
        {
            TxtLog.Info("執行第二階段: Update Status To Sending");

            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", FTPDBParameter.FTPParam.FILENAME);
            dict.Add("@SERVERNAME", FTPDBParameter.FTPParam.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_Status_To_Sending", dict, FTPDBParameter.conn);
        }

        /// <summary>
        /// 執行Foreach Loop裡Update Status to Verify之後到Update Status to Sending之前的動作 
        /// </summary>
        /// <param name="vfyFile"></param>
        /// <param name="vfyFileNtUse"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private string ExecuteFileVerify(Del vfyFile, Del vfyFileNtUse, string fileName)
        {
            TxtLog.Info("執行第二階段: Verify File Exist");
            int errCount = default(int);
            string errVfFNuse = string.Empty;
            string errFg;
            do
            {
                errFg = vfyFile(fileName);
                if (errFg == "N")
                {
                    errVfFNuse = vfyFileNtUse(fileName);
                }
                else if (errFg == "Y")
                {
                    ++errCount;
                    if (errCount > 5)
                    {
                        TxtLog.Fatal("執行第二階段: errCount = " + errCount);
                        TxtLog.Fatal("超過五次錯誤");
                    }
                    TxtLog.Info("等候30秒");
                    Thread.Sleep(30000);
                }
            } while (errFg == "Y" && errCount <= 5);
            return errVfFNuse;
        }

        /// <summary>
        /// 執行Verify File Not Use
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private string VerifyFileNotUse(string fileName)
        {
            TxtLog.Info("執行第二階段: Verify File Not Exist");
            string PROCESS_TYPE = FTPDBParameter.FTPParam.PROCESS_TYPE.Trim();
            string FilePath;
            string filesize;
            string filesizeaf;
            bool IsFileUsed;
            string ErrFg;

            StreamReader s1;

            if (PROCESS_TYPE == "D" || PROCESS_TYPE == "E")
            {
#if useDB
                FilePath = FTPDBParameter.FTPParam.SOURCEDIR.Trim()  + fileName;
#elif useConfig
                FilePath = Utility.DefaultPath  + fileName;
#endif
            }
            else
            {
#if useDB
                 FilePath = FTPDBParameter.FTPParam.SOURCEDIR.Trim()   + fileName;
#elif useConfig
                FilePath = Utility.DefaultPath   + fileName;
#endif
            }
            try
            {
                FTPDBParameter.FilePath = FilePath;
                s1 = new StreamReader(FilePath);
                IsFileUsed = false;
                s1.Close();
            }
            catch (Exception ex)
            {
                IsFileUsed = true;
            }

            if (IsFileUsed)
            {
                ErrFg = "Y";
            }
            else
            {
                ErrFg = "N";
            }
            TxtLog.Info("執行第二階段: Verify File Not Exist 成功");
            return ErrFg;
        }

        /// <summary>
        /// Verify File Exist
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private string VerifyFileExist(string fileName)
        {
            TxtLog.Info("執行第二階段: Verify File Exist");
            string PROCESS_TYPE = FTPDBParameter.FTPParam.PROCESS_TYPE.Trim();
            string FilePath;
            string ErrFg;
            if (PROCESS_TYPE == "D" || PROCESS_TYPE == "E")
            {
#if useDB
                 FilePath = FTPDBParameter.FTPParam.SOURCEDIR.Trim()  + fileName;
#elif useConfig
                FilePath = Utility.DefaultPath  + fileName;
#endif
            }
            else
            {
#if useDB
                 FilePath = FTPDBParameter.FTPParam.SOURCEDIR.Trim()   + fileName;
#elif useConfig
                FilePath = Utility.DefaultPath   + fileName;
#endif
            }
            TxtLog.Info("第二階段 filePath = " + FilePath);
            if (File.Exists(FilePath))
            {
                ErrFg = "N";
                TxtLog.Info("執行第二階段: Verify File Exist 結果 " + FilePath + "存在");
                TxtLog.Info("執行第二階段: Verify File Exist 結果 ErrFg為 = " + ErrFg + "。執行成功");
            }
            else
            {

                ErrFg = "Y";
                TxtLog.Error("執行第二階段: Verify File Exist 結果 " + FilePath + "不存在");
                TxtLog.Error("執行第二階段: Verify File Exist 結果 ErrFg為 = " + ErrFg);
            }
            return ErrFg;
        }

        private void DeleteFile(string fileName)
        {
            TxtLog.Info("執行第二階段: File Delete");
            string PROCESS_TYPE = FTPDBParameter.FTPParam.PROCESS_TYPE.Trim();
            string FilePath = "";
            if (PROCESS_TYPE == "D" || PROCESS_TYPE == "E")
            {
#if useDB
                FilePath = FTPDBParameter.FTPParam.SOURCEDIR.Trim()  + fileName;
#elif useConfig
                FilePath = Utility.DefaultPath  + fileName;
#endif
            }
            else
            {
#if useDB
                FilePath = FTPDBParameter.FTPParam.SOURCEDIR.Trim()   + fileName;
#elif useConfig
                FilePath = Utility.DefaultPath   + fileName;
#endif
            }
            TxtLog.Info("執行第二階段: File Dele Begins");
            if (File.Exists(FilePath))
                File.Delete(FilePath);
            TxtLog.Info("執行第二階段: File Delete 完成");
        }

        /// <summary>
        /// 執行Reset Ftp Connection
        /// </summary>
        /// <param name="fileName"></param>
        private void ResetFTPConnection(string fileName)
        {
            FTPDBParameter.FTPParam.PROCESS_TYPE = FTPDBParameter.FTPParam.PROCESS_TYPE.Trim();
            TxtLog.Info("執行第二階段: Reset Ftp Connction");

            string serverName = FTPDBParameter.FTPParam.SERVERNAME;

            if (FTPDBParameter.FTPParam.PROCESS_TYPE == "D" || FTPDBParameter.FTPParam.PROCESS_TYPE == "E")
            {
#if useDB
                connectionString = FTPDBParameter.FTPParam.SOURCEDIR.Trim()  + fileName;
#elif useConfig
                connectionString = Utility.DefaultPath  + fileName;
#endif
            }
            else
            {
#if useDB
                connectionString = FTPDBParameter.FTPParam.SOURCEDIR.Trim()   + fileName;
#elif useConfig
                connectionString = Utility.DefaultPath   + fileName;
#endif
            }
            TxtLog.Info("執行第二階段: Reset Ftp Connction 完成");
        }

        /// <summary>
        /// 執行Sending Files動作
        /// </summary>
        /// <param name="fileName"></param>
        private bool SendFiles(string fileName)
        {
            TxtLog.Info("執行第二階段: Send Files");
            bool isSendingFileSuccess = true;
            try
            {
                using (var client = new WebClient())
                {
                    client.Credentials = new NetworkCredential(FTPDBParameter.FTPParam.USERNAME.Trim(), FTPDBParameter.FTPParam.PW.Trim());
                    client.UploadFile(@"ftp://" + FTPDBParameter.FTPParam.SERVERIP.Trim() + "/" + fileName.Trim(), WebRequestMethods.Ftp.UploadFile, connectionString);
                }
            }
            catch (Exception ex)
            {
                isSendingFileSuccess = false;
                TxtLog.Fatal("Send Files Fail : "  + FTPDBParameter.FTPParam.SERVERIP.Trim() + ex.Message);
                //throw new Exception("Send Files Fail : " + ex.Message);
            }
            if (isSendingFileSuccess)
                TxtLog.Info("執行第二階段: Send Files 成功");
            else
                TxtLog.Error("執行第二階段: Send Files 不成功");
            return isSendingFileSuccess;
        }
    }
}
