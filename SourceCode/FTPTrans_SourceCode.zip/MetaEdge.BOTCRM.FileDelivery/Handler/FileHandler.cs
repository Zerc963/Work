﻿
#define useDB
#if useDB
#elif useConfig
#endif

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
using log4net;
using log4net.Config;
using System.Configuration;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第一階段Judge File Exist流程
    /// </summary>
    internal class FileHandler : AbstractHandler
    {
        internal DBParameter DBParameter { get; set; }

        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(FileHandler));


        internal FileHandler(DBParameter DBParameter)
        {
            this.DBParameter = DBParameter;
        }

        public override void Handle(Step step)
        {
            if (step == Step.Second)
            {
                XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));
                TxtLog.Info("執行第一階段: Judge File Exist");
                this.DoesFileExist(DBParameter.FileDeliver, DBParameter.Boot, DBParameter.FNBSDT);
                TxtLog.Info("執行第一階段: Judge File Exist 成功");
            }
            else
                base.Handle(step);
        }

        /// <summary>
        /// Judge File Exist
        /// </summary>
        /// <param name="fileDelivery"></param>
        /// <param name="BOOT"></param>
        /// <param name="FNBSDT"></param>
        private void DoesFileExist(FileDelivery fileDelivery, string BOOT, string FNBSDT)
        {
            string PROCESS_TYPE = fileDelivery.PROCESS_TYPE.Trim();
            string FILETRANS_FilePath;
            string FTPData_FilePath;
            string Backup_FilePath;
            if (PROCESS_TYPE.Equals("D") || PROCESS_TYPE.Equals("E"))
            {
                #if useDB
                    FILETRANS_FilePath = fileDelivery.SOURCEDIR.Trim()  + fileDelivery.FileName.Trim() + "." + FNBSDT.Trim().Replace("/", "");
                #elif useConfig
                    FILETRANS_FilePath = Utility.DefaultPath  + fileDelivery.FileName.Trim() + "." + FNBSDT.Trim().Replace("/", "");
                #endif
            }
            else
            {
                 #if useDB
                    FILETRANS_FilePath = fileDelivery.SOURCEDIR.Trim()  + fileDelivery.FileName.Trim() + "." + FNBSDT.Trim().Replace("/", "");
                 #elif useConfig
                    FILETRANS_FilePath = Utility.DefaultPath   + fileDelivery.FileName.Trim() + "." + FNBSDT.Trim().Replace("/", "");
                 #endif
            }
                #if useDB                 
                    FTPData_FilePath = (string)(new AppSettingsReader().GetValue("FTPDataPath", typeof(string))) + fileDelivery.FileName.Trim() + "." + FNBSDT.Trim().Replace("/", "");
                    Backup_FilePath = (string)(new AppSettingsReader().GetValue("BackupPath", typeof(string))) + FNBSDT.Trim().Replace("/", "") + fileDelivery.FileName + ".rar";
                #elif useConfig
                    FTPData_FilePath = @"D:\FTPData\" + fileDelivery.FileName.Trim() + "." + FNBSDT.Trim().Replace("/", "");
                    Backup_FilePath = @"D:\Backup\" + FNBSDT.Trim().Replace("/", "") + fileDelivery.FileName + ".rar";
                #endif
            if (!BOOT.Trim().Equals("ZZZZ") && fileDelivery.FILE_TYPE.Equals("F"))
            {
                if (File.Exists(FILETRANS_FilePath + ".D") && File.Exists(FILETRANS_FilePath + ".H"))
                {
                    //'檔案已到可以派送了
                }
                else
                {
                    if (File.Exists(FTPData_FilePath + ".D") && File.Exists(FILETRANS_FilePath + ".H"))
                    {
                        File.Copy(FTPData_FilePath + ".D", FILETRANS_FilePath + ".D", true);
                        File.Copy(FTPData_FilePath + ".H", FILETRANS_FilePath + ".H", true);
                    }
                    else
                    {
                        if (File.Exists(Backup_FilePath))
                        {
                            var p = new Process();
                            #if useDB 
                            p.StartInfo.FileName = (string)(new AppSettingsReader().GetValue("WinRARPath", typeof(string)));
                            #elif useConfig
                                p.StartInfo.FileName = @"D:\CRM\EXE\winrar\WinRAR.exe";
                            #endif

                            if (PROCESS_TYPE == "D" || PROCESS_TYPE == "E")
                                p.StartInfo.Arguments = "-ibck -o+ e " + Backup_FilePath + " " + fileDelivery.SOURCEDIR.Trim() ;
                            else
                                p.StartInfo.Arguments = "-ibck -o+ e " + Backup_FilePath + " " + fileDelivery.SOURCEDIR.Trim()  ;
                            p.StartInfo.UseShellExecute = false;
                            p.StartInfo.RedirectStandardError = true;
                            p.StartInfo.CreateNoWindow = true;
                            p.Start();
                            p.BeginErrorReadLine();
                            p.WaitForExit();
                        }
                        else
                            BOOT = "W";
                    }
                }
            }
        }
    }
}
