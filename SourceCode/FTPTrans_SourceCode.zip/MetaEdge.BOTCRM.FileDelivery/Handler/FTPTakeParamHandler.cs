﻿using log4net;
using log4net.Config;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MetaEdge.BOTCRM.FileDelivery
{
    /// <summary>
    /// 執行第二階段(FTP)Take Param到Update Status to Output步驟
    /// </summary>
    internal class FTPTakeHandler : AbstractHandler
    {
        internal DBParameter DBParameter { get; set; }
        private static readonly ILog TxtLog = LogManager.GetLogger(typeof(FTPTakeHandler));

        internal FTPDBParameter FTPDBParameter { get; set; }
        internal FTPTakeHandler(DBParameter DBParameter, FTPDBParameter FTPDBParameter)
        {
            this.DBParameter = DBParameter;
            this.FTPDBParameter = FTPDBParameter;
        }

        public override void Handle(Step step)
        {
            XmlConfigurator.Configure(new FileInfo(@"../../log4netconfig.xml"));
            if (step == Step.First)
            {
                DoGetFTPParamSP();
                FTPDBParameter.CycleDate = DoGetCycleDateSP();
                TxtLog.Info("執行第二階段: Get CycleDate 成功");
                DoUpdateStatusToOutputSP();
                TxtLog.Info("執行第二階段: Update Status to Output 成功");
            }
            else
                base.Handle(step);
        }


        //Take Param
        private void DoGetFTPParamSP()
        {
            TxtLog.Info("執行第二階段: Take Param");
            Dictionary<string, string> ftpFirst = new Dictionary<string, string>();
            ftpFirst.Add("@FILENAME", DBParameter.FileDeliver.FileName);
            ftpFirst.Add("@SERVERNAME", DBParameter.FileDeliver.SERVERNAME);
            var ftpResult = SPExecutor.ExecuteSPWithRtValue("USP_TRAN_FTP_Take_Param", ftpFirst, DBParameter.conn);
            FTPDBParameter.FTPParam = new FTPParam(ftpResult.Where(i => i.Key == FTPValue.FILENAME).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.SERVERNAME).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.SOURCEDIR).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.BOOT).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.FILE_TYPE).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.PROCESS_TYPE).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.SERVERIP).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.USERNAME).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.PW).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.FTPFILEDIR).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.WAIT_DATACAT).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.RUN_STATUS).Select(i => i.Value).First(),
                                                      ftpResult.Where(i => i.Key == FTPValue.ACTIVE_START_DATE).Select(i => i.Value).First());
            TxtLog.Info("執行第二階段: Take Param 成功");
        }

        //執行Get CycleDate
        private string DoGetCycleDateSP()
        {
            TxtLog.Info("執行第二階段: Get CycleDate");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@PROCESS_TYPE", FTPDBParameter.FTPParam.PROCESS_TYPE);
            dict.Add("@FILE_TYPE", FTPDBParameter.FTPParam.FILE_TYPE);
            dict.Add("@RUN_STATUS", FTPDBParameter.FTPParam.RUN_STATUS);
            dict.Add("@ACTIVE_START_DATE", FTPDBParameter.FTPParam.ACTIVE_START_DATE);
            return SPExecutor.ExecuteSPWithStrValue("USP_TRAN_Get_CycleDate", dict, DBParameter.conn);
        }


        private void DoUpdateStatusToOutputSP()
        {
            TxtLog.Info("執行第二階段: Update Status to Output");
            Dictionary<string, string> dict = new Dictionary<string, string>();
            dict.Add("@FILENAME", FTPDBParameter.FTPParam.FILENAME);
            dict.Add("@SERVERNAME", FTPDBParameter.FTPParam.SERVERNAME);
            SPExecutor.ExecuteSPWithRtValue("USP_TRAN_Update_Status_To_Output", dict, DBParameter.conn);
        }

    }
}
