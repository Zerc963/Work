USE [CRM_MetaAuth]
GO
INSERT [dbo].[auth_Objects] ([AppId], [ObjectCode], [Parent], [ObjectName], [MenuPosition], [MenuText], [ToolTipText], [NavigateUrl], [ReportUrl], [MenuClass], [IconUrl], [AffiliateId], [Suspended], [Lst_Maint_Usr], [Lst_Maint_Dt]) VALUES (
	     101
	   , 0
	   , 101099
	   , N'整批查詢客戶往來分行'
	   , 12
	   , N'整批查詢客戶往來分行'
	   , N'整批查詢客戶往來分行'
	   , N'CRM4Program/CS_Report/CS_ACPFM_CuBrno_Import_Report.aspx'
	   , NULL, N'btn btn-danger', N'menu-icon fa fa-cogs', NULL, NULL, N'admin', CAST(N'2021-08-10T16:10:40.007' AS DateTime))
GO

INSERT [dbo].[auth_Permissions](
	    [AppId]
      , [ObjectId]
      , [OperationId]
      , [PermissionName]
      , [Lst_Maint_Usr]
      , [Lst_Maint_Dt]) VALUES (
	    101
	  , (select top 1 objectid from auth_Objects where [ObjectName] like '%整批查詢客戶往來分行%')
	  , 101001
	  , '整批查詢客戶往來分行-檢視'
	  , 'admin'
	  , GETDATE())
	  
INSERT [dbo].[auth_RolePermission]([RoleId], [PermissionId]) VALUES ('63010000', (select top 1 [PermissionId] from auth_Permissions where PermissionName like '%整批查詢客戶往來分行-檢視%'))
INSERT [dbo].[auth_RolePermission]([RoleId], [PermissionId]) VALUES ('63020000', (select top 1 [PermissionId] from auth_Permissions where PermissionName like '%整批查詢客戶往來分行-檢視%'))
INSERT [dbo].[auth_RolePermission]([RoleId], [PermissionId]) VALUES ('63030000', (select top 1 [PermissionId] from auth_Permissions where PermissionName like '%整批查詢客戶往來分行-檢視%'))
INSERT [dbo].[auth_RolePermission]([RoleId], [PermissionId]) VALUES ('63040000', (select top 1 [PermissionId] from auth_Permissions where PermissionName like '%整批查詢客戶往來分行-檢視%'))
INSERT [dbo].[auth_RolePermission]([RoleId], [PermissionId]) VALUES ('63050000', (select top 1 [PermissionId] from auth_Permissions where PermissionName like '%整批查詢客戶往來分行-檢視%'))
INSERT [dbo].[auth_RolePermission]([RoleId], [PermissionId]) VALUES ('63060000', (select top 1 [PermissionId] from auth_Permissions where PermissionName like '%整批查詢客戶往來分行-檢視%'))
